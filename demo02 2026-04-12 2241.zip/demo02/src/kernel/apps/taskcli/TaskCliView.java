package kernel.apps.taskcli;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Function;
import java.util.stream.Collectors;

import kernel.core.DerivedOutput;
import kernel.core.ReplayRun;
import kernel.core.VerifiedEvent;
import kernel.laws.task.TaskStateView;

final class TaskCliView {
    private TaskCliView() {
    }

    static String render(TaskStateView state, ReplayRun replayRun, List<VerifiedEvent> verifiedEvents) {
        List<String> lines = new ArrayList<>();
        Map<String, VerifiedEvent> eventsById = verifiedEvents.stream()
            .collect(Collectors.toMap(VerifiedEvent::eventId, Function.identity()));
        List<VerifiedEvent> correctionEvents = filterEvents(verifiedEvents, "TaskCorrected");
        VerifiedEvent lastStateEvent = state.lastStateEventId() == null ? null : eventsById.get(state.lastStateEventId());
        VerifiedEvent correctionTargetEvent = state.correctionTargetEventId() == null ? null : eventsById.get(state.correctionTargetEventId());
        VerifiedEvent correctionEvent = state.lastStateEventId() != null
            && state.status() == kernel.laws.task.TaskStatus.REOPENED
            ? eventsById.get(state.lastStateEventId())
            : findLatestCorrectionEvent(verifiedEvents, state.correctionTargetEventId(), state.correctionReason());

        lines.add("STATE");
        lines.add("  task: " + state.taskId());
        lines.add("  status: " + humanStatus(state));
        if (lastStateEvent != null) {
            lines.add("  last change: " + humanEvent(lastStateEvent) + " by " + lastStateEvent.actorId() + " at " + lastStateEvent.timeValue());
        }
        lines.add("  event count: " + replayRun.finalState().eventCount());
        lines.add("  last event id: " + replayRun.finalState().lastEventId());

        lines.add("WHY");
        if (correctionTargetEvent != null) {
            lines.add("  correction cycles: " + correctionEvents.size() + " corrected completion" + (correctionEvents.size() == 1 ? "" : "s"));
            lines.add(
                "  corrected completion: by " + correctionTargetEvent.actorId()
                    + " at " + correctionTargetEvent.timeValue()
            );
            if (correctionEvent != null && "TaskCorrected".equals(correctionEvent.eventType())) {
                lines.add(
                    "  correction made by: " + correctionEvent.actorId()
                        + " at " + correctionEvent.timeValue()
                );
            }
            if (correctionEvents.size() > 1) {
                VerifiedEvent priorCorrectionEvent = correctionEvents.get(correctionEvents.size() - 2);
                lines.add(
                    "  earlier correction: " + priorCorrectionReason(priorCorrectionEvent)
                        + " by " + priorCorrectionEvent.actorId()
                        + " at " + priorCorrectionEvent.timeValue()
                );
            }
            lines.add("  reason: " + state.correctionReason());
        } else {
            lines.add("  no correction or conflict");
        }

        lines.add("PATH");
        lines.add("  " + String.join(" -> ", summarizedPath(verifiedEvents)));

        lines.add("TRACE");
        for (String eventId : state.eventIds()) {
            VerifiedEvent event = eventsById.get(eventId);
            if (event != null) {
                lines.add(
                    "  [" + event.eventId() + "] "
                        + humanEvent(event)
                        + " by " + event.actorId()
                        + " at " + event.timeValue()
                );
            }
        }

        lines.add("OUTPUTS");
        for (DerivedOutput output : replayRun.outputs()) {
            lines.add("  - " + output.kind() + " eventId=" + output.eventId() + " value=" + output.value());
        }
        return String.join(System.lineSeparator(), lines);
    }

    private static VerifiedEvent findLatestCorrectionEvent(List<VerifiedEvent> verifiedEvents, String correctionTargetEventId, String correctionReason) {
        if (correctionTargetEventId == null) {
            return null;
        }
        for (int i = verifiedEvents.size() - 1; i >= 0; i--) {
            VerifiedEvent event = verifiedEvents.get(i);
            if ("TaskCorrected".equals(event.eventType()) && payloadValue(event).contains(correctionTargetEventId)) {
                return event;
            }
        }
        return null;
    }

    private static List<VerifiedEvent> filterEvents(List<VerifiedEvent> verifiedEvents, String eventType) {
        List<VerifiedEvent> filtered = new ArrayList<>();
        for (VerifiedEvent event : verifiedEvents) {
            if (eventType.equals(event.eventType())) {
                filtered.add(event);
            }
        }
        return filtered;
    }

    private static String payloadValue(VerifiedEvent event) {
        return new String(event.payloadBytes(), StandardCharsets.UTF_8);
    }

    private static String priorCorrectionReason(VerifiedEvent event) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(event.payloadBytes()), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse task payload for eventId " + event.eventId(), e);
        }
        return properties.getProperty("reason", "unknown");
    }

    private static String summarize(VerifiedEvent event) {
        return switch (event.eventType()) {
            case "TaskCreated" -> "Created";
            case "TaskStarted" -> "Started";
            case "TaskCompleted" -> "Completed";
            case "TaskCorrected" -> "Corrected completion";
            case "TaskCancelled" -> "Cancelled";
            default -> event.eventType();
        };
    }

    private static String humanEvent(VerifiedEvent event) {
        return switch (event.eventType()) {
            case "TaskCreated" -> "created";
            case "TaskStarted" -> "started";
            case "TaskCompleted" -> "completed";
            case "TaskCorrected" -> "corrected completion";
            case "TaskCancelled" -> "cancelled";
            default -> event.eventType();
        };
    }

    private static String humanStatus(TaskStateView state) {
        return switch (state.status()) {
            case CREATED -> "CREATED";
            case ACTIVE -> "ACTIVE";
            case REOPENED -> "REOPENED";
            case DONE -> "DONE";
            case CANCELLED -> "CANCELLED";
        };
    }

    private static List<String> summarizedPath(List<VerifiedEvent> verifiedEvents) {
        List<String> path = new ArrayList<>();
        for (int i = 0; i < verifiedEvents.size(); i++) {
            VerifiedEvent event = verifiedEvents.get(i);
            if ("TaskCompleted".equals(event.eventType())
                && i + 1 < verifiedEvents.size()
                && "TaskCorrected".equals(verifiedEvents.get(i + 1).eventType())) {
                path.add("Completed (corrected)");
                i++;
                continue;
            }
            path.add(summarize(event));
        }
        return path;
    }
}
