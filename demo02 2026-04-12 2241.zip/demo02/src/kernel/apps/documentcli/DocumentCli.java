package kernel.apps.documentcli;

import java.io.PrintStream;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import kernel.apps.flow.DocumentFlowShell;
import kernel.apps.support.AppConventions;
import kernel.apps.support.RootDisplay;
import kernel.apps.support.ShowConventions;
import kernel.apps.support.WorkspaceRoots;
import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.VerifiedEvent;
import kernel.core.VerifiedReplayChain;
import kernel.laws.document.DocumentEventWriter;
import kernel.laws.document.DocumentLaw;
import kernel.laws.document.DocumentStateView;
import kernel.laws.document.DocumentStatus;

public final class DocumentCli {
    private static final String LAW_VERSION = "document-law-v1";
    private static final String DEFAULT_ACTOR = "cli";
    private static final String DOMAIN = "document";

    private DocumentCli() {
    }

    public static void main(String[] args) {
        int exitCode = run(args, System.out, System.err);
        if (exitCode != 0) {
            System.exit(exitCode);
        }
    }

    public static int run(String[] args, PrintStream out, PrintStream err) {
        try {
            if (args.length == 0 || isHelp(args[0])) {
                printUsage(out);
                return 0;
            }

            String command = args[0];
            if ("flow".equals(command)) {
                return runFlow(args, out, err);
            }

            Map<String, String> options = parseOptions(args);
            Path rootDir = Path.of(options.getOrDefault("root", AppConventions.defaultRoot(DOMAIN).toString()));
            out.println("Root: " + RootDisplay.concise(rootDir));
            DocumentCliRepository repository = new DocumentCliRepository(rootDir);

            switch (command) {
                case "draft" -> draft(repository, options, out);
                case "submit" -> append(repository, options, "DocumentSubmitted", out);
                case "reject" -> reject(repository, options, out);
                case "revise" -> append(repository, options, "DocumentRevised", out);
                case "approve" -> append(repository, options, "DocumentApproved", out);
                case "flow" -> throw new IllegalStateException("document flow should be handled before standard option parsing");
                case "list" -> {
                    requireOnlyOptions(options, "root");
                    list(rootDir, out);
                }
                case "next" -> {
                    requireOnlyOptions(options, "root");
                    next(repository, out);
                }
                case "verify" -> {
                    requireOnlyOptions(options, "root");
                    verify(repository, out);
                }
                case "show" -> {
                    requireOnlyOptions(options, "root");
                    show(repository, out);
                }
                default -> {
                    err.println("error=Unknown document command: " + command);
                    printUsage(err);
                    return 1;
                }
            }
            return 0;
        } catch (Exception e) {
            err.println("error=" + e.getMessage());
            return 1;
        }
    }

    public static String[] usageLines() {
        return new String[] {
            "document draft --document <documentId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "document submit --document <documentId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "document reject --document <documentId> --target-event <eventId> --reason <text> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "document revise --document <documentId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "document approve --document <documentId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "document flow [--root <dir> | --new]",
            "document list [--root <workspaceDir>]",
            "document next [--root <dir>]",
            "document verify [--root <dir>]",
            "document show [--root <dir>]"
        };
    }

    private static void draft(DocumentCliRepository repository, Map<String, String> options, PrintStream out) throws Exception {
        requireOnlyOptions(options, "document", "root", "actor", "time");
        String documentId = required(options, "document");
        DocumentCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.isEmpty()) {
            throw new IllegalStateException("Document already exists at this root: " + repository.rootDir());
        }

        long timeValue = parseTime(options, 1L);
        DocumentEventWriter.WrittenDocumentEvent written = DocumentEventWriter.write(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            "DocumentDrafted",
            EventCodec.INITIAL_POINTER_SENTINEL,
            documentId,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("drafted=true");
        out.println("eventHash=" + written.eventHash());
        out.println("documentId=" + documentId);
    }

    private static void append(DocumentCliRepository repository, Map<String, String> options, String eventType, PrintStream out) throws Exception {
        requireOnlyOptions(options, "document", "root", "actor", "time");
        String documentId = required(options, "document");
        DocumentCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            throw new IllegalStateException("Document chain does not exist at " + repository.rootDir());
        }

        DocumentStateView currentState = currentDocumentState(repository);
        requireMatchingDocumentId(documentId, currentState);
        requireAllowedTransition(eventType, currentState);

        long timeValue = parseTime(options, chainState.eventCount() + 1L);
        DocumentEventWriter.WrittenDocumentEvent written = DocumentEventWriter.write(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            eventType,
            chainState.headHash(),
            documentId,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("appended=true");
        out.println("eventType=" + eventType);
        out.println("eventHash=" + written.eventHash());
        out.println("documentId=" + documentId);
    }

    private static void reject(DocumentCliRepository repository, Map<String, String> options, PrintStream out) throws Exception {
        requireOnlyOptions(options, "document", "target-event", "reason", "root", "actor", "time");
        String documentId = required(options, "document");
        String targetEventId = required(options, "target-event");
        String reason = required(options, "reason");
        DocumentCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            throw new IllegalStateException("Document chain does not exist at " + repository.rootDir());
        }

        DocumentStateView currentState = currentDocumentState(repository);
        requireMatchingDocumentId(documentId, currentState);
        if (currentState.status() != DocumentStatus.IN_REVIEW) {
            throw new IllegalStateException("DocumentRejected requires status IN_REVIEW but found " + currentState.status());
        }
        if (!targetEventId.equals(currentState.lastSubmissionEventId())) {
            throw new IllegalStateException(
                "Rejection target " + targetEventId + " does not match last submission event " + currentState.lastSubmissionEventId()
            );
        }

        long timeValue = parseTime(options, chainState.eventCount() + 1L);
        DocumentEventWriter.WrittenDocumentEvent written = DocumentEventWriter.writeRejection(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            chainState.headHash(),
            documentId,
            targetEventId,
            reason,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("rejected=true");
        out.println("eventType=DocumentRejected");
        out.println("eventHash=" + written.eventHash());
        out.println("documentId=" + documentId);
        out.println("targetEventId=" + targetEventId);
    }

    private static void verify(DocumentCliRepository repository, PrintStream out) throws Exception {
        requireChainExists(repository, "document");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        int count = replayChain.stream().toList().size();
        out.println("verified=true");
        out.println("verifiedEventCount=" + count);
    }

    private static void next(DocumentCliRepository repository, PrintStream out) throws Exception {
        out.println("NEXT");
        List<String> commands = nextCommands(repository);
        if (commands.isEmpty()) {
            out.println("  (no valid next events: document is " + currentDocumentState(repository).status() + ")");
            return;
        }
        for (String command : commands) {
            out.println("  - " + command);
        }
    }

    public static List<String> nextCommands(Path rootDir) throws Exception {
        return nextCommands(new DocumentCliRepository(rootDir));
    }

    public static List<DocumentListEntry> listEntries(Path workspaceRoot) throws Exception {
        java.util.ArrayList<DocumentListEntry> entries = new java.util.ArrayList<>();
        for (Path entityRoot : WorkspaceRoots.discoverEntityRoots(workspaceRoot)) {
            DocumentCliRepository repository = new DocumentCliRepository(entityRoot);
            DocumentStateView state = currentDocumentState(repository);
            entries.add(new DocumentListEntry(entityRoot, state.documentId(), state.status(), state.currentRevision()));
        }
        return List.copyOf(entries);
    }

    private static void list(Path workspaceRoot, PrintStream out) throws Exception {
        List<DocumentListEntry> entries = listEntries(workspaceRoot);
        out.println("STATE");
        out.println("  documents: " + entries.size());
        out.println("WHY");
        out.println("  discovered under: " + workspaceRoot);
        out.println("PATH");
        out.println("  current root + direct child roots with event histories");
        out.println("TRACE");
        for (DocumentListEntry entry : entries) {
            out.println(
                "  [" + WorkspaceRoots.displayRoot(workspaceRoot, entry.rootDir()) + "] "
                    + entry.documentId() + " " + entry.status() + " revision=" + entry.revision()
            );
        }
        out.println("OUTPUTS");
        for (DocumentListEntry entry : entries) {
            out.println("  - " + entry.showCommand(workspaceRoot));
        }
    }

    private static void show(DocumentCliRepository repository, PrintStream out) throws Exception {
        requireChainExists(repository, "document");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        List<VerifiedEvent> verifiedEvents = replayChain.stream().toList();
        ReplayRun replayRun = new Replayer().replay(replayChain, new DocumentLaw(LAW_VERSION));
        DocumentStateView state = DocumentStateView.from(replayRun.finalState());
        out.println(DocumentCliView.render(state, replayRun, verifiedEvents));
    }

    private static ReplayRun replay(DocumentCliRepository repository) throws Exception {
        requireChainExists(repository, "document");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        return new Replayer().replay(replayChain, new DocumentLaw(LAW_VERSION));
    }

    private static List<String> nextCommands(DocumentCliRepository repository) throws Exception {
        DocumentCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            return List.of("document draft --document <documentId>");
        }

        DocumentStateView state = currentDocumentState(repository);
        return switch (state.status()) {
            case DRAFT -> List.of(
                "document submit --document " + quote(state.documentId())
            );
            case IN_REVIEW -> List.of(
                "document reject --document " + quote(state.documentId())
                    + " --target-event " + quote(state.lastSubmissionEventId())
                    + " --reason <text>",
                "document approve --document " + quote(state.documentId())
            );
            case CHANGES_REQUESTED -> List.of(
                "document revise --document " + quote(state.documentId())
            );
            case APPROVED -> List.of();
        };
    }

    private static int runFlow(String[] args, PrintStream out, PrintStream err) throws Exception {
        FlowRequest request = parseFlowRequest(args);
        if (request.usingNewRoot()) {
            out.println("Using new root: " + RootDisplay.concise(request.rootDir()));
        }
        out.println("Root: " + RootDisplay.concise(request.rootDir()));
        return DocumentFlowShell.run(request.rootDir(), System.in, out, err);
    }

    private static DocumentStateView currentDocumentState(DocumentCliRepository repository) throws Exception {
        return DocumentStateView.from(replay(repository).finalState());
    }

    private static Map<String, String> parseOptions(String[] args) {
        java.util.HashMap<String, String> options = new java.util.HashMap<>();
        for (int i = 1; i < args.length; i++) {
            String token = args[i];
            if (!token.startsWith("--")) {
                throw new IllegalArgumentException("Expected option starting with -- but found: " + token);
            }
            String key = token.substring(2);
            if (i + 1 >= args.length) {
                throw new IllegalArgumentException("Missing value for option --" + key);
            }
            options.put(key, args[++i]);
        }
        return options;
    }

    private static FlowRequest parseFlowRequest(String[] args) throws Exception {
        Path rootDir = null;
        boolean usingNewRoot = false;

        for (int i = 1; i < args.length; i++) {
            String token = args[i];
            if ("--new".equals(token)) {
                usingNewRoot = true;
                continue;
            }
            if ("--root".equals(token)) {
                if (i + 1 >= args.length) {
                    throw new IllegalArgumentException("Missing value for option --root");
                }
                rootDir = Path.of(args[++i]);
                continue;
            }
            if (token.startsWith("--")) {
                throw new IllegalArgumentException("Unsupported option for document flow: " + token);
            }
            throw new IllegalArgumentException("Expected option starting with -- but found: " + token);
        }

        if (usingNewRoot && rootDir != null) {
            throw new IllegalArgumentException("document flow accepts either --root <dir> or --new, not both");
        }
        if (usingNewRoot) {
            return new FlowRequest(AppConventions.newSandboxRoot(DOMAIN), true);
        }
        if (rootDir != null) {
            return new FlowRequest(rootDir, false);
        }
        return new FlowRequest(AppConventions.defaultRoot(DOMAIN), false);
    }

    private static String required(Map<String, String> options, String key) {
        String value = options.get(key);
        if (value == null || value.isEmpty()) {
            throw new IllegalArgumentException("Missing required option --" + key);
        }
        return value;
    }

    private static long parseTime(Map<String, String> options, long defaultValue) {
        String value = options.get("time");
        return value == null ? defaultValue : Long.parseLong(value);
    }

    private static void requireOnlyOptions(Map<String, String> options, String... allowedKeys) {
        java.util.HashSet<String> allowed = new java.util.HashSet<>(java.util.List.of(allowedKeys));
        for (String key : options.keySet()) {
            if (!allowed.contains(key)) {
                throw new IllegalArgumentException("Unsupported option for document command: --" + key);
            }
        }
    }

    private static void requireChainExists(DocumentCliRepository repository, String domain) throws Exception {
        DocumentCliRepository.ChainState chainState = repository.chainState();
        if (chainState.isEmpty()) {
            throw new IllegalStateException("No " + domain + " chain exists at this root yet: " + repository.rootDir());
        }
    }

    private static void requireMatchingDocumentId(String documentId, DocumentStateView currentState) {
        if (!documentId.equals(currentState.documentId())) {
            throw new IllegalStateException(
                "Document id " + documentId + " does not match existing chain document " + currentState.documentId()
            );
        }
    }

    private static void requireAllowedTransition(String eventType, DocumentStateView currentState) {
        switch (eventType) {
            case "DocumentSubmitted" -> {
                if (currentState.status() != DocumentStatus.DRAFT) {
                    throw new IllegalStateException("DocumentSubmitted requires status DRAFT but found " + currentState.status());
                }
            }
            case "DocumentRevised" -> {
                if (currentState.status() != DocumentStatus.CHANGES_REQUESTED) {
                    throw new IllegalStateException(
                        "DocumentRevised requires status CHANGES_REQUESTED but found " + currentState.status()
                    );
                }
            }
            case "DocumentApproved" -> {
                if (currentState.status() != DocumentStatus.IN_REVIEW) {
                    throw new IllegalStateException("DocumentApproved requires status IN_REVIEW but found " + currentState.status());
                }
            }
            default -> throw new IllegalArgumentException("Unsupported document event type: " + eventType);
        }
    }

    private static boolean isHelp(String value) {
        return "help".equals(value) || "--help".equals(value) || "-h".equals(value);
    }

    private static void printUsage(PrintStream out) {
        out.println("Document CLI");
        out.println("Default root: " + AppConventions.defaultRoot(DOMAIN));
        out.println("Usage:");
        for (String line : usageLines()) {
            out.println("  " + line);
        }
        out.println();
        ShowConventions.printGuide(out);
    }

    public record DocumentListEntry(Path rootDir, String documentId, DocumentStatus status, int revision) {
        public String showCommand(Path workspaceRoot) {
            if (workspaceRoot.toAbsolutePath().normalize().equals(rootDir.toAbsolutePath().normalize())) {
                return "document show";
            }
            return "document show --root " + quote(rootDir.toString());
        }
    }

    private static String quote(String value) {
        return value.indexOf(' ') >= 0 ? "\"" + value.replace("\"", "\\\"") + "\"" : value;
    }

    private record FlowRequest(Path rootDir, boolean usingNewRoot) {
    }
}
