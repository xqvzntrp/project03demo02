package kernel.apps.documentcli;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Function;
import java.util.stream.Collectors;

import kernel.core.DerivedOutput;
import kernel.core.ReplayRun;
import kernel.core.VerifiedEvent;
import kernel.laws.document.DocumentStateView;
import kernel.laws.document.DocumentStatus;

final class DocumentCliView {
    private DocumentCliView() {
    }

    static String render(DocumentStateView state, ReplayRun replayRun, List<VerifiedEvent> verifiedEvents) {
        List<String> lines = new ArrayList<>();
        Map<String, VerifiedEvent> eventsById = verifiedEvents.stream()
            .collect(Collectors.toMap(VerifiedEvent::eventId, Function.identity(), (left, right) -> left, LinkedHashMap::new));
        Map<String, Integer> revisionsByEventId = revisionsByEventId(verifiedEvents);
        List<VerifiedEvent> rejectionEvents = filterEvents(verifiedEvents, "DocumentRejected");
        VerifiedEvent lastStateEvent = state.lastStateEventId() == null ? null : eventsById.get(state.lastStateEventId());
        VerifiedEvent rejectionEvent = state.lastRejectionEventId() == null ? null : eventsById.get(state.lastRejectionEventId());
        VerifiedEvent revisedEvent = rejectionEvent == null ? null : findNextEvent(verifiedEvents, rejectionEvent.eventId(), "DocumentRevised");
        VerifiedEvent resubmittedEvent = revisedEvent == null ? null : findNextEvent(verifiedEvents, revisedEvent.eventId(), "DocumentSubmitted");

        lines.add("STATE");
        lines.add("  document: " + state.documentId());
        lines.add("  status: " + humanStatus(state.status()));
        lines.add("  revision: " + state.currentRevision());
        if (lastStateEvent != null) {
            lines.add("  last change: " + humanEvent(lastStateEvent, revisionsByEventId));
        }
        lines.add("  event count: " + replayRun.finalState().eventCount());
        lines.add("  last event id: " + replayRun.finalState().lastEventId());

        lines.add("WHY");
        if (rejectionEvent != null) {
            lines.add("  review cycles: " + rejectionEvents.size() + " rejection" + (rejectionEvents.size() == 1 ? "" : "s") + " before approval");
            lines.add("  last rejection: by " + rejectionEvent.actorId() + " at " + rejectionEvent.timeValue());
            lines.add("  reason: " + state.lastRejectionReason());
            if (rejectionEvents.size() > 1) {
                VerifiedEvent priorRejectionEvent = rejectionEvents.get(rejectionEvents.size() - 2);
                lines.add("  earlier rejection: " + rejectionReason(priorRejectionEvent) + " by "
                    + priorRejectionEvent.actorId() + " at " + priorRejectionEvent.timeValue());
            }
            if (revisedEvent != null) {
                lines.add("  recovered by: " + humanEvent(revisedEvent, revisionsByEventId));
            }
            if (resubmittedEvent != null && state.status() != DocumentStatus.CHANGES_REQUESTED && state.status() != DocumentStatus.DRAFT) {
                lines.add("  resubmitted by: " + humanEvent(resubmittedEvent, revisionsByEventId));
            }
        } else if (state.status() == DocumentStatus.IN_REVIEW && lastStateEvent != null) {
            lines.add("  awaiting review since " + humanEvent(lastStateEvent, revisionsByEventId));
        } else if (state.status() == DocumentStatus.APPROVED && lastStateEvent != null) {
            lines.add("  approved without rejection history");
        } else {
            lines.add("  no rejection or approval yet");
        }

        lines.add("PATH");
        lines.add("  " + String.join(" -> ", summarizedPath(verifiedEvents, revisionsByEventId)));

        lines.add("TRACE");
        for (String eventId : state.eventIds()) {
            VerifiedEvent event = eventsById.get(eventId);
            if (event != null) {
                lines.add("  [" + event.eventId() + "] " + humanEvent(event, revisionsByEventId));
            }
        }

        lines.add("OUTPUTS");
        for (DerivedOutput output : replayRun.outputs()) {
            lines.add("  - " + output.kind() + " eventId=" + output.eventId() + " value=" + output.value());
        }
        return String.join(System.lineSeparator(), lines);
    }

    private static Map<String, Integer> revisionsByEventId(List<VerifiedEvent> verifiedEvents) {
        Map<String, Integer> revisions = new LinkedHashMap<>();
        int currentRevision = 0;
        for (VerifiedEvent event : verifiedEvents) {
            switch (event.eventType()) {
                case "DocumentDrafted" -> currentRevision = 1;
                case "DocumentRevised" -> currentRevision++;
                default -> {
                }
            }
            revisions.put(event.eventId(), currentRevision);
        }
        return revisions;
    }

    private static List<VerifiedEvent> filterEvents(List<VerifiedEvent> verifiedEvents, String eventType) {
        List<VerifiedEvent> filtered = new ArrayList<>();
        for (VerifiedEvent event : verifiedEvents) {
            if (eventType.equals(event.eventType())) {
                filtered.add(event);
            }
        }
        return filtered;
    }

    private static VerifiedEvent findNextEvent(List<VerifiedEvent> verifiedEvents, String afterEventId, String eventType) {
        boolean pastTarget = false;
        for (VerifiedEvent event : verifiedEvents) {
            if (!pastTarget) {
                pastTarget = event.eventId().equals(afterEventId);
                continue;
            }
            if (eventType.equals(event.eventType())) {
                return event;
            }
        }
        return null;
    }

    private static List<String> summarizedPath(List<VerifiedEvent> verifiedEvents, Map<String, Integer> revisionsByEventId) {
        List<String> path = new ArrayList<>();
        for (VerifiedEvent event : verifiedEvents) {
            path.add(summarize(event, revisionsByEventId));
        }
        return path;
    }

    private static String summarize(VerifiedEvent event, Map<String, Integer> revisionsByEventId) {
        return switch (event.eventType()) {
            case "DocumentDrafted" -> "Drafted v" + revisionsByEventId.get(event.eventId());
            case "DocumentSubmitted" -> "Submitted";
            case "DocumentRejected" -> "Rejected";
            case "DocumentRevised" -> "Revised v" + revisionsByEventId.get(event.eventId());
            case "DocumentApproved" -> "Approved";
            default -> event.eventType();
        };
    }

    private static String humanEvent(VerifiedEvent event, Map<String, Integer> revisionsByEventId) {
        return switch (event.eventType()) {
            case "DocumentDrafted" -> "drafted revision " + revisionsByEventId.get(event.eventId())
                + " by " + event.actorId() + " at " + event.timeValue();
            case "DocumentSubmitted" -> "submitted revision " + revisionsByEventId.get(event.eventId())
                + " by " + event.actorId() + " at " + event.timeValue();
            case "DocumentRejected" -> "rejected by " + event.actorId() + " at " + event.timeValue();
            case "DocumentRevised" -> "revised to revision " + revisionsByEventId.get(event.eventId())
                + " by " + event.actorId() + " at " + event.timeValue();
            case "DocumentApproved" -> "approved by " + event.actorId() + " at " + event.timeValue();
            default -> event.eventType() + " by " + event.actorId() + " at " + event.timeValue();
        };
    }

    private static String humanStatus(DocumentStatus status) {
        return switch (status) {
            case DRAFT -> "DRAFT";
            case IN_REVIEW -> "IN_REVIEW";
            case CHANGES_REQUESTED -> "CHANGES_REQUESTED";
            case APPROVED -> "APPROVED";
        };
    }

    private static String rejectionReason(VerifiedEvent event) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(event.payloadBytes()), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse document payload for eventId " + event.eventId(), e);
        }
        return properties.getProperty("reason", "unknown");
    }
}
