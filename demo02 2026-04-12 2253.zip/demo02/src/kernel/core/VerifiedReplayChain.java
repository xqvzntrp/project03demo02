package kernel.core;

import java.util.List;
import java.util.stream.Stream;

public final class VerifiedReplayChain {
    private final List<VerifiedEvent> events;

    VerifiedReplayChain(List<VerifiedEvent> events) {
        this.events = List.copyOf(events);
        for (VerifiedEvent event : this.events) {
            if (event == null) {
                throw new IllegalArgumentException("Verified replay chain must not contain null events");
            }
            if (event.payloadBytes() == null) {
                throw new IllegalArgumentException("Verified replay chain requires payload bytes for eventId " + event.eventId());
            }
        }
    }

    public Stream<VerifiedEvent> stream() {
        return events.stream();
    }
}
