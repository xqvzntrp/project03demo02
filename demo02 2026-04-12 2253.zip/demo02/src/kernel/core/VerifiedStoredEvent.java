package kernel.core;

public record VerifiedStoredEvent(
    String eventHash,
    Event event
) {
}
