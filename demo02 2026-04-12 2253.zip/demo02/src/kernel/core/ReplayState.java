package kernel.core;

import java.util.List;

public record ReplayState(
    List<String> appliedEventIds,
    int eventCount,
    long totalPayloadBytes,
    String lastEventId
) {
    public ReplayState {
        appliedEventIds = List.copyOf(appliedEventIds);
    }

    public static ReplayState initial() {
        return new ReplayState(List.of(), 0, 0L, null);
    }
}
