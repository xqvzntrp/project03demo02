package kernel.core;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class EventCodec {
    public static final String INITIAL_POINTER_SENTINEL = "GENESIS";

    private static final byte[] FORMAT_MARKER = new byte[] { 'E', 'V', 'T', '1' };
    private static final byte FIELD_ABSENT = 0x00;
    private static final byte FIELD_NULL = 0x01;
    private static final byte FIELD_PRESENT = 0x02;

    private EventCodec() {
    }

    public static byte[] canonicalBytes(Event event) {
        requirePresent(event.eventId(), "eventId");
        requirePresent(event.eventType(), "eventType");
        requirePresent(event.previousHash(), "previousHash");
        requirePresent(event.payloadHash(), "payloadHash");
        requirePresent(event.lawVersion(), "lawVersion");
        requirePresent(event.actorId(), "actorId");

        ByteArrayOutputStream output = new ByteArrayOutputStream();
        output.writeBytes(FORMAT_MARKER);
        writeString(output, event.eventId());
        writeString(output, event.eventType());
        writeString(output, event.previousHash());
        writeString(output, event.payloadHash());
        writeString(output, event.lawVersion());
        writeString(output, event.actorId());
        writeLong(output, event.timeValue());
        return output.toByteArray();
    }

    public static String eventHash(Event event) {
        return sha256Hex(canonicalBytes(event));
    }

    public static String payloadHash(byte[] payloadBytes) {
        return sha256Hex(payloadBytes);
    }

    private static void requirePresent(String value, String fieldName) {
        if (value == null) {
            throw new IllegalArgumentException(fieldName + " must be present");
        }
    }

    private static void writeString(ByteArrayOutputStream output, String value) {
        if (value == null) {
            output.write(FIELD_NULL);
            return;
        }
        output.write(FIELD_PRESENT);
        byte[] utf8 = value.getBytes(StandardCharsets.UTF_8);
        output.writeBytes(intBytes(utf8.length));
        output.writeBytes(utf8);
    }

    private static void writeLong(ByteArrayOutputStream output, long value) {
        output.writeBytes(ByteBuffer.allocate(Long.BYTES).order(ByteOrder.BIG_ENDIAN).putLong(value).array());
    }

    private static byte[] intBytes(int value) {
        return ByteBuffer.allocate(Integer.BYTES).order(ByteOrder.BIG_ENDIAN).putInt(value).array();
    }

    private static String sha256Hex(byte[] input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input);
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte b : hash) {
                hex.append(Character.forDigit((b >>> 4) & 0x0F, 16));
                hex.append(Character.forDigit(b & 0x0F, 16));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }
}
