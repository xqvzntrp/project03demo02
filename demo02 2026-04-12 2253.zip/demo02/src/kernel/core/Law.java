package kernel.core;

public interface Law {
    String version();

    ReplayResult apply(ReplayState state, VerifiedEvent event);
}
