package kernel.core;

public record StoredEvent(Event event, String eventHash) {
}
