package kernel.core;

record VerifiedTransportEvent(
    String eventHash,
    Event event,
    byte[] payloadBytes
) implements VerifiedEvent {
    VerifiedTransportEvent {
        payloadBytes = payloadBytes == null ? null : payloadBytes.clone();
    }

    @Override
    public String eventId() {
        return event.eventId();
    }

    @Override
    public String eventType() {
        return event.eventType();
    }

    @Override
    public String previousHash() {
        return event.previousHash();
    }

    @Override
    public String payloadHash() {
        return event.payloadHash();
    }

    @Override
    public String lawVersion() {
        return event.lawVersion();
    }

    @Override
    public String actorId() {
        return event.actorId();
    }

    @Override
    public long timeValue() {
        return event.timeValue();
    }

    @Override
    public byte[] payloadBytes() {
        return payloadBytes == null ? null : payloadBytes.clone();
    }
}
