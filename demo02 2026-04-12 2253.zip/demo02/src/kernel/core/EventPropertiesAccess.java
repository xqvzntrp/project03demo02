package kernel.core;

import java.util.Properties;

public final class EventPropertiesAccess {
    private EventPropertiesAccess() {
    }

    public static Event readFromProperties(Properties properties) {
        return new Event(
            required(properties, "eventId"),
            required(properties, "eventType"),
            properties.getProperty("previousHash"),
            required(properties, "payloadHash"),
            required(properties, "lawVersion"),
            required(properties, "actorId"),
            Long.parseLong(required(properties, "timeValue"))
        );
    }

    private static String required(Properties properties, String key) {
        String value = properties.getProperty(key);
        if (value == null) {
            throw new IllegalArgumentException("Missing required property: " + key);
        }
        return value;
    }
}
