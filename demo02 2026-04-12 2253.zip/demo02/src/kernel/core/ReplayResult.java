package kernel.core;

import java.util.List;

public record ReplayResult(
    ReplayState nextState,
    List<DerivedOutput> outputs
) {
    public ReplayResult {
        outputs = List.copyOf(outputs);
    }
}
