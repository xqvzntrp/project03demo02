package kernel.core;

import java.util.List;

public record ReplayRun(
    String lawVersion,
    ReplayState finalState,
    List<DerivedOutput> outputs
) {
    public ReplayRun {
        outputs = List.copyOf(outputs);
    }
}
