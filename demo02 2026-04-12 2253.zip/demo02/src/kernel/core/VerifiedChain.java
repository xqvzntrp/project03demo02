package kernel.core;

import java.util.List;

public final class VerifiedChain {
    private final List<VerifiedStoredEvent> events;

    VerifiedChain(List<VerifiedStoredEvent> events) {
        this.events = List.copyOf(events);
    }

    public List<VerifiedStoredEvent> events() {
        return events;
    }
}
