package kernel.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class PayloadCas {
    private PayloadCas() {
    }

    public static String store(Path payloadDir, byte[] payloadBytes) throws IOException {
        String payloadHash = EventCodec.payloadHash(payloadBytes);
        Path payloadPath = pathForHash(payloadDir, payloadHash);
        Files.createDirectories(payloadPath.getParent());
        Files.write(payloadPath, payloadBytes);
        return payloadHash;
    }

    public static byte[] read(Path payloadDir, String payloadHash) throws IOException {
        Path payloadPath = pathForHash(payloadDir, payloadHash);
        if (!Files.isRegularFile(payloadPath)) {
            throw new IllegalStateException("Missing payload for hash " + payloadHash + " at " + payloadPath);
        }
        return Files.readAllBytes(payloadPath);
    }

    public static Path pathForHash(Path payloadDir, String payloadHash) {
        return payloadDir.resolve(payloadHash + ".bin");
    }
}
