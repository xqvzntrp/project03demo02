package kernel.core;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class EventProperties {
    private EventProperties() {
    }

    public static void write(Path path, Event event) throws IOException {
        String eventHash = EventCodec.eventHash(event);
        Files.createDirectories(path.getParent());
        try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            writeLine(writer, "eventId", event.eventId());
            writeLine(writer, "eventType", event.eventType());
            writeLine(writer, "previousHash", event.previousHash());
            writeLine(writer, "payloadHash", event.payloadHash());
            writeLine(writer, "lawVersion", event.lawVersion());
            writeLine(writer, "actorId", event.actorId());
            writeLine(writer, "timeValue", Long.toString(event.timeValue()));
            writeLine(writer, "eventHash", eventHash);
        }
    }

    public static StoredEvent read(Path path) throws IOException {
        Properties properties = new Properties();
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            properties.load(reader);
        }

        Event event = EventPropertiesAccess.readFromProperties(properties);

        String storedHash = required(properties, "eventHash");
        String computedHash = EventCodec.eventHash(event);
        if (!storedHash.equals(computedHash)) {
            throw new IllegalStateException("Stored eventHash does not match canonical hash");
        }
        return new StoredEvent(event, storedHash);
    }

    private static String required(Properties properties, String key) {
        String value = properties.getProperty(key);
        if (value == null) {
            throw new IllegalArgumentException("Missing required property: " + key);
        }
        return value;
    }

    private static void writeLine(Writer writer, String key, String value) throws IOException {
        writer.write(escape(key));
        writer.write('=');
        if (value != null) {
            writer.write(escape(value));
        }
        writer.write('\n');
    }

    private static String escape(String value) {
        StringBuilder escaped = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            switch (ch) {
                case '\\':
                    escaped.append("\\\\");
                    break;
                case '\n':
                    escaped.append("\\n");
                    break;
                case '\r':
                    escaped.append("\\r");
                    break;
                case '\t':
                    escaped.append("\\t");
                    break;
                case '=':
                case ':':
                case '#':
                case '!':
                    escaped.append('\\').append(ch);
                    break;
                default:
                    escaped.append(ch);
                    break;
            }
        }
        return escaped.toString();
    }
}
