package kernel.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

public final class ChainVerifier {
    private ChainVerifier() {
    }

    public static void verify(Path eventDir, Path payloadDir) throws IOException {
        verifiedReplayChain(eventDir, payloadDir);
    }

    public static void verify(Path eventDir) throws IOException {
        verifiedChain(eventDir);
    }

    public static VerifiedReplayChain verifiedReplayChain(Path eventDir, Path payloadDir) throws IOException {
        if (!Files.isDirectory(payloadDir)) {
            throw new IllegalArgumentException("Payload directory does not exist: " + payloadDir);
        }
        return verifiedReplayChainInternal(eventDir, payloadDir);
    }

    public static VerifiedChain verifiedChain(Path eventDir) throws IOException {
        return verifiedChainInternal(eventDir);
    }

    private static VerifiedReplayChain verifiedReplayChainInternal(Path eventDir, Path payloadDir) throws IOException {
        List<VerifiedTransportEvent> verifiedEvents = verifiedTransportEvents(eventDir, payloadDir);
        return new VerifiedReplayChain(verifiedEvents.stream().map(event -> (VerifiedEvent) event).toList());
    }

    private static VerifiedChain verifiedChainInternal(Path eventDir) throws IOException {
        List<VerifiedTransportEvent> verifiedEvents = verifiedTransportEvents(eventDir, null);
        List<VerifiedStoredEvent> storedEvents = verifiedEvents.stream()
            .map(event -> new VerifiedStoredEvent(event.eventHash(), event.event()))
            .toList();
        return new VerifiedChain(storedEvents);
    }

    private static List<VerifiedTransportEvent> verifiedTransportEvents(Path eventDir, Path payloadDir) throws IOException {
        if (!Files.isDirectory(eventDir)) {
            throw new IllegalArgumentException("Event directory does not exist: " + eventDir);
        }

        List<Path> eventPaths = loadEventPaths(eventDir);
        if (eventPaths.isEmpty()) {
            throw new IllegalStateException("No event files found in: " + eventDir);
        }

        Map<String, VerifiedTransportEvent> eventsByHash = new HashMap<>();
        Map<String, String> childByParent = new HashMap<>();
        List<String> genesisHashes = new ArrayList<>();

        for (Path eventPath : eventPaths) {
            StoredEvent storedEvent = EventProperties.read(eventPath);
            String eventHash = storedEvent.eventHash();
            Event event = storedEvent.event();
            byte[] payloadBytes = null;

            if (payloadDir != null) {
                payloadBytes = verifyPayload(payloadDir, storedEvent);
            }

            VerifiedTransportEvent verifiedEvent = new VerifiedTransportEvent(eventHash, event, payloadBytes);
            VerifiedTransportEvent existing = eventsByHash.putIfAbsent(eventHash, verifiedEvent);
            if (existing != null) {
                throw new IllegalStateException("Duplicate event hash found: " + eventHash);
            }

            if (EventCodec.INITIAL_POINTER_SENTINEL.equals(event.previousHash())) {
                genesisHashes.add(eventHash);
                continue;
            }

            String previousHash = event.previousHash();
            if (previousHash == null || previousHash.isEmpty()) {
                throw new IllegalStateException("Non-genesis event has invalid previousHash: " + eventHash);
            }

            String existingChild = childByParent.putIfAbsent(previousHash, eventHash);
            if (existingChild != null) {
                throw new IllegalStateException(
                    "Parent hash " + previousHash + " is referenced by more than one child"
                );
            }
        }

        if (genesisHashes.size() != 1) {
            throw new IllegalStateException("Expected exactly one genesis event but found " + genesisHashes.size());
        }

        for (VerifiedTransportEvent verifiedEvent : eventsByHash.values()) {
            String previousHash = verifiedEvent.event().previousHash();
            if (!EventCodec.INITIAL_POINTER_SENTINEL.equals(previousHash) && !eventsByHash.containsKey(previousHash)) {
                throw new IllegalStateException(
                    "Event " + verifiedEvent.eventHash() + " references missing parent " + previousHash
                );
            }
        }

        Set<String> nonHeads = childByParent.keySet();
        List<String> heads = new ArrayList<>();
        for (String eventHash : eventsByHash.keySet()) {
            if (!nonHeads.contains(eventHash)) {
                heads.add(eventHash);
            }
        }
        if (heads.size() != 1) {
            throw new IllegalStateException("Expected exactly one head event but found " + heads.size());
        }

        String genesisHash = genesisHashes.getFirst();
        String currentHash = heads.getFirst();
        Set<String> visited = new HashSet<>();
        List<VerifiedTransportEvent> reversedChain = new ArrayList<>();

        while (true) {
            if (!visited.add(currentHash)) {
                throw new IllegalStateException("Cycle detected at event " + currentHash);
            }

            VerifiedTransportEvent verifiedEvent = eventsByHash.get(currentHash);
            if (verifiedEvent == null) {
                throw new IllegalStateException("Head walk reached missing event " + currentHash);
            }
            reversedChain.add(verifiedEvent);

            String previousHash = verifiedEvent.event().previousHash();
            if (EventCodec.INITIAL_POINTER_SENTINEL.equals(previousHash)) {
                if (!currentHash.equals(genesisHash)) {
                    throw new IllegalStateException("Head walk reached unexpected genesis event " + currentHash);
                }
                break;
            }

            currentHash = previousHash;
        }

        if (visited.size() != eventsByHash.size()) {
            throw new IllegalStateException("Chain does not cover all stored events");
        }

        Collections.reverse(reversedChain);
        return List.copyOf(reversedChain);
    }

    private static byte[] verifyPayload(Path payloadDir, StoredEvent storedEvent) throws IOException {
        String expectedPayloadHash = storedEvent.event().payloadHash();
        byte[] payloadBytes = PayloadCas.read(payloadDir, expectedPayloadHash);
        String actualPayloadHash = EventCodec.payloadHash(payloadBytes);
        if (!expectedPayloadHash.equals(actualPayloadHash)) {
            throw new IllegalStateException(
                "Payload hash mismatch for event "
                    + storedEvent.eventHash()
                    + ": expected "
                    + expectedPayloadHash
                    + " but found "
                    + actualPayloadHash
            );
        }
        return payloadBytes;
    }

    private static List<Path> loadEventPaths(Path eventDir) throws IOException {
        try (Stream<Path> stream = Files.list(eventDir)) {
            return stream
                .filter(Files::isRegularFile)
                .filter(path -> path.getFileName().toString().endsWith(".properties"))
                .sorted()
                .toList();
        }
    }
}
