package kernel.core;

public record Event(
    String eventId,
    String eventType,
    String previousHash,
    String payloadHash,
    String lawVersion,
    String actorId,
    long timeValue
) {
}
