package kernel.core;

import java.util.ArrayList;
import java.util.List;

public final class Replayer {
    public ReplayRun replay(VerifiedReplayChain source, Law law) {
        ReplayState state = ReplayState.initial();
        List<DerivedOutput> outputs = new ArrayList<>();

        for (VerifiedEvent event : (Iterable<VerifiedEvent>) source.stream()::iterator) {
            ensureLawVersionMatches(law, event);
            ReplayResult result = law.apply(state, event);
            state = result.nextState();
            outputs.addAll(result.outputs());
        }

        return new ReplayRun(law.version(), state, outputs);
    }

    public static final class CountingLaw implements Law {
        private final String version;

        public CountingLaw(String version) {
            this.version = version;
        }

        @Override
        public String version() {
            return version;
        }

        @Override
        public ReplayResult apply(ReplayState state, VerifiedEvent event) {
            return switch (event.eventType()) {
                case "DocumentCreated", "DocumentSigned" -> appendEvent(state, event);
                default -> throw new IllegalStateException(
                    "Selected law "
                        + version
                        + " does not support eventType "
                        + event.eventType()
                        + " for eventId "
                        + event.eventId()
                );
            };
        }

        private ReplayResult appendEvent(ReplayState state, VerifiedEvent event) {
            List<String> appliedEventIds = new ArrayList<>(state.appliedEventIds());
            appliedEventIds.add(event.eventId());
            ReplayState nextState = new ReplayState(
                appliedEventIds,
                state.eventCount() + 1,
                state.totalPayloadBytes() + event.payloadBytes().length,
                event.eventId()
            );
            DerivedOutput output = new DerivedOutput(
                "event-applied",
                event.eventId(),
                event.eventType()
            );
            return new ReplayResult(nextState, List.of(output));
        }
    }

    private void ensureLawVersionMatches(Law law, VerifiedEvent event) {
        String eventLawVersion = event.lawVersion();
        if (!law.version().equals(eventLawVersion)) {
            throw new IllegalStateException(
                "Replay law version "
                    + law.version()
                    + " does not match event law version "
                    + eventLawVersion
                    + " for eventId "
                    + event.eventId()
            );
        }
    }
}
