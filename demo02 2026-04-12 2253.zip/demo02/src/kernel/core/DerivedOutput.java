package kernel.core;

public record DerivedOutput(
    String kind,
    String eventId,
    String value
) {
}
