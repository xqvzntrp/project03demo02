package kernel.core;

public sealed interface VerifiedEvent permits VerifiedTransportEvent {
    String eventId();

    String eventType();

    String previousHash();

    String payloadHash();

    String lawVersion();

    String actorId();

    long timeValue();

    byte[] payloadBytes();
}
