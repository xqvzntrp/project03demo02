package kernel.domain.spi;

import java.util.List;

import kernel.core.Law;

public interface MiniCorePlugin {
    String pluginId();

    String displayName();

    Law law();

    UnderstandingAdapter understandingAdapter();

    default List<DemoEventSpec> demoEvents() {
        return List.of();
    }
}
