package kernel.domain.spi;

import java.util.List;

public record UnderstandingSection(
    String title,
    List<String> lines
) {
    public UnderstandingSection {
        lines = List.copyOf(lines);
    }
}
