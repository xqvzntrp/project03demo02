package kernel.domain.spi;

import java.io.PrintStream;

import kernel.core.ReplayRun;

public interface Wrapper {
    String mode();

    int run(ReplayRun replayRun, UnderstandingView understandingView, PrintStream out, PrintStream err);
}
