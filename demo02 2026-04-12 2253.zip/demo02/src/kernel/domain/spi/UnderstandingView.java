package kernel.domain.spi;

import java.util.List;

public record UnderstandingView(
    List<UnderstandingSection> sections
) {
    public UnderstandingView {
        sections = List.copyOf(sections);
    }

    public UnderstandingView(
        List<String> concepts,
        List<String> observations,
        List<String> questions,
        List<String> nextSteps
    ) {
        this(List.of(
            section("concepts", concepts),
            section("observations", observations),
            section("questions", questions),
            section("nextSteps", nextSteps)
        ));
    }

    public List<String> concepts() {
        return sectionLines("concepts");
    }

    public List<String> observations() {
        return sectionLines("observations");
    }

    public List<String> questions() {
        return sectionLines("questions");
    }

    public List<String> nextSteps() {
        return sectionLines("nextSteps");
    }

    public List<String> sectionLines(String title) {
        for (UnderstandingSection section : sections) {
            if (section.title().equals(title)) {
                return section.lines();
            }
        }
        return List.of();
    }

    public static UnderstandingSection section(String title, List<String> lines) {
        return new UnderstandingSection(title, lines);
    }
}
