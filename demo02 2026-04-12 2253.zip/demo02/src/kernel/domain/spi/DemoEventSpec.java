package kernel.domain.spi;

import java.util.Arrays;

public record DemoEventSpec(
    String eventType,
    byte[] payloadBytes,
    String actorId,
    long timeValue
) {
    public DemoEventSpec {
        payloadBytes = Arrays.copyOf(payloadBytes, payloadBytes.length);
    }

    @Override
    public byte[] payloadBytes() {
        return Arrays.copyOf(payloadBytes, payloadBytes.length);
    }
}
