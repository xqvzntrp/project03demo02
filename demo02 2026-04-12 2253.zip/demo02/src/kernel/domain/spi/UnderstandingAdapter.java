package kernel.domain.spi;

import kernel.core.ReplayRun;

public interface UnderstandingAdapter {
    UnderstandingView understand(ReplayRun replayRun);
}
