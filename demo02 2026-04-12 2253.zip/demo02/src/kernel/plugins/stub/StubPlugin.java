package kernel.plugins.stub;

import java.util.List;

import kernel.core.DerivedOutput;
import kernel.core.Law;
import kernel.core.ReplayRun;
import kernel.core.ReplayResult;
import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;
import kernel.domain.spi.MiniCorePlugin;
import kernel.domain.spi.UnderstandingAdapter;
import kernel.domain.spi.UnderstandingView;

public final class StubPlugin implements MiniCorePlugin {
    private static final Law STUB_LAW = new Law() {
        @Override
        public String version() {
            return "stub-law-v1";
        }

        @Override
        public ReplayResult apply(ReplayState state, VerifiedEvent event) {
            ReplayState nextState = new ReplayState(
                append(state.appliedEventIds(), event.eventId()),
                state.eventCount() + 1,
                state.totalPayloadBytes() + event.payloadBytes().length,
                event.eventId()
            );
            DerivedOutput output = new DerivedOutput("stub-event-applied", event.eventId(), event.eventType());
            return new ReplayResult(nextState, List.of(output));
        }
    };

    private static final UnderstandingAdapter STUB_UNDERSTANDING = replayRun -> new UnderstandingView(
        List.of(
            "Plugins can contribute a law and a teaching surface without changing the kernel",
            "Teaching is derived from replay output, not from hidden mutable state"
        ),
        List.of(
            "Replay event count: " + replayRun.finalState().eventCount(),
            "Replay output count: " + replayRun.outputs().size()
        ),
        List.of(
            "Does plugin loading work end to end?",
            "Can the host ask the plugin for a teaching view?"
        ),
        List.of(
            "Replace this stub with a real domain plugin",
            "Add a replay entry point for teaching against real verified chains"
        )
    );

    @Override
    public String pluginId() {
        return "stub";
    }

    @Override
    public String displayName() {
        return "Stub Plugin";
    }

    @Override
    public Law law() {
        return STUB_LAW;
    }

    @Override
    public UnderstandingAdapter understandingAdapter() {
        return STUB_UNDERSTANDING;
    }

    private static List<String> append(List<String> appliedEventIds, String eventId) {
        java.util.ArrayList<String> next = new java.util.ArrayList<>(appliedEventIds);
        next.add(eventId);
        return List.copyOf(next);
    }
}
