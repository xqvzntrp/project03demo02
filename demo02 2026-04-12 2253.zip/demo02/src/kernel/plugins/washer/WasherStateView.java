package kernel.plugins.washer;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;

record WasherStateView(
    String cycle,
    String phase,
    List<String> eventIds
) {
    private static final String PREFIX = "WASHER_STATE:";

    static WasherStateView from(ReplayState state) {
        if (state.eventCount() == 0) {
            return new WasherStateView(null, null, List.of());
        }
        if (state.appliedEventIds().isEmpty()) {
            throw new IllegalStateException("ReplayState is missing washer state marker");
        }

        String marker = state.appliedEventIds().getFirst();
        if (!marker.startsWith(PREFIX)) {
            throw new IllegalStateException("ReplayState marker is invalid: " + marker);
        }

        String[] parts = marker.substring(PREFIX.length()).split("\\|", -1);
        if (parts.length != 2) {
            throw new IllegalStateException("ReplayState marker is malformed: " + marker);
        }

        return new WasherStateView(
            decodeNullable(parts[0]),
            decodeNullable(parts[1]),
            List.copyOf(state.appliedEventIds().subList(1, state.appliedEventIds().size()))
        );
    }

    boolean hasCycle() {
        return cycle != null;
    }

    ReplayState next(String cycle, String phase, VerifiedEvent event, ReplayState priorState) {
        List<String> nextEntries = new ArrayList<>();
        nextEntries.add(PREFIX + encodeNullable(cycle) + "|" + encodeNullable(phase));
        nextEntries.addAll(eventIds);
        nextEntries.add(event.eventId());
        return new ReplayState(
            nextEntries,
            priorState.eventCount() + 1,
            priorState.totalPayloadBytes() + event.payloadBytes().length,
            event.eventId()
        );
    }

    private static String encodeNullable(String value) {
        return value == null ? "" : Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String decodeNullable(String value) {
        return value == null || value.isEmpty()
            ? null
            : new String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8);
    }
}
