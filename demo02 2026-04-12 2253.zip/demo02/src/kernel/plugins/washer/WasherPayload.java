package kernel.plugins.washer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

record WasherPayload(String cycle) {
    static WasherPayload cycleSelected(String cycle) {
        return new WasherPayload(cycle);
    }

    static WasherPayload empty() {
        return new WasherPayload(null);
    }

    static WasherPayload fromBytes(byte[] payloadBytes) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(payloadBytes), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse washer payload", e);
        }
        String cycle = properties.getProperty("cycle");
        return new WasherPayload(cycle == null || cycle.isEmpty() ? null : cycle);
    }

    byte[] toBytes() {
        StringWriter writer = new StringWriter();
        if (cycle != null) {
            writer.write("cycle=");
            writer.write(escape(cycle));
            writer.write('\n');
        }
        return writer.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static String escape(String value) {
        StringBuilder escaped = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            switch (ch) {
                case '\\' -> escaped.append("\\\\");
                case '\n' -> escaped.append("\\n");
                case '\r' -> escaped.append("\\r");
                case '\t' -> escaped.append("\\t");
                case '=', ':', '#', '!' -> escaped.append('\\').append(ch);
                default -> escaped.append(ch);
            }
        }
        return escaped.toString();
    }
}
