package kernel.plugins.washer;

import java.util.List;

import kernel.core.DerivedOutput;
import kernel.core.Law;
import kernel.core.ReplayResult;
import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;

public final class WasherLaw implements Law {
    public static final String VERSION = "washer-law-v1";

    @Override
    public String version() {
        return VERSION;
    }

    @Override
    public ReplayResult apply(ReplayState state, VerifiedEvent event) {
        WasherStateView current = WasherStateView.from(state);
        WasherPayload payload = WasherPayload.fromBytes(event.payloadBytes());

        return switch (event.eventType()) {
            case "WasherCycleSelected" -> applyCycleSelected(state, current, payload, event);
            case "WasherStarted" -> applyStarted(state, current, event);
            case "WasherAdvanced" -> applyAdvanced(state, current, event);
            default -> throw new IllegalStateException("Unsupported washer eventType: " + event.eventType());
        };
    }

    private ReplayResult applyCycleSelected(
        ReplayState state,
        WasherStateView current,
        WasherPayload payload,
        VerifiedEvent event
    ) {
        if (current.hasCycle()) {
            throw new IllegalStateException("WasherCycleSelected is only valid before a cycle is chosen");
        }
        if (payload.cycle() == null) {
            throw new IllegalStateException("WasherCycleSelected requires cycle payload");
        }
        ReplayState nextState = current.next(payload.cycle(), "READY", event, state);
        return new ReplayResult(nextState, List.of(output("washer-cycle", event, payload.cycle())));
    }

    private ReplayResult applyStarted(ReplayState state, WasherStateView current, VerifiedEvent event) {
        if (!current.hasCycle()) {
            throw new IllegalStateException("WasherStarted requires a selected cycle");
        }
        if (!"READY".equals(current.phase())) {
            throw new IllegalStateException("WasherStarted is invalid from phase " + current.phase());
        }
        ReplayState nextState = current.next(current.cycle(), "WASH", event, state);
        return new ReplayResult(nextState, List.of(output("washer-phase", event, "WASH")));
    }

    private ReplayResult applyAdvanced(ReplayState state, WasherStateView current, VerifiedEvent event) {
        if (!current.hasCycle()) {
            throw new IllegalStateException("WasherAdvanced requires a selected cycle");
        }
        String nextPhase = switch (current.phase()) {
            case "WASH" -> "RINSE";
            case "RINSE" -> "SPIN";
            case "SPIN" -> "DONE";
            default -> throw new IllegalStateException("WasherAdvanced is invalid from phase " + current.phase());
        };
        ReplayState nextState = current.next(current.cycle(), nextPhase, event, state);
        return new ReplayResult(nextState, List.of(output("washer-phase", event, nextPhase)));
    }

    private DerivedOutput output(String kind, VerifiedEvent event, String value) {
        return new DerivedOutput(kind, event.eventId(), value);
    }
}
