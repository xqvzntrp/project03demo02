package kernel.plugins.washer;

import java.util.List;

import kernel.core.ReplayRun;
import kernel.domain.spi.UnderstandingAdapter;
import kernel.domain.spi.UnderstandingView;

public final class WasherUnderstandingAdapter implements UnderstandingAdapter {
    @Override
    public UnderstandingView understand(ReplayRun replayRun) {
        WasherStateView state = WasherStateView.from(replayRun.finalState());
        String phase = state.phase() == null ? "not started" : state.phase();

        return new UnderstandingView(
            List.of(
                "A wash cycle is a predefined sequence",
                "The law carries the progression order: READY -> WASH -> RINSE -> SPIN -> DONE",
                "Teaching is grounded in replayed truth, not a separate tutorial state"
            ),
            List.of(
                "Current cycle: " + (state.cycle() == null ? "none" : state.cycle()),
                "Current phase: " + phase,
                "Replay event count: " + replayRun.finalState().eventCount()
            ),
            List.of(
                "What phase comes after " + phase + "?",
                "What would happen if the machine advanced once more from here?"
            ),
            List.of(
                "Try comparing READY to WASH to see where motion begins",
                "Later we can test whether every phase distinction needs to remain in state"
            )
        );
    }
}
