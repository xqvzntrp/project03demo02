package kernel.plugins.washer;

import java.util.List;

import kernel.core.Law;
import kernel.domain.spi.DemoEventSpec;
import kernel.domain.spi.MiniCorePlugin;
import kernel.domain.spi.UnderstandingAdapter;

public final class WasherPlugin implements MiniCorePlugin {
    private static final Law LAW = new WasherLaw();
    private static final UnderstandingAdapter UNDERSTANDING = new WasherUnderstandingAdapter();

    @Override
    public String pluginId() {
        return "washer";
    }

    @Override
    public String displayName() {
        return "Washer Demo";
    }

    @Override
    public Law law() {
        return LAW;
    }

    @Override
    public UnderstandingAdapter understandingAdapter() {
        return UNDERSTANDING;
    }

    @Override
    public List<DemoEventSpec> demoEvents() {
        return List.of(
            new DemoEventSpec("WasherCycleSelected", WasherPayload.cycleSelected("NORMAL").toBytes(), "alex", 1L),
            new DemoEventSpec("WasherStarted", WasherPayload.empty().toBytes(), "alex", 2L),
            new DemoEventSpec("WasherAdvanced", WasherPayload.empty().toBytes(), "alex", 3L),
            new DemoEventSpec("WasherAdvanced", WasherPayload.empty().toBytes(), "alex", 4L)
        );
    }
}
