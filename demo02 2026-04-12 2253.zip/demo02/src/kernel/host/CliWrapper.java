package kernel.host;

import java.io.PrintStream;

import kernel.core.ReplayRun;
import kernel.domain.spi.UnderstandingView;
import kernel.domain.spi.Wrapper;

public final class CliWrapper implements Wrapper {
    @Override
    public String mode() {
        return "cli";
    }

    @Override
    public int run(ReplayRun replayRun, UnderstandingView understandingView, PrintStream out, PrintStream err) {
        out.println("REPLAY");
        out.println("  law version: " + replayRun.lawVersion());
        out.println("  event count: " + replayRun.finalState().eventCount());
        out.println("  last event id: " + replayRun.finalState().lastEventId());
        printSection(out, "UNDERSTANDING", "concepts", understandingView.concepts());
        printSection(out, null, "observations", understandingView.observations());
        printSection(out, null, "questions", understandingView.questions());
        printSection(out, null, "next steps", understandingView.nextSteps());
        return 0;
    }

    private static void printSection(PrintStream out, String title, String label, java.util.List<String> lines) {
        if (title != null) {
            out.println(title);
        }
        out.println("  " + label + ":");
        if (lines.isEmpty()) {
            out.println("    -");
            return;
        }
        for (String line : lines) {
            out.println("    - " + line);
        }
    }
}
