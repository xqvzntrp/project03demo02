package kernel.host;

import java.io.PrintStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.ServiceLoader;

import kernel.core.ChainVerifier;
import kernel.core.Event;
import kernel.core.EventCodec;
import kernel.core.EventProperties;
import kernel.core.PayloadCas;
import kernel.core.ReplayRun;
import kernel.core.ReplayState;
import kernel.core.Replayer;
import kernel.domain.spi.DemoEventSpec;
import kernel.domain.spi.MiniCorePlugin;
import kernel.domain.spi.UnderstandingView;
import kernel.domain.spi.Wrapper;

public final class MiniCoreHost {
    private MiniCoreHost() {
    }

    public static void main(String[] args) {
        int exitCode = runWrapped(args, System.out, System.err);
        if (exitCode != 0) {
            System.exit(exitCode);
        }
    }

    public static int run(String[] args, PrintStream out, PrintStream err) {
        if (args.length > 0) {
            err.println("error=MiniCoreHost does not accept arguments yet");
            return 1;
        }

        out.println("Discovered plugins:");
        int count = 0;
        for (MiniCorePlugin plugin : ServiceLoader.load(MiniCorePlugin.class)) {
            count++;
            out.println("- " + plugin.pluginId() + ": " + plugin.displayName());
            out.println("  lawVersion: " + plugin.law().version());
            ReplayRun replayRun = replayRunFor(plugin);
            out.println("  finalEventCount: " + replayRun.finalState().eventCount());
            out.println("  lastEventId: " + replayRun.finalState().lastEventId());
            printPreview(out, plugin.understandingAdapter().understand(replayRun));
        }

        if (count == 0) {
            out.println("  (none)");
        }
        return 0;
    }

    public static int runWrapped(String[] args, PrintStream out, PrintStream err) {
        if (args.length > 0) {
            err.println("error=Wrapper mode does not accept arguments yet");
            return 1;
        }

        Wrapper wrapper = new CliWrapper();
        out.println("Wrapper mode: " + wrapper.mode());
        int count = 0;
        for (MiniCorePlugin plugin : ServiceLoader.load(MiniCorePlugin.class)) {
            count++;
            ReplayRun replayRun = replayRunFor(plugin);
            UnderstandingView understandingView = plugin.understandingAdapter().understand(replayRun);
            out.println("PLUGIN");
            out.println("  id: " + plugin.pluginId());
            out.println("  name: " + plugin.displayName());
            int exitCode = wrapper.run(replayRun, understandingView, out, err);
            if (exitCode != 0) {
                return exitCode;
            }
        }

        if (count == 0) {
            out.println("No plugins discovered");
        }
        return 0;
    }

    private static void printPreview(PrintStream out, UnderstandingView view) {
        printSection(out, "concepts", view.concepts());
        printSection(out, "observations", view.observations());
        printSection(out, "questions", view.questions());
        printSection(out, "nextSteps", view.nextSteps());
    }

    private static ReplayRun replayRunFor(MiniCorePlugin plugin) {
        List<DemoEventSpec> demoEvents = plugin.demoEvents();
        if (demoEvents.isEmpty()) {
            return new ReplayRun(plugin.law().version(), ReplayState.initial(), List.of());
        }

        try {
            Path rootDir = Path.of("build", "plugin-host", plugin.pluginId());
            resetRoot(rootDir);
            Path eventDir = rootDir.resolve("events");
            Path payloadDir = rootDir.resolve("payloads");
            Files.createDirectories(eventDir);
            Files.createDirectories(payloadDir);

            String previousHash = EventCodec.INITIAL_POINTER_SENTINEL;
            for (int i = 0; i < demoEvents.size(); i++) {
                DemoEventSpec spec = demoEvents.get(i);
                String eventId = "evt-" + String.format("%06d", i + 1);
                String payloadHash = PayloadCas.store(payloadDir, spec.payloadBytes());
                Event event = new Event(
                    eventId,
                    spec.eventType(),
                    previousHash,
                    payloadHash,
                    plugin.law().version(),
                    spec.actorId(),
                    spec.timeValue()
                );
                String eventHash = EventCodec.eventHash(event);
                EventProperties.write(eventDir.resolve(eventHash + ".properties"), event);
                previousHash = eventHash;
            }

            return new Replayer().replay(ChainVerifier.verifiedReplayChain(eventDir, payloadDir), plugin.law());
        } catch (Exception e) {
            throw new IllegalStateException("Unable to run demo events for plugin " + plugin.pluginId(), e);
        }
    }

    private static void resetRoot(Path rootDir) throws IOException {
        if (!Files.exists(rootDir)) {
            return;
        }
        try (java.util.stream.Stream<Path> stream = Files.walk(rootDir)) {
            stream.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.delete(path);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }

    private static void printSection(PrintStream out, String label, java.util.List<String> lines) {
        out.println("  " + label + ":");
        if (lines.isEmpty()) {
            out.println("    -");
            return;
        }
        for (String line : lines) {
            out.println("    - " + line);
        }
    }
}
