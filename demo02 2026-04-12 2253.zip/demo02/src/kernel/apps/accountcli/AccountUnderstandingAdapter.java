package kernel.apps.accountcli;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Function;
import java.util.stream.Collectors;

import kernel.core.DerivedOutput;
import kernel.core.ReplayRun;
import kernel.core.VerifiedEvent;
import kernel.domain.spi.UnderstandingView;
import kernel.laws.account.AccountStateView;

final class AccountUnderstandingAdapter {
    private AccountUnderstandingAdapter() {
    }

    static UnderstandingView understand(AccountStateView state, ReplayRun replayRun, List<VerifiedEvent> verifiedEvents) {
        Map<String, VerifiedEvent> eventsById = verifiedEvents.stream()
            .collect(Collectors.toMap(VerifiedEvent::eventId, Function.identity(), (left, right) -> left, LinkedHashMap::new));
        Map<String, DerivedOutput> outputsByEventId = replayRun.outputs().stream()
            .collect(Collectors.toMap(DerivedOutput::eventId, Function.identity(), (left, right) -> left, LinkedHashMap::new));
        VerifiedEvent lastMeaningfulEvent = findLastMeaningfulEvent(verifiedEvents, outputsByEventId);
        VerifiedEvent latestOverdraftEvent = findLatestEventByOutput(replayRun.outputs(), eventsById, "overdraft-attempted");
        VerifiedEvent closedEvent = findLatestEvent(verifiedEvents, "AccountClosed");
        VerifiedEvent recoveryEvent = latestOverdraftEvent == null
            ? null
            : findFirstRecoveryEventAfter(verifiedEvents, outputsByEventId, latestOverdraftEvent.eventId());

        List<String> stateLines = new ArrayList<>();
        stateLines.add("  account: " + state.accountId());
        stateLines.add("  status: " + state.status());
        stateLines.add("  balance: " + state.balance());
        if (lastMeaningfulEvent != null) {
            stateLines.add("  last change: " + humanLastChange(lastMeaningfulEvent, outputsByEventId));
        }
        stateLines.add("  event count: " + replayRun.finalState().eventCount());
        stateLines.add("  last event id: " + replayRun.finalState().lastEventId());

        List<String> whyLines = new ArrayList<>();
        if (closedEvent != null) {
            whyLines.add("  account closed: by " + closedEvent.actorId() + " at " + closedEvent.timeValue());
            whyLines.add("  balance frozen at: " + state.balance());
            if (latestOverdraftEvent != null) {
                whyLines.add("  earlier rejected withdrawal: " + amount(latestOverdraftEvent) + " by "
                    + latestOverdraftEvent.actorId() + " at " + latestOverdraftEvent.timeValue());
                if (recoveryEvent != null) {
                    whyLines.add("  recovered by: " + humanRecovery(recoveryEvent));
                }
            }
        } else if (latestOverdraftEvent != null && isLatestEvent(verifiedEvents, latestOverdraftEvent)) {
            whyLines.add("  rejected withdrawal: by " + latestOverdraftEvent.actorId() + " at " + latestOverdraftEvent.timeValue());
            whyLines.add("  requested: " + amount(latestOverdraftEvent));
            whyLines.add("  balance stayed: " + state.balance());
        } else if (latestOverdraftEvent != null) {
            whyLines.add("  earlier rejected withdrawal: " + amount(latestOverdraftEvent) + " by "
                + latestOverdraftEvent.actorId() + " at " + latestOverdraftEvent.timeValue());
            if (recoveryEvent != null) {
                whyLines.add("  recovered by: " + humanRecovery(recoveryEvent));
            } else {
                whyLines.add("  no later recovery event");
            }
        } else {
            whyLines.add("  no anomaly or closure");
        }

        List<String> pathLines = List.of("  " + String.join(" -> ", summarizedPath(verifiedEvents, outputsByEventId)));

        List<String> traceLines = new ArrayList<>();
        for (String eventId : state.eventIds()) {
            VerifiedEvent event = eventsById.get(eventId);
            if (event != null) {
                traceLines.add("  [" + event.eventId() + "] " + humanTrace(event, outputsByEventId));
            }
        }

        List<String> outputLines = new ArrayList<>();
        for (DerivedOutput output : replayRun.outputs()) {
            outputLines.add("  - " + output.kind() + " eventId=" + output.eventId() + " value=" + output.value());
        }

        return new UnderstandingView(List.of(
            UnderstandingView.section("STATE", stateLines),
            UnderstandingView.section("WHY", whyLines),
            UnderstandingView.section("PATH", pathLines),
            UnderstandingView.section("TRACE", traceLines),
            UnderstandingView.section("OUTPUTS", outputLines)
        ));
    }

    private static VerifiedEvent findLastMeaningfulEvent(List<VerifiedEvent> verifiedEvents, Map<String, DerivedOutput> outputsByEventId) {
        for (int i = verifiedEvents.size() - 1; i >= 0; i--) {
            VerifiedEvent event = verifiedEvents.get(i);
            DerivedOutput output = outputsByEventId.get(event.eventId());
            if (output == null || !"overdraft-attempted".equals(output.kind())) {
                return event;
            }
        }
        return null;
    }

    private static VerifiedEvent findLatestEventByOutput(List<DerivedOutput> outputs, Map<String, VerifiedEvent> eventsById, String kind) {
        for (int i = outputs.size() - 1; i >= 0; i--) {
            DerivedOutput output = outputs.get(i);
            if (kind.equals(output.kind())) {
                return eventsById.get(output.eventId());
            }
        }
        return null;
    }

    private static VerifiedEvent findLatestEvent(List<VerifiedEvent> verifiedEvents, String eventType) {
        for (int i = verifiedEvents.size() - 1; i >= 0; i--) {
            VerifiedEvent event = verifiedEvents.get(i);
            if (eventType.equals(event.eventType())) {
                return event;
            }
        }
        return null;
    }

    private static boolean isLatestEvent(List<VerifiedEvent> verifiedEvents, VerifiedEvent event) {
        return !verifiedEvents.isEmpty() && verifiedEvents.getLast().eventId().equals(event.eventId());
    }

    private static VerifiedEvent findFirstRecoveryEventAfter(
        List<VerifiedEvent> verifiedEvents,
        Map<String, DerivedOutput> outputsByEventId,
        String eventId
    ) {
        boolean foundTarget = false;
        for (VerifiedEvent event : verifiedEvents) {
            if (!foundTarget) {
                foundTarget = event.eventId().equals(eventId);
                continue;
            }
            if ("AccountClosed".equals(event.eventType())) {
                continue;
            }
            if (!isOverdraft(event, outputsByEventId)) {
                return event;
            }
        }
        return null;
    }

    private static List<String> summarizedPath(List<VerifiedEvent> verifiedEvents, Map<String, DerivedOutput> outputsByEventId) {
        List<String> path = new ArrayList<>();
        for (VerifiedEvent event : verifiedEvents) {
            path.add(summarize(event, outputsByEventId));
        }
        return path;
    }

    private static String summarize(VerifiedEvent event, Map<String, DerivedOutput> outputsByEventId) {
        return switch (event.eventType()) {
            case "AccountOpened" -> "Opened";
            case "FundsDeposited" -> "Deposited " + amount(event);
            case "FundsWithdrawn" -> isOverdraft(event, outputsByEventId)
                ? "Withdrawal rejected " + amount(event)
                : "Withdrew " + amount(event);
            case "AccountClosed" -> "Closed";
            default -> event.eventType();
        };
    }

    private static String humanLastChange(VerifiedEvent event, Map<String, DerivedOutput> outputsByEventId) {
        return switch (event.eventType()) {
            case "AccountOpened" -> "opened by " + event.actorId() + " at " + event.timeValue();
            case "FundsDeposited" -> "deposited " + amount(event) + " by " + event.actorId() + " at " + event.timeValue();
            case "FundsWithdrawn" -> (isOverdraft(event, outputsByEventId) ? "withdrawal rejected " : "withdrew ")
                + amount(event) + " by " + event.actorId() + " at " + event.timeValue();
            case "AccountClosed" -> "closed by " + event.actorId() + " at " + event.timeValue();
            default -> event.eventType() + " by " + event.actorId() + " at " + event.timeValue();
        };
    }

    private static String humanTrace(VerifiedEvent event, Map<String, DerivedOutput> outputsByEventId) {
        return switch (event.eventType()) {
            case "AccountOpened" -> "opened by " + event.actorId() + " at " + event.timeValue();
            case "FundsDeposited" -> "deposited " + amount(event) + " by " + event.actorId() + " at " + event.timeValue();
            case "FundsWithdrawn" -> isOverdraft(event, outputsByEventId)
                ? "withdrawal attempted " + amount(event) + " by " + event.actorId() + " at " + event.timeValue() + " (rejected)"
                : "withdrew " + amount(event) + " by " + event.actorId() + " at " + event.timeValue();
            case "AccountClosed" -> "closed by " + event.actorId() + " at " + event.timeValue();
            default -> event.eventType() + " by " + event.actorId() + " at " + event.timeValue();
        };
    }

    private static boolean isOverdraft(VerifiedEvent event, Map<String, DerivedOutput> outputsByEventId) {
        DerivedOutput output = outputsByEventId.get(event.eventId());
        return output != null && "overdraft-attempted".equals(output.kind());
    }

    private static String humanRecovery(VerifiedEvent event) {
        return switch (event.eventType()) {
            case "FundsDeposited" -> "deposited " + amount(event) + " by " + event.actorId() + " at " + event.timeValue();
            case "FundsWithdrawn" -> "withdrew " + amount(event) + " by " + event.actorId() + " at " + event.timeValue();
            case "AccountOpened" -> "opened by " + event.actorId() + " at " + event.timeValue();
            default -> event.eventType() + " by " + event.actorId() + " at " + event.timeValue();
        };
    }

    private static long amount(VerifiedEvent event) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(event.payloadBytes()), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse account payload for eventId " + event.eventId(), e);
        }
        return Long.parseLong(properties.getProperty("amount", "0"));
    }
}
