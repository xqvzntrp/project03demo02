package kernel.apps.accountcli;

import java.io.PrintStream;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import kernel.apps.flow.AccountFlowShell;
import kernel.apps.support.AppConventions;
import kernel.apps.support.RootDisplay;
import kernel.apps.support.ShowConventions;
import kernel.apps.support.UnderstandingRenderer;
import kernel.apps.support.WorkspaceRoots;
import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.VerifiedEvent;
import kernel.core.VerifiedReplayChain;
import kernel.domain.spi.UnderstandingView;
import kernel.laws.account.AccountEventWriter;
import kernel.laws.account.AccountLaw;
import kernel.laws.account.AccountStateView;
import kernel.laws.account.AccountStatus;

public final class AccountCli {
    private static final String LAW_VERSION = "account-law-v1";
    private static final String DEFAULT_ACTOR = "cli";
    private static final String DOMAIN = "account";

    private AccountCli() {
    }

    public static void main(String[] args) {
        int exitCode = run(args, System.out, System.err);
        if (exitCode != 0) {
            System.exit(exitCode);
        }
    }

    public static int run(String[] args, PrintStream out, PrintStream err) {
        try {
            if (args.length == 0 || isHelp(args[0])) {
                printUsage(out);
                return 0;
            }

            String command = args[0];
            if ("flow".equals(command)) {
                return runFlow(args, out, err);
            }

            Map<String, String> options = parseOptions(args);
            Path rootDir = Path.of(options.getOrDefault("root", AppConventions.defaultRoot(DOMAIN).toString()));
            out.println("Root: " + RootDisplay.concise(rootDir));
            AccountCliRepository repository = new AccountCliRepository(rootDir);

            switch (command) {
                case "open" -> open(repository, options, out);
                case "deposit" -> append(repository, options, "FundsDeposited", out);
                case "withdraw" -> append(repository, options, "FundsWithdrawn", out);
                case "close" -> close(repository, options, out);
                case "flow" -> throw new IllegalStateException("account flow should be handled before standard option parsing");
                case "list" -> {
                    requireOnlyOptions(options, "root");
                    list(rootDir, out);
                }
                case "next" -> {
                    requireOnlyOptions(options, "root");
                    next(repository, out);
                }
                case "verify" -> {
                    requireOnlyOptions(options, "root");
                    verify(repository, out);
                }
                case "show" -> {
                    requireOnlyOptions(options, "root");
                    show(repository, out);
                }
                default -> {
                    err.println("error=Unknown account command: " + command);
                    printUsage(err);
                    return 1;
                }
            }
            return 0;
        } catch (Exception e) {
            err.println("error=" + e.getMessage());
            return 1;
        }
    }

    public static String[] usageLines() {
        return new String[] {
            "account open --account <accountId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "account deposit --account <accountId> --amount <n> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "account withdraw --account <accountId> --amount <n> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "account close --account <accountId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "account flow [--root <dir> | --new]",
            "account list [--root <workspaceDir>]",
            "account next [--root <dir>]",
            "account verify [--root <dir>]",
            "account show [--root <dir>]"
        };
    }

    private static void open(AccountCliRepository repository, Map<String, String> options, PrintStream out) throws Exception {
        requireOnlyOptions(options, "account", "root", "actor", "time");
        String accountId = required(options, "account");
        AccountCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.isEmpty()) {
            throw new IllegalStateException("Account already exists at this root: " + repository.rootDir());
        }

        long timeValue = parseTime(options, 1L);
        AccountEventWriter.WrittenAccountEvent written = AccountEventWriter.write(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            "AccountOpened",
            EventCodec.INITIAL_POINTER_SENTINEL,
            accountId,
            0L,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("opened=true");
        out.println("eventHash=" + written.eventHash());
        out.println("accountId=" + accountId);
    }

    private static void append(AccountCliRepository repository, Map<String, String> options, String eventType, PrintStream out) throws Exception {
        requireOnlyOptions(options, "account", "amount", "root", "actor", "time");
        String accountId = required(options, "account");
        AccountCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            throw new IllegalStateException("Account chain does not exist at " + repository.rootDir());
        }

        AccountStateView currentState = currentAccountState(repository);
        requireMatchingAccountId(accountId, currentState);
        requireAllowedTransition(eventType, currentState);

        long amount = parseAmount(options);
        long timeValue = parseTime(options, chainState.eventCount() + 1L);
        AccountEventWriter.WrittenAccountEvent written = AccountEventWriter.write(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            eventType,
            chainState.headHash(),
            accountId,
            amount,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("appended=true");
        out.println("eventType=" + eventType);
        out.println("eventHash=" + written.eventHash());
        out.println("accountId=" + accountId);
        out.println("amount=" + amount);
    }

    private static void close(AccountCliRepository repository, Map<String, String> options, PrintStream out) throws Exception {
        requireOnlyOptions(options, "account", "root", "actor", "time");
        String accountId = required(options, "account");
        AccountCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            throw new IllegalStateException("Account chain does not exist at " + repository.rootDir());
        }

        AccountStateView currentState = currentAccountState(repository);
        requireMatchingAccountId(accountId, currentState);
        if (currentState.status() != AccountStatus.OPEN) {
            throw new IllegalStateException("AccountClosed requires status OPEN but found " + currentState.status());
        }

        long timeValue = parseTime(options, chainState.eventCount() + 1L);
        AccountEventWriter.WrittenAccountEvent written = AccountEventWriter.write(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            "AccountClosed",
            chainState.headHash(),
            accountId,
            0L,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("closed=true");
        out.println("eventHash=" + written.eventHash());
        out.println("accountId=" + accountId);
    }

    private static void verify(AccountCliRepository repository, PrintStream out) throws Exception {
        requireChainExists(repository, "account");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        int count = replayChain.stream().toList().size();
        out.println("verified=true");
        out.println("verifiedEventCount=" + count);
    }

    private static void next(AccountCliRepository repository, PrintStream out) throws Exception {
        out.println("NEXT");
        List<String> commands = nextCommands(repository);
        if (commands.isEmpty()) {
            out.println("  (no valid next events: account is " + currentAccountState(repository).status() + ")");
            return;
        }
        for (String command : commands) {
            out.println("  - " + command);
        }
    }

    public static List<String> nextCommands(Path rootDir) throws Exception {
        return nextCommands(new AccountCliRepository(rootDir));
    }

    public static List<AccountListEntry> listEntries(Path workspaceRoot) throws Exception {
        java.util.ArrayList<AccountListEntry> entries = new java.util.ArrayList<>();
        for (Path entityRoot : WorkspaceRoots.discoverEntityRoots(workspaceRoot)) {
            AccountCliRepository repository = new AccountCliRepository(entityRoot);
            AccountStateView state = currentAccountState(repository);
            entries.add(new AccountListEntry(entityRoot, state.accountId(), state.status(), state.balance()));
        }
        return List.copyOf(entries);
    }

    private static void list(Path workspaceRoot, PrintStream out) throws Exception {
        List<AccountListEntry> entries = listEntries(workspaceRoot);
        out.println("STATE");
        out.println("  accounts: " + entries.size());
        out.println("WHY");
        out.println("  discovered under: " + workspaceRoot);
        out.println("PATH");
        out.println("  current root + direct child roots with event histories");
        out.println("TRACE");
        for (AccountListEntry entry : entries) {
            out.println(
                "  [" + WorkspaceRoots.displayRoot(workspaceRoot, entry.rootDir()) + "] "
                    + entry.accountId() + " " + entry.status() + " balance=" + entry.balance()
            );
        }
        out.println("OUTPUTS");
        for (AccountListEntry entry : entries) {
            out.println("  - " + entry.showCommand(workspaceRoot));
        }
    }

    private static void show(AccountCliRepository repository, PrintStream out) throws Exception {
        requireChainExists(repository, "account");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        List<VerifiedEvent> verifiedEvents = replayChain.stream().toList();
        ReplayRun replayRun = new Replayer().replay(replayChain, new AccountLaw(LAW_VERSION));
        AccountStateView state = AccountStateView.from(replayRun.finalState());
        UnderstandingView understandingView = AccountUnderstandingAdapter.understand(state, replayRun, verifiedEvents);
        out.println(UnderstandingRenderer.render(understandingView));
    }

    private static ReplayRun replay(AccountCliRepository repository) throws Exception {
        requireChainExists(repository, "account");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        return new Replayer().replay(replayChain, new AccountLaw(LAW_VERSION));
    }

    private static List<String> nextCommands(AccountCliRepository repository) throws Exception {
        AccountCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            return List.of("account open --account <accountId>");
        }

        AccountStateView state = currentAccountState(repository);
        return switch (state.status()) {
            case OPEN -> List.of(
                "account deposit --account " + quote(state.accountId()) + " --amount <n>",
                "account withdraw --account " + quote(state.accountId()) + " --amount <n>",
                "account close --account " + quote(state.accountId())
            );
            case CLOSED -> List.of();
        };
    }

    private static int runFlow(String[] args, PrintStream out, PrintStream err) throws Exception {
        FlowRequest request = parseFlowRequest(args);
        if (request.usingNewRoot()) {
            out.println("Using new root: " + RootDisplay.concise(request.rootDir()));
        }
        out.println("Root: " + RootDisplay.concise(request.rootDir()));
        return AccountFlowShell.run(request.rootDir(), System.in, out, err);
    }

    private static AccountStateView currentAccountState(AccountCliRepository repository) throws Exception {
        return AccountStateView.from(replay(repository).finalState());
    }

    private static Map<String, String> parseOptions(String[] args) {
        java.util.HashMap<String, String> options = new java.util.HashMap<>();
        for (int i = 1; i < args.length; i++) {
            String token = args[i];
            if (!token.startsWith("--")) {
                throw new IllegalArgumentException("Expected option starting with -- but found: " + token);
            }
            String key = token.substring(2);
            if (i + 1 >= args.length) {
                throw new IllegalArgumentException("Missing value for option --" + key);
            }
            options.put(key, args[++i]);
        }
        return options;
    }

    private static FlowRequest parseFlowRequest(String[] args) throws Exception {
        Path rootDir = null;
        boolean usingNewRoot = false;

        for (int i = 1; i < args.length; i++) {
            String token = args[i];
            if ("--new".equals(token)) {
                usingNewRoot = true;
                continue;
            }
            if ("--root".equals(token)) {
                if (i + 1 >= args.length) {
                    throw new IllegalArgumentException("Missing value for option --root");
                }
                rootDir = Path.of(args[++i]);
                continue;
            }
            if (token.startsWith("--")) {
                throw new IllegalArgumentException("Unsupported option for account flow: " + token);
            }
            throw new IllegalArgumentException("Expected option starting with -- but found: " + token);
        }

        if (usingNewRoot && rootDir != null) {
            throw new IllegalArgumentException("account flow accepts either --root <dir> or --new, not both");
        }
        if (usingNewRoot) {
            return new FlowRequest(AppConventions.newSandboxRoot(DOMAIN), true);
        }
        if (rootDir != null) {
            return new FlowRequest(rootDir, false);
        }
        return new FlowRequest(AppConventions.defaultRoot(DOMAIN), false);
    }

    private static String required(Map<String, String> options, String key) {
        String value = options.get(key);
        if (value == null || value.isEmpty()) {
            throw new IllegalArgumentException("Missing required option --" + key);
        }
        return value;
    }

    private static long parseTime(Map<String, String> options, long defaultValue) {
        String value = options.get("time");
        return value == null ? defaultValue : Long.parseLong(value);
    }

    private static long parseAmount(Map<String, String> options) {
        String value = required(options, "amount");
        return Long.parseLong(value);
    }

    private static void requireOnlyOptions(Map<String, String> options, String... allowedKeys) {
        java.util.HashSet<String> allowed = new java.util.HashSet<>(java.util.List.of(allowedKeys));
        for (String key : options.keySet()) {
            if (!allowed.contains(key)) {
                throw new IllegalArgumentException("Unsupported option for account command: --" + key);
            }
        }
    }

    private static void requireChainExists(AccountCliRepository repository, String domain) throws Exception {
        AccountCliRepository.ChainState chainState = repository.chainState();
        if (chainState.isEmpty()) {
            throw new IllegalStateException("No " + domain + " chain exists at this root yet: " + repository.rootDir());
        }
    }

    private static void requireMatchingAccountId(String accountId, AccountStateView currentState) {
        if (!accountId.equals(currentState.accountId())) {
            throw new IllegalStateException(
                "Account id " + accountId + " does not match existing chain account " + currentState.accountId()
            );
        }
    }

    private static void requireAllowedTransition(String eventType, AccountStateView currentState) {
        if (currentState.status() != AccountStatus.OPEN) {
            throw new IllegalStateException(eventType + " requires status OPEN but found " + currentState.status());
        }
        if (!"FundsDeposited".equals(eventType) && !"FundsWithdrawn".equals(eventType)) {
            throw new IllegalArgumentException("Unsupported account event type: " + eventType);
        }
    }

    private static boolean isHelp(String value) {
        return "help".equals(value) || "--help".equals(value) || "-h".equals(value);
    }

    private static void printUsage(PrintStream out) {
        out.println("Account CLI");
        out.println("Default root: " + AppConventions.defaultRoot(DOMAIN));
        out.println("Usage:");
        for (String line : usageLines()) {
            out.println("  " + line);
        }
        out.println();
        ShowConventions.printGuide(out);
    }

    public record AccountListEntry(Path rootDir, String accountId, AccountStatus status, long balance) {
        public String showCommand(Path workspaceRoot) {
            if (workspaceRoot.toAbsolutePath().normalize().equals(rootDir.toAbsolutePath().normalize())) {
                return "account show";
            }
            return "account show --root " + quote(rootDir.toString());
        }
    }

    private static String quote(String value) {
        return value.indexOf(' ') >= 0 ? "\"" + value.replace("\"", "\\\"") + "\"" : value;
    }

    private record FlowRequest(Path rootDir, boolean usingNewRoot) {
    }
}
