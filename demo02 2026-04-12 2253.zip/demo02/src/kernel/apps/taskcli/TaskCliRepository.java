package kernel.apps.taskcli;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import kernel.core.Event;
import kernel.core.EventCodec;
import kernel.core.EventProperties;
import kernel.core.StoredEvent;

final class TaskCliRepository {
    private final Path rootDir;
    private final Path eventDir;
    private final Path payloadDir;

    TaskCliRepository(Path rootDir) {
        this.rootDir = rootDir;
        this.eventDir = rootDir.resolve("events");
        this.payloadDir = rootDir.resolve("payloads");
    }

    Path rootDir() {
        return rootDir;
    }

    Path eventDir() {
        return eventDir;
    }

    Path payloadDir() {
        return payloadDir;
    }

    void ensureDirectories() throws IOException {
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);
    }

    ChainState chainState() throws IOException {
        ensureDirectories();
        List<Path> eventPaths = eventPaths();
        if (eventPaths.isEmpty()) {
            return new ChainState(null, 0);
        }

        Map<String, StoredEvent> eventsByHash = new HashMap<>();
        Map<String, String> childByParent = new HashMap<>();

        for (Path eventPath : eventPaths) {
            StoredEvent storedEvent = EventProperties.read(eventPath);
            eventsByHash.put(storedEvent.eventHash(), storedEvent);
            String previousHash = storedEvent.event().previousHash();
            if (!EventCodec.INITIAL_POINTER_SENTINEL.equals(previousHash)) {
                childByParent.put(previousHash, storedEvent.eventHash());
            }
        }

        String headHash = null;
        for (String eventHash : eventsByHash.keySet()) {
            if (!childByParent.containsKey(eventHash)) {
                if (headHash != null) {
                    throw new IllegalStateException("Task CLI repository found more than one chain head");
                }
                headHash = eventHash;
            }
        }

        return new ChainState(headHash, eventsByHash.size());
    }

    StoredEvent storedEvent(String eventHash) throws IOException {
        return EventProperties.read(eventDir.resolve(eventHash + ".properties"));
    }

    private List<Path> eventPaths() throws IOException {
        try (Stream<Path> stream = Files.list(eventDir)) {
            return stream
                .filter(Files::isRegularFile)
                .filter(path -> path.getFileName().toString().endsWith(".properties"))
                .sorted()
                .toList();
        }
    }

    record ChainState(String headHash, int eventCount) {
        boolean exists() {
            return headHash != null;
        }

        boolean isEmpty() {
            return eventCount == 0;
        }

        String nextEventId() {
            return "task-evt-" + String.format("%06d", eventCount + 1);
        }
    }
}
