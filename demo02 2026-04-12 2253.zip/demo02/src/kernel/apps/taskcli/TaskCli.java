package kernel.apps.taskcli;

import java.io.PrintStream;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import kernel.apps.flow.TaskFlowShell;
import kernel.apps.support.AppConventions;
import kernel.apps.support.RootDisplay;
import kernel.apps.support.ShowConventions;
import kernel.apps.support.UnderstandingRenderer;
import kernel.apps.support.WorkspaceRoots;
import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.VerifiedEvent;
import kernel.core.VerifiedReplayChain;
import kernel.domain.spi.UnderstandingView;
import kernel.laws.task.TaskEventWriter;
import kernel.laws.task.TaskLaw;
import kernel.laws.task.TaskStateView;

public final class TaskCli {
    private static final String LAW_VERSION = "task-law-v1";
    private static final String DEFAULT_ACTOR = "cli";
    private static final String DOMAIN = "task";

    private TaskCli() {
    }

    public static void main(String[] args) {
        int exitCode = run(args, System.out, System.err);
        if (exitCode != 0) {
            System.exit(exitCode);
        }
    }

    public static int run(String[] args, PrintStream out, PrintStream err) {
        try {
            if (args.length == 0 || isHelp(args[0])) {
                printUsage(out);
                return 0;
            }

            String command = args[0];
            if ("flow".equals(command)) {
                return runFlow(args, out, err);
            }

            Map<String, String> options = parseOptions(args);
            Path rootDir = Path.of(options.getOrDefault("root", AppConventions.defaultRoot(DOMAIN).toString()));
            out.println("Root: " + RootDisplay.concise(rootDir));
            TaskCliRepository repository = new TaskCliRepository(rootDir);

            switch (command) {
                case "create" -> create(repository, options, out);
                case "start" -> append(repository, options, "TaskStarted", out);
                case "complete" -> append(repository, options, "TaskCompleted", out);
                case "correct" -> correct(repository, options, out);
                case "cancel" -> append(repository, options, "TaskCancelled", out);
                case "list" -> {
                    requireOnlyOptions(options, "root");
                    list(rootDir, out);
                }
                case "next" -> {
                    requireOnlyOptions(options, "root");
                    next(repository, out);
                }
                case "verify" -> {
                    requireOnlyOptions(options, "root");
                    verify(repository, out);
                }
                case "show" -> {
                    requireOnlyOptions(options, "root");
                    show(repository, out);
                }
                default -> {
                    err.println("error=Unknown task command: " + command);
                    printUsage(err);
                    return 1;
                }
            }
            return 0;
        } catch (Exception e) {
            err.println("error=" + e.getMessage());
            return 1;
        }
    }

    public static String[] usageLines() {
        return new String[] {
            "task create --task <taskId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "task start --task <taskId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "task complete --task <taskId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "task correct --task <taskId> --target-event <eventId> --reason <text> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "task cancel --task <taskId> [--root <dir>] [--actor <actorId>] [--time <n>]",
            "task flow [--root <dir> | --new]",
            "task list [--root <workspaceDir>]",
            "task next [--root <dir>]",
            "task verify [--root <dir>]",
            "task show [--root <dir>]"
        };
    }

    private static void create(TaskCliRepository repository, Map<String, String> options, PrintStream out) throws Exception {
        requireOnlyOptions(options, "task", "root", "actor", "time");
        String taskId = required(options, "task");
        TaskCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.isEmpty()) {
            throw new IllegalStateException("Task already exists at this root: " + repository.rootDir());
        }

        long timeValue = parseTime(options, 1L);
        TaskEventWriter.WrittenTaskEvent written = TaskEventWriter.write(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            "TaskCreated",
            EventCodec.INITIAL_POINTER_SENTINEL,
            taskId,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("created=true");
        out.println("eventHash=" + written.eventHash());
        out.println("taskId=" + taskId);
    }

    private static void append(TaskCliRepository repository, Map<String, String> options, String eventType, PrintStream out) throws Exception {
        requireOnlyOptions(options, "task", "root", "actor", "time");
        String taskId = required(options, "task");
        TaskCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            throw new IllegalStateException("Task chain does not exist at " + repository.rootDir());
        }

        TaskStateView currentState = currentTaskState(repository);
        requireMatchingTaskId(taskId, currentState);
        requireAllowedTransition(eventType, currentState);

        long timeValue = parseTime(options, chainState.eventCount() + 1L);
        TaskEventWriter.WrittenTaskEvent written = TaskEventWriter.write(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            eventType,
            chainState.headHash(),
            taskId,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("appended=true");
        out.println("eventType=" + eventType);
        out.println("eventHash=" + written.eventHash());
        out.println("taskId=" + taskId);
    }

    private static void correct(TaskCliRepository repository, Map<String, String> options, PrintStream out) throws Exception {
        requireOnlyOptions(options, "task", "target-event", "reason", "root", "actor", "time");
        String taskId = required(options, "task");
        String targetEventId = required(options, "target-event");
        String reason = required(options, "reason");
        TaskCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            throw new IllegalStateException("Task chain does not exist at " + repository.rootDir());
        }

        TaskStateView currentState = currentTaskState(repository);
        requireMatchingTaskId(taskId, currentState);
        if (currentState.status() != kernel.laws.task.TaskStatus.DONE) {
            throw new IllegalStateException("TaskCorrected requires status DONE but found " + currentState.status());
        }
        if (!targetEventId.equals(currentState.lastCompletionEventId())) {
            throw new IllegalStateException(
                "Correction target " + targetEventId + " does not match last completion event " + currentState.lastCompletionEventId()
            );
        }

        long timeValue = parseTime(options, chainState.eventCount() + 1L);
        TaskEventWriter.WrittenTaskEvent written = TaskEventWriter.writeCorrection(
            repository.eventDir(),
            repository.payloadDir(),
            chainState.nextEventId(),
            chainState.headHash(),
            taskId,
            targetEventId,
            reason,
            LAW_VERSION,
            options.getOrDefault("actor", DEFAULT_ACTOR),
            timeValue
        );
        out.println("corrected=true");
        out.println("eventType=TaskCorrected");
        out.println("eventHash=" + written.eventHash());
        out.println("taskId=" + taskId);
        out.println("targetEventId=" + targetEventId);
    }

    private static void verify(TaskCliRepository repository, PrintStream out) throws Exception {
        requireChainExists(repository, "task");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        int count = replayChain.stream().toList().size();
        out.println("verified=true");
        out.println("verifiedEventCount=" + count);
    }

    private static void next(TaskCliRepository repository, PrintStream out) throws Exception {
        out.println("NEXT");
        List<String> commands = nextCommands(repository);
        if (commands.isEmpty()) {
            out.println("  (no valid next events: task is " + currentTaskState(repository).status() + ")");
            return;
        }
        for (String command : commands) {
            out.println("  - " + command);
        }
    }

    public static List<String> nextCommands(Path rootDir) throws Exception {
        return nextCommands(new TaskCliRepository(rootDir));
    }

    public static List<TaskListEntry> listEntries(Path workspaceRoot) throws Exception {
        java.util.ArrayList<TaskListEntry> entries = new java.util.ArrayList<>();
        for (Path entityRoot : WorkspaceRoots.discoverEntityRoots(workspaceRoot)) {
            TaskCliRepository repository = new TaskCliRepository(entityRoot);
            TaskStateView state = currentTaskState(repository);
            entries.add(new TaskListEntry(entityRoot, state.taskId(), state.status()));
        }
        return List.copyOf(entries);
    }

    private static void list(Path workspaceRoot, PrintStream out) throws Exception {
        List<TaskListEntry> entries = listEntries(workspaceRoot);
        out.println("STATE");
        out.println("  tasks: " + entries.size());
        out.println("WHY");
        out.println("  discovered under: " + workspaceRoot);
        out.println("PATH");
        out.println("  current root + direct child roots with event histories");
        out.println("TRACE");
        for (TaskListEntry entry : entries) {
            out.println("  [" + WorkspaceRoots.displayRoot(workspaceRoot, entry.rootDir()) + "] " + entry.taskId() + " " + entry.status());
        }
        out.println("OUTPUTS");
        for (TaskListEntry entry : entries) {
            out.println("  - " + entry.showCommand(workspaceRoot));
        }
    }

    private static void show(TaskCliRepository repository, PrintStream out) throws Exception {
        requireChainExists(repository, "task");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        List<VerifiedEvent> verifiedEvents = replayChain.stream().toList();
        ReplayRun replayRun = new Replayer().replay(replayChain, new TaskLaw(LAW_VERSION));
        TaskStateView state = TaskStateView.from(replayRun.finalState());
        UnderstandingView understandingView = TaskUnderstandingAdapter.understand(state, replayRun, verifiedEvents);
        out.println(UnderstandingRenderer.render(understandingView));
    }

    private static ReplayRun replay(TaskCliRepository repository) throws Exception {
        requireChainExists(repository, "task");
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(repository.eventDir(), repository.payloadDir());
        return new Replayer().replay(replayChain, new TaskLaw(LAW_VERSION));
    }

    private static List<String> nextCommands(TaskCliRepository repository) throws Exception {
        TaskCliRepository.ChainState chainState = repository.chainState();
        if (!chainState.exists()) {
            return List.of("task create --task <taskId>");
        }

        TaskStateView state = currentTaskState(repository);
        return switch (state.status()) {
            case CREATED, REOPENED -> List.of(
                "task start --task " + quote(state.taskId()),
                "task cancel --task " + quote(state.taskId())
            );
            case ACTIVE -> List.of(
                "task complete --task " + quote(state.taskId()),
                "task cancel --task " + quote(state.taskId())
            );
            case DONE -> List.of(
                "task correct --task " + quote(state.taskId())
                    + " --target-event " + quote(state.lastCompletionEventId())
                    + " --reason <text>"
            );
            case CANCELLED -> List.of();
        };
    }

    private static int runFlow(String[] args, PrintStream out, PrintStream err) throws Exception {
        FlowRequest request = parseFlowRequest(args);
        if (request.usingNewRoot()) {
            out.println("Using new root: " + RootDisplay.concise(request.rootDir()));
        }
        out.println("Root: " + RootDisplay.concise(request.rootDir()));
        return TaskFlowShell.run(request.rootDir(), System.in, out, err);
    }

    private static TaskStateView currentTaskState(TaskCliRepository repository) throws Exception {
        return TaskStateView.from(replay(repository).finalState());
    }

    private static Map<String, String> parseOptions(String[] args) {
        java.util.HashMap<String, String> options = new java.util.HashMap<>();
        for (int i = 1; i < args.length; i++) {
            String token = args[i];
            if (!token.startsWith("--")) {
                throw new IllegalArgumentException("Expected option starting with -- but found: " + token);
            }
            String key = token.substring(2);
            if (i + 1 >= args.length) {
                throw new IllegalArgumentException("Missing value for option --" + key);
            }
            options.put(key, args[++i]);
        }
        return options;
    }

    private static FlowRequest parseFlowRequest(String[] args) throws Exception {
        Path rootDir = null;
        boolean usingNewRoot = false;

        for (int i = 1; i < args.length; i++) {
            String token = args[i];
            if ("--new".equals(token)) {
                usingNewRoot = true;
                continue;
            }
            if ("--root".equals(token)) {
                if (i + 1 >= args.length) {
                    throw new IllegalArgumentException("Missing value for option --root");
                }
                rootDir = Path.of(args[++i]);
                continue;
            }
            if (token.startsWith("--")) {
                throw new IllegalArgumentException("Unsupported option for task flow: " + token);
            }
            throw new IllegalArgumentException("Expected option starting with -- but found: " + token);
        }

        if (usingNewRoot && rootDir != null) {
            throw new IllegalArgumentException("task flow accepts either --root <dir> or --new, not both");
        }
        if (usingNewRoot) {
            return new FlowRequest(AppConventions.newSandboxRoot(DOMAIN), true);
        }
        if (rootDir != null) {
            return new FlowRequest(rootDir, false);
        }
        return new FlowRequest(AppConventions.defaultRoot(DOMAIN), false);
    }

    private static String required(Map<String, String> options, String key) {
        String value = options.get(key);
        if (value == null || value.isEmpty()) {
            throw new IllegalArgumentException("Missing required option --" + key);
        }
        return value;
    }

    private static long parseTime(Map<String, String> options, long defaultValue) {
        String value = options.get("time");
        return value == null ? defaultValue : Long.parseLong(value);
    }

    private static void requireOnlyOptions(Map<String, String> options, String... allowedKeys) {
        java.util.HashSet<String> allowed = new java.util.HashSet<>(java.util.List.of(allowedKeys));
        for (String key : options.keySet()) {
            if (!allowed.contains(key)) {
                throw new IllegalArgumentException("Unsupported option for task command: --" + key);
            }
        }
    }

    private static void requireChainExists(TaskCliRepository repository, String domain) throws Exception {
        TaskCliRepository.ChainState chainState = repository.chainState();
        if (chainState.isEmpty()) {
            throw new IllegalStateException("No " + domain + " chain exists at this root yet: " + repository.rootDir());
        }
    }

    private static void requireMatchingTaskId(String taskId, TaskStateView currentState) {
        if (!taskId.equals(currentState.taskId())) {
            throw new IllegalStateException(
                "Task id " + taskId + " does not match existing chain task " + currentState.taskId()
            );
        }
    }

    private static void requireAllowedTransition(String eventType, TaskStateView currentState) {
        switch (eventType) {
            case "TaskStarted" -> {
                if (currentState.status() != kernel.laws.task.TaskStatus.CREATED
                    && currentState.status() != kernel.laws.task.TaskStatus.REOPENED) {
                    throw new IllegalStateException(
                        "TaskStarted requires status CREATED or REOPENED but found " + currentState.status()
                    );
                }
            }
            case "TaskCompleted" -> {
                if (currentState.status() != kernel.laws.task.TaskStatus.ACTIVE) {
                    throw new IllegalStateException("TaskCompleted requires status ACTIVE but found " + currentState.status());
                }
            }
            case "TaskCorrected" -> {
                if (currentState.status() != kernel.laws.task.TaskStatus.DONE) {
                    throw new IllegalStateException("TaskCorrected requires status DONE but found " + currentState.status());
                }
            }
            case "TaskCancelled" -> {
                if (currentState.status() != kernel.laws.task.TaskStatus.CREATED
                    && currentState.status() != kernel.laws.task.TaskStatus.ACTIVE
                    && currentState.status() != kernel.laws.task.TaskStatus.REOPENED) {
                    throw new IllegalStateException(
                        "TaskCancelled requires status CREATED, ACTIVE, or REOPENED but found " + currentState.status()
                    );
                }
            }
            default -> throw new IllegalArgumentException("Unsupported task event type: " + eventType);
        }
    }

    private static boolean isHelp(String value) {
        return "help".equals(value) || "--help".equals(value) || "-h".equals(value);
    }

    private static void printUsage(PrintStream out) {
        out.println("Task CLI");
        out.println("Default root: " + AppConventions.defaultRoot(DOMAIN));
        out.println("Usage:");
        for (String line : usageLines()) {
            out.println("  " + line);
        }
        out.println();
        ShowConventions.printGuide(out);
    }

    public record TaskListEntry(Path rootDir, String taskId, kernel.laws.task.TaskStatus status) {
        public String showCommand(Path workspaceRoot) {
            if (workspaceRoot.toAbsolutePath().normalize().equals(rootDir.toAbsolutePath().normalize())) {
                return "task show";
            }
            return "task show --root " + quote(rootDir.toString());
        }
    }

    private static String quote(String value) {
        return value.indexOf(' ') >= 0 ? "\"" + value.replace("\"", "\\\"") + "\"" : value;
    }

    private record FlowRequest(Path rootDir, boolean usingNewRoot) {
    }
}
