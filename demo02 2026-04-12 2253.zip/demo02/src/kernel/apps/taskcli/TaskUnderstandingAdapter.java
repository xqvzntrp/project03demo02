package kernel.apps.taskcli;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Function;
import java.util.stream.Collectors;

import kernel.core.DerivedOutput;
import kernel.core.ReplayRun;
import kernel.core.VerifiedEvent;
import kernel.domain.spi.UnderstandingView;
import kernel.laws.task.TaskStateView;
import kernel.laws.task.TaskStatus;

final class TaskUnderstandingAdapter {
    private TaskUnderstandingAdapter() {
    }

    static UnderstandingView understand(TaskStateView state, ReplayRun replayRun, List<VerifiedEvent> verifiedEvents) {
        Map<String, VerifiedEvent> eventsById = verifiedEvents.stream()
            .collect(Collectors.toMap(VerifiedEvent::eventId, Function.identity()));
        List<VerifiedEvent> correctionEvents = filterEvents(verifiedEvents, "TaskCorrected");
        VerifiedEvent lastStateEvent = state.lastStateEventId() == null ? null : eventsById.get(state.lastStateEventId());
        VerifiedEvent correctionTargetEvent = state.correctionTargetEventId() == null ? null : eventsById.get(state.correctionTargetEventId());
        VerifiedEvent correctionEvent = state.lastStateEventId() != null
            && state.status() == TaskStatus.REOPENED
            ? eventsById.get(state.lastStateEventId())
            : findLatestCorrectionEvent(verifiedEvents, state.correctionTargetEventId());

        List<String> stateLines = new ArrayList<>();
        stateLines.add("  task: " + state.taskId());
        stateLines.add("  status: " + humanStatus(state));
        if (lastStateEvent != null) {
            stateLines.add("  last change: " + humanEvent(lastStateEvent) + " by " + lastStateEvent.actorId() + " at " + lastStateEvent.timeValue());
        }
        stateLines.add("  event count: " + replayRun.finalState().eventCount());
        stateLines.add("  last event id: " + replayRun.finalState().lastEventId());

        List<String> whyLines = new ArrayList<>();
        if (correctionTargetEvent != null) {
            whyLines.add("  correction cycles: " + correctionEvents.size() + " corrected completion" + (correctionEvents.size() == 1 ? "" : "s"));
            whyLines.add("  corrected completion: by " + correctionTargetEvent.actorId() + " at " + correctionTargetEvent.timeValue());
            if (correctionEvent != null && "TaskCorrected".equals(correctionEvent.eventType())) {
                whyLines.add("  correction made by: " + correctionEvent.actorId() + " at " + correctionEvent.timeValue());
            }
            if (correctionEvents.size() > 1) {
                VerifiedEvent priorCorrectionEvent = correctionEvents.get(correctionEvents.size() - 2);
                whyLines.add(
                    "  earlier correction: " + priorCorrectionReason(priorCorrectionEvent)
                        + " by " + priorCorrectionEvent.actorId()
                        + " at " + priorCorrectionEvent.timeValue()
                );
            }
            whyLines.add("  reason: " + state.correctionReason());
        } else {
            whyLines.add("  no correction or conflict");
        }

        List<String> pathLines = List.of("  " + String.join(" -> ", summarizedPath(verifiedEvents)));

        List<String> traceLines = new ArrayList<>();
        for (String eventId : state.eventIds()) {
            VerifiedEvent event = eventsById.get(eventId);
            if (event != null) {
                traceLines.add(
                    "  [" + event.eventId() + "] "
                        + humanEvent(event)
                        + " by " + event.actorId()
                        + " at " + event.timeValue()
                );
            }
        }

        List<String> outputLines = new ArrayList<>();
        for (DerivedOutput output : replayRun.outputs()) {
            outputLines.add("  - " + output.kind() + " eventId=" + output.eventId() + " value=" + output.value());
        }

        return new UnderstandingView(List.of(
            UnderstandingView.section("STATE", stateLines),
            UnderstandingView.section("WHY", whyLines),
            UnderstandingView.section("PATH", pathLines),
            UnderstandingView.section("TRACE", traceLines),
            UnderstandingView.section("OUTPUTS", outputLines)
        ));
    }

    private static VerifiedEvent findLatestCorrectionEvent(List<VerifiedEvent> verifiedEvents, String correctionTargetEventId) {
        if (correctionTargetEventId == null) {
            return null;
        }
        for (int i = verifiedEvents.size() - 1; i >= 0; i--) {
            VerifiedEvent event = verifiedEvents.get(i);
            if ("TaskCorrected".equals(event.eventType()) && payloadValue(event).contains(correctionTargetEventId)) {
                return event;
            }
        }
        return null;
    }

    private static List<VerifiedEvent> filterEvents(List<VerifiedEvent> verifiedEvents, String eventType) {
        List<VerifiedEvent> filtered = new ArrayList<>();
        for (VerifiedEvent event : verifiedEvents) {
            if (eventType.equals(event.eventType())) {
                filtered.add(event);
            }
        }
        return filtered;
    }

    private static String payloadValue(VerifiedEvent event) {
        return new String(event.payloadBytes(), StandardCharsets.UTF_8);
    }

    private static String priorCorrectionReason(VerifiedEvent event) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(event.payloadBytes()), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse task payload for eventId " + event.eventId(), e);
        }
        return properties.getProperty("reason", "unknown");
    }

    private static String summarize(VerifiedEvent event) {
        return switch (event.eventType()) {
            case "TaskCreated" -> "Created";
            case "TaskStarted" -> "Started";
            case "TaskCompleted" -> "Completed";
            case "TaskCorrected" -> "Corrected completion";
            case "TaskCancelled" -> "Cancelled";
            default -> event.eventType();
        };
    }

    private static String humanEvent(VerifiedEvent event) {
        return switch (event.eventType()) {
            case "TaskCreated" -> "created";
            case "TaskStarted" -> "started";
            case "TaskCompleted" -> "completed";
            case "TaskCorrected" -> "corrected completion";
            case "TaskCancelled" -> "cancelled";
            default -> event.eventType();
        };
    }

    private static String humanStatus(TaskStateView state) {
        return switch (state.status()) {
            case CREATED -> "CREATED";
            case ACTIVE -> "ACTIVE";
            case REOPENED -> "REOPENED";
            case DONE -> "DONE";
            case CANCELLED -> "CANCELLED";
        };
    }

    private static List<String> summarizedPath(List<VerifiedEvent> verifiedEvents) {
        List<String> path = new ArrayList<>();
        for (int i = 0; i < verifiedEvents.size(); i++) {
            VerifiedEvent event = verifiedEvents.get(i);
            if ("TaskCompleted".equals(event.eventType())
                && i + 1 < verifiedEvents.size()
                && "TaskCorrected".equals(verifiedEvents.get(i + 1).eventType())) {
                path.add("Completed (corrected)");
                i++;
                continue;
            }
            path.add(summarize(event));
        }
        return path;
    }
}
