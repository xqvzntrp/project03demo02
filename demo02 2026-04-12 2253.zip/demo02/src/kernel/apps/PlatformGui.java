package kernel.apps;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import kernel.apps.flow.AccountFlow;
import kernel.apps.flow.DocumentFlow;
import kernel.apps.flow.TaskFlow;
import kernel.apps.support.AppConventions;
import kernel.apps.support.RootDisplay;

public final class PlatformGui {
    private PlatformGui() {
    }

    static void launch(String[] initialCommand) {
        if (GraphicsEnvironment.isHeadless()) {
            throw new IllegalStateException("Swing UI is not available in a headless environment");
        }

        SwingUtilities.invokeLater(() -> {
            GuiState guiState = new GuiState();

            JFrame frame = new JFrame("Platform Flow GUI");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout(12, 12));

            JComboBox<FlowDomain> domainSelector = new JComboBox<>(FlowDomain.values());
            JTextField rootField = new JTextField();
            JButton newRootButton = new JButton("New Root");
            JButton openRootButton = new JButton("Open Root");
            JButton refreshButton = new JButton("Refresh");

            JPanel topControls = new JPanel(new BorderLayout(8, 8));
            JPanel leftControls = new JPanel(new GridLayout(2, 1, 0, 4));
            leftControls.add(new JLabel("Domain"));
            leftControls.add(domainSelector);
            JPanel centerControls = new JPanel(new GridLayout(2, 1, 0, 4));
            centerControls.add(new JLabel("Root"));
            centerControls.add(rootField);
            JPanel rightControls = new JPanel(new GridLayout(3, 1, 0, 4));
            rightControls.add(newRootButton);
            rightControls.add(openRootButton);
            rightControls.add(refreshButton);

            topControls.add(leftControls, BorderLayout.WEST);
            topControls.add(centerControls, BorderLayout.CENTER);
            topControls.add(rightControls, BorderLayout.EAST);

            JTextArea stateArea = textArea();
            JTextArea nextArea = textArea();
            JTextArea resultArea = textArea();
            JTextArea previewArea = textArea();
            previewArea.setRows(4);

            JLabel currentRootLabel = new JLabel("Current Root: (none)");
            JLabel nextActionLabel = new JLabel("Next Action: (choose a root to begin)");
            JLabel promptLabel = new JLabel("Input");
            JTextField inputField = new JTextField();
            JButton applyInputButton = new JButton("Apply Input");
            JButton runButton = new JButton("Run");

            JPanel statePanel = new JPanel(new BorderLayout(0, 8));
            statePanel.add(new JLabel("Current State"), BorderLayout.NORTH);
            statePanel.add(new JScrollPane(stateArea), BorderLayout.CENTER);

            JPanel nextPanel = new JPanel(new BorderLayout(0, 8));
            nextPanel.add(new JLabel("Next Commands"), BorderLayout.NORTH);
            nextPanel.add(new JScrollPane(nextArea), BorderLayout.CENTER);

            JSplitPane leftSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, statePanel, nextPanel);
            leftSplit.setResizeWeight(0.7);

            JPanel sessionPanel = new JPanel(new BorderLayout(0, 8));
            JPanel sessionHeader = new JPanel(new GridLayout(2, 1, 0, 4));
            sessionHeader.add(currentRootLabel);
            sessionHeader.add(nextActionLabel);
            sessionPanel.add(sessionHeader, BorderLayout.NORTH);

            JPanel interactionPanel = new JPanel(new BorderLayout(0, 8));
            JPanel inputPanel = new JPanel(new BorderLayout(8, 0));
            inputPanel.add(promptLabel, BorderLayout.WEST);
            inputPanel.add(inputField, BorderLayout.CENTER);
            inputPanel.add(applyInputButton, BorderLayout.EAST);

            JPanel previewPanel = new JPanel(new BorderLayout(0, 8));
            previewPanel.add(new JLabel("Preview"), BorderLayout.NORTH);
            previewPanel.add(new JScrollPane(previewArea), BorderLayout.CENTER);

            JPanel runPanel = new JPanel(new BorderLayout());
            runPanel.add(runButton, BorderLayout.EAST);

            JPanel resultPanel = new JPanel(new BorderLayout(0, 8));
            resultPanel.add(new JLabel("Result"), BorderLayout.NORTH);
            resultPanel.add(new JScrollPane(resultArea), BorderLayout.CENTER);

            interactionPanel.add(inputPanel, BorderLayout.NORTH);
            interactionPanel.add(previewPanel, BorderLayout.CENTER);
            interactionPanel.add(runPanel, BorderLayout.SOUTH);

            sessionPanel.add(interactionPanel, BorderLayout.CENTER);
            sessionPanel.add(resultPanel, BorderLayout.SOUTH);

            JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftSplit, sessionPanel);
            mainSplit.setResizeWeight(0.55);

            frame.add(topControls, BorderLayout.NORTH);
            frame.add(mainSplit, BorderLayout.CENTER);
            frame.setSize(new Dimension(1280, 760));
            frame.setLocationByPlatform(true);

            Runnable updateView = () -> refreshView(guiState, rootField, stateArea, nextArea, resultArea, previewArea, currentRootLabel, nextActionLabel, promptLabel, inputField, applyInputButton, runButton);

            domainSelector.addActionListener(event -> {
                FlowDomain domain = (FlowDomain) domainSelector.getSelectedItem();
                guiState.domain = domain == null ? FlowDomain.TASK : domain;
                rootField.setText(guiState.rootDir == null ? "" : guiState.rootDir.toString());
                updateView.run();
            });

            newRootButton.addActionListener(event -> {
                try {
                    guiState.domain = selectedDomain(domainSelector);
                    guiState.rootDir = guiState.domain.newSandboxRoot();
                    guiState.session = guiState.domain.begin(guiState.rootDir);
                    guiState.lastResult = "Using new root: " + RootDisplay.concise(guiState.rootDir);
                    rootField.setText(guiState.rootDir.toString());
                    updateView.run();
                } catch (Exception e) {
                    guiState.lastResult = "error=" + e.getMessage();
                    updateView.run();
                }
            });

            openRootButton.addActionListener(event -> {
                try {
                    guiState.domain = selectedDomain(domainSelector);
                    guiState.rootDir = resolveRoot(guiState.domain, rootField.getText());
                    guiState.session = guiState.domain.begin(guiState.rootDir);
                    guiState.lastResult = "Opened root: " + RootDisplay.concise(guiState.rootDir);
                    rootField.setText(guiState.rootDir.toString());
                    updateView.run();
                } catch (Exception e) {
                    guiState.lastResult = "error=" + e.getMessage();
                    updateView.run();
                }
            });

            refreshButton.addActionListener(event -> {
                try {
                    if (guiState.rootDir != null) {
                        guiState.session = guiState.domain.begin(guiState.rootDir);
                    }
                    updateView.run();
                } catch (Exception e) {
                    guiState.lastResult = "error=" + e.getMessage();
                    updateView.run();
                }
            });

            applyInputButton.addActionListener(event -> {
                try {
                    if (guiState.session == null) {
                        guiState.lastResult = "Choose a root to begin.";
                    } else {
                        guiState.session = guiState.session.answer(inputField.getText());
                        guiState.lastResult = null;
                        inputField.setText("");
                    }
                } catch (Exception e) {
                    guiState.lastResult = "error=" + e.getMessage();
                }
                updateView.run();
            });

            inputField.addActionListener(event -> applyInputButton.doClick());

            runButton.addActionListener(event -> {
                try {
                    if (guiState.session == null) {
                        guiState.lastResult = "Choose a root to begin.";
                    } else {
                        GuiExecution execution = guiState.session.execute();
                        guiState.session = execution.nextSession();
                        guiState.lastResult = execution.output();
                        inputField.setText("");
                    }
                } catch (Exception e) {
                    guiState.lastResult = "error=" + e.getMessage();
                }
                updateView.run();
            });

            applyInitialCommand(guiState, selectedDomain(domainSelector), initialCommand);
            domainSelector.setSelectedItem(guiState.domain);
            rootField.setText(guiState.rootDir == null ? "" : guiState.rootDir.toString());
            updateView.run();

            frame.setVisible(true);
            inputField.requestFocusInWindow();
        });
    }

    public static String primaryNextActionFromOutput(String output) {
        boolean inNext = false;
        for (String line : output.split("\\R")) {
            if ("NEXT".equals(line.strip()) || "[next]".equals(line.strip())) {
                inNext = true;
                continue;
            }
            if (!inNext) {
                continue;
            }
            if (line.startsWith("  - ")) {
                return line.substring("  - ".length());
            }
            if (!line.isBlank()) {
                break;
            }
        }
        return null;
    }

    private static void applyInitialCommand(GuiState guiState, FlowDomain selectedDomain, String[] initialCommand) {
        guiState.domain = selectedDomain;
        if (initialCommand.length == 0) {
            guiState.lastResult = "Choose a domain, then click New Root or Open Root.";
            return;
        }

        try {
            FlowStart start = FlowStart.parse(initialCommand);
            guiState.domain = start.domain();
            guiState.rootDir = start.rootDir();
            guiState.session = guiState.domain.begin(guiState.rootDir);
            guiState.lastResult = start.message();
        } catch (Exception e) {
            guiState.lastResult = "error=" + e.getMessage();
        }
    }

    private static void refreshView(
        GuiState guiState,
        JTextField rootField,
        JTextArea stateArea,
        JTextArea nextArea,
        JTextArea resultArea,
        JTextArea previewArea,
        JLabel currentRootLabel,
        JLabel nextActionLabel,
        JLabel promptLabel,
        JTextField inputField,
        JButton applyInputButton,
        JButton runButton
    ) {
        resultArea.setText(guiState.lastResult == null ? "" : guiState.lastResult);

        if (guiState.rootDir == null || guiState.session == null) {
            currentRootLabel.setText("Current Root: (none)");
            nextActionLabel.setText("Next Action: (choose a root to begin)");
            promptLabel.setText("Input");
            inputField.setEnabled(false);
            applyInputButton.setEnabled(false);
            runButton.setEnabled(false);
            previewArea.setText("");
            stateArea.setText("");
            nextArea.setText("");
            return;
        }

        rootField.setText(guiState.rootDir.toString());
        currentRootLabel.setText("Current Root: " + RootDisplay.concise(guiState.rootDir));
        stateArea.setText(runPlatformCli(guiState.domain.showArgs(guiState.rootDir)).output());
        nextArea.setText(runPlatformCli(guiState.domain.nextArgs(guiState.rootDir)).output());
        previewArea.setText(guiState.session.commandPreview());

        if (guiState.session.isFinished()) {
            nextActionLabel.setText("Next Action: (no guided action available)");
            promptLabel.setText("Input");
            inputField.setText("");
            inputField.setEnabled(false);
            applyInputButton.setEnabled(false);
            runButton.setEnabled(false);
            return;
        }

        nextActionLabel.setText("Next Action: " + guiState.session.nextActionLabel());
        if (guiState.session.readyToExecute()) {
            promptLabel.setText("Input");
            inputField.setEnabled(false);
            applyInputButton.setEnabled(false);
            runButton.setEnabled(true);
        } else {
            GuiPrompt prompt = guiState.session.prompt();
            promptLabel.setText(prompt.field() + " - " + prompt.instruction());
            inputField.setEnabled(true);
            applyInputButton.setEnabled(true);
            runButton.setEnabled(false);
            if (!inputField.isFocusOwner()) {
                inputField.requestFocusInWindow();
            }
        }
    }

    private static FlowDomain selectedDomain(JComboBox<FlowDomain> domainSelector) {
        FlowDomain selected = (FlowDomain) domainSelector.getSelectedItem();
        return selected == null ? FlowDomain.TASK : selected;
    }

    private static Path resolveRoot(FlowDomain domain, String value) {
        String trimmed = value == null ? "" : value.trim();
        return trimmed.isEmpty() ? domain.defaultRoot() : Path.of(trimmed);
    }

    private static PlatformRun runPlatformCli(String... args) {
        ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
        ByteArrayOutputStream errBuffer = new ByteArrayOutputStream();
        int exitCode = PlatformCli.run(
            args,
            new PrintStream(outBuffer, true, StandardCharsets.UTF_8),
            new PrintStream(errBuffer, true, StandardCharsets.UTF_8)
        );

        String output = outBuffer.toString(StandardCharsets.UTF_8);
        String error = errBuffer.toString(StandardCharsets.UTF_8);
        StringBuilder builder = new StringBuilder();
        if (!output.isBlank()) {
            builder.append(output.stripTrailing());
        }
        if (!error.isBlank()) {
            if (builder.length() > 0) {
                builder.append(System.lineSeparator());
            }
            builder.append(error.stripTrailing());
        }
        if (builder.length() == 0) {
            builder.append("exitCode=").append(exitCode);
        } else if (exitCode != 0) {
            builder.append(System.lineSeparator()).append("exitCode=").append(exitCode);
        }
        return new PlatformRun(exitCode, builder.toString());
    }

    private static JTextArea textArea() {
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        area.setLineWrap(false);
        return area;
    }

    private record PlatformRun(int exitCode, String output) {
    }

    private record GuiPrompt(String field, String instruction, String preview) {
    }

    private record GuiExecution(String output, GuiFlowSession nextSession) {
    }

    private interface GuiFlowSession {
        boolean isFinished();

        boolean readyToExecute();

        GuiPrompt prompt();

        GuiFlowSession answer(String value) throws Exception;

        GuiExecution execute() throws Exception;

        String commandPreview();

        String nextActionLabel();
    }

    private static final class GuiState {
        private FlowDomain domain = FlowDomain.TASK;
        private Path rootDir;
        private GuiFlowSession session;
        private String lastResult;
    }

    private enum FlowDomain {
        TASK("task") {
            @Override
            Path defaultRoot() {
                return AppConventions.defaultRoot("task");
            }

            @Override
            Path newSandboxRoot() throws Exception {
                return AppConventions.newSandboxRoot("task");
            }

            @Override
            GuiFlowSession begin(Path rootDir) throws Exception {
                return new TaskGuiFlowSession(TaskFlow.begin(rootDir));
            }
        },
        ACCOUNT("account") {
            @Override
            Path defaultRoot() {
                return AppConventions.defaultRoot("account");
            }

            @Override
            Path newSandboxRoot() throws Exception {
                return AppConventions.newSandboxRoot("account");
            }

            @Override
            GuiFlowSession begin(Path rootDir) throws Exception {
                return new AccountGuiFlowSession(AccountFlow.begin(rootDir));
            }
        },
        DOCUMENT("document") {
            @Override
            Path defaultRoot() {
                return AppConventions.defaultRoot("document");
            }

            @Override
            Path newSandboxRoot() throws Exception {
                return AppConventions.newSandboxRoot("document");
            }

            @Override
            GuiFlowSession begin(Path rootDir) throws Exception {
                return new DocumentGuiFlowSession(DocumentFlow.begin(rootDir));
            }
        };

        private final String domainName;

        FlowDomain(String domainName) {
            this.domainName = domainName;
        }

        abstract Path defaultRoot();

        abstract Path newSandboxRoot() throws Exception;

        abstract GuiFlowSession begin(Path rootDir) throws Exception;

        String[] showArgs(Path rootDir) {
            return new String[] { domainName, "show", "--root", rootDir.toString() };
        }

        String[] nextArgs(Path rootDir) {
            return new String[] { domainName, "next", "--root", rootDir.toString() };
        }

        @Override
        public String toString() {
            return switch (this) {
                case TASK -> "Task";
                case ACCOUNT -> "Account";
                case DOCUMENT -> "Document";
            };
        }
    }

    private record FlowStart(FlowDomain domain, Path rootDir, String message) {
        static FlowStart parse(String[] args) throws Exception {
            if (args.length == 0) {
                return new FlowStart(FlowDomain.TASK, null, "Choose a domain, then click New Root or Open Root.");
            }

            FlowDomain domain = switch (args[0]) {
                case "task" -> FlowDomain.TASK;
                case "account" -> FlowDomain.ACCOUNT;
                case "document" -> FlowDomain.DOCUMENT;
                default -> throw new IllegalArgumentException("GUI expects task/account/document flow commands");
            };

            if (args.length == 1) {
                return new FlowStart(domain, domain.defaultRoot(), "Opened root: " + RootDisplay.concise(domain.defaultRoot()));
            }
            if (!"flow".equals(args[1])) {
                throw new IllegalArgumentException("GUI currently renders only flow commands");
            }

            Path rootDir = null;
            boolean usingNewRoot = false;
            for (int i = 2; i < args.length; i++) {
                String token = args[i];
                if ("--new".equals(token)) {
                    usingNewRoot = true;
                    continue;
                }
                if ("--root".equals(token)) {
                    if (i + 1 >= args.length) {
                        throw new IllegalArgumentException("Missing value for option --root");
                    }
                    rootDir = Path.of(args[++i]);
                    continue;
                }
                throw new IllegalArgumentException("Unsupported GUI flow option: " + token);
            }

            if (usingNewRoot && rootDir != null) {
                throw new IllegalArgumentException("GUI flow accepts either --root <dir> or --new, not both");
            }
            if (usingNewRoot) {
                Path newRoot = domain.newSandboxRoot();
                return new FlowStart(domain, newRoot, "Using new root: " + RootDisplay.concise(newRoot));
            }
            if (rootDir != null) {
                return new FlowStart(domain, rootDir, "Opened root: " + RootDisplay.concise(rootDir));
            }
            Path defaultRoot = domain.defaultRoot();
            return new FlowStart(domain, defaultRoot, "Opened root: " + RootDisplay.concise(defaultRoot));
        }
    }

    private record TaskGuiFlowSession(TaskFlow.TaskFlowSession delegate) implements GuiFlowSession {
        @Override
        public boolean isFinished() {
            return delegate.isFinished();
        }

        @Override
        public boolean readyToExecute() {
            return delegate.readyToExecute();
        }

        @Override
        public GuiPrompt prompt() {
            TaskFlow.TaskFlowPrompt prompt = delegate.prompt();
            return new GuiPrompt(prompt.field(), prompt.instruction(), prompt.commandPreview());
        }

        @Override
        public GuiFlowSession answer(String value) {
            return new TaskGuiFlowSession(delegate.answer(value));
        }

        @Override
        public GuiExecution execute() throws Exception {
            TaskFlow.TaskFlowExecution execution = delegate.execute();
            return new GuiExecution(execution.output(), new TaskGuiFlowSession(execution.nextSession()));
        }

        @Override
        public String commandPreview() {
            return delegate.commandPreview();
        }

        @Override
        public String nextActionLabel() {
            return "task " + delegate.action().commandName();
        }
    }

    private record AccountGuiFlowSession(AccountFlow.AccountFlowSession delegate) implements GuiFlowSession {
        @Override
        public boolean isFinished() {
            return delegate.isFinished();
        }

        @Override
        public boolean readyToExecute() {
            return delegate.readyToExecute();
        }

        @Override
        public GuiPrompt prompt() {
            AccountFlow.AccountFlowPrompt prompt = delegate.prompt();
            return new GuiPrompt(prompt.field(), prompt.instruction(), prompt.commandPreview());
        }

        @Override
        public GuiFlowSession answer(String value) {
            return new AccountGuiFlowSession(delegate.answer(value));
        }

        @Override
        public GuiExecution execute() throws Exception {
            AccountFlow.AccountFlowExecution execution = delegate.execute();
            return new GuiExecution(execution.output(), new AccountGuiFlowSession(execution.nextSession()));
        }

        @Override
        public String commandPreview() {
            return delegate.commandPreview();
        }

        @Override
        public String nextActionLabel() {
            return "account " + delegate.action().commandName();
        }
    }

    private record DocumentGuiFlowSession(DocumentFlow.DocumentFlowSession delegate) implements GuiFlowSession {
        @Override
        public boolean isFinished() {
            return delegate.isFinished();
        }

        @Override
        public boolean readyToExecute() {
            return delegate.readyToExecute();
        }

        @Override
        public GuiPrompt prompt() {
            DocumentFlow.DocumentFlowPrompt prompt = delegate.prompt();
            return new GuiPrompt(prompt.field(), prompt.instruction(), prompt.commandPreview());
        }

        @Override
        public GuiFlowSession answer(String value) {
            return new DocumentGuiFlowSession(delegate.answer(value));
        }

        @Override
        public GuiExecution execute() throws Exception {
            DocumentFlow.DocumentFlowExecution execution = delegate.execute();
            return new GuiExecution(execution.output(), new DocumentGuiFlowSession(execution.nextSession()));
        }

        @Override
        public String commandPreview() {
            return delegate.commandPreview();
        }

        @Override
        public String nextActionLabel() {
            return "document " + delegate.action().commandName();
        }
    }
}
