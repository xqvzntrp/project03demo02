package kernel.apps;

import java.io.PrintStream;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import kernel.apps.accountcli.AccountCli;
import kernel.apps.documentcli.DocumentCli;
import kernel.apps.support.AppConventions;
import kernel.apps.support.ShowConventions;
import kernel.apps.taskcli.TaskCli;
import kernel.host.MiniCoreHost;

public final class PlatformCli {
    private PlatformCli() {
    }

    public static void main(String[] args) {
        int exitCode = run(args, System.out, System.err);
        if (exitCode != 0) {
            System.exit(exitCode);
        }
    }

    public static int run(String[] args, PrintStream out, PrintStream err) {
        if (isGui(args)) {
            String[] forwarded = Arrays.copyOfRange(args, 1, args.length);
            try {
                PlatformGui.launch(forwarded);
                return 0;
            } catch (Throwable t) {
                err.println("gui unavailable, falling back to CLI: " + t.getMessage());
                return run(forwarded, out, err);
            }
        }

        if (args.length == 0 || isHelp(args[0])) {
            printUsage(out);
            return 0;
        }

        String domain = args[0];
        String[] forwarded = Arrays.copyOfRange(args, 1, args.length);

        return switch (domain) {
            case "plugins" -> MiniCoreHost.run(forwarded, out, err);
            case "suggest" -> suggest(forwarded, out);
            case "task" -> TaskCli.run(forwarded, out, err);
            case "account" -> AccountCli.run(forwarded, out, err);
            case "document" -> DocumentCli.run(forwarded, out, err);
            default -> {
                err.println("error=Unknown domain: " + domain);
                err.println("Try: help, plugins, suggest, task, account, document");
                printUsage(err);
                yield 1;
            }
        };
    }

    private static boolean isHelp(String value) {
        return "help".equals(value) || "--help".equals(value) || "-h".equals(value);
    }

    private static boolean isGui(String[] args) {
        return args.length > 0 && ("--gui".equals(args[0]) || "gui".equals(args[0]));
    }

    private static int suggest(String[] args, PrintStream out) {
        SuggestRequest request = parseSuggestRequest(args);
        out.println("SUGGESTIONS");
        for (String suggestion : PlatformGuiSuggestions.suggestionsFor(
            request.query(),
            request.taskWorkspace(),
            request.accountWorkspace(),
            request.documentWorkspace()
        )) {
            out.println("  - " + suggestion);
            String optionsHint = optionsHintFor(suggestion);
            if (optionsHint != null) {
                out.println("    options: " + optionsHint);
            }
        }
        return 0;
    }

    private static String optionsHintFor(String suggestion) {
        if (suggestion.contains("--root ")) {
            return null;
        }

        return switch (suggestion) {
            case "task list", "account list", "document list",
                "task verify", "account verify", "document verify",
                "task show", "account show", "document show" -> "--root <dir>";
            case "task flow" -> "--root <dir> or --new";
            case "account flow" -> "--root <dir> or --new";
            case "document flow" -> "--root <dir> or --new";
            case "task flow --new" -> null;
            case "account flow --new" -> null;
            case "document flow --new" -> null;
            default -> optionsHintByPrefix(suggestion);
        };
    }

    private static String optionsHintByPrefix(String suggestion) {
        for (String prefix : List.of(
            "task create --task ",
            "task start --task ",
            "task complete --task ",
            "task correct --task ",
            "task cancel --task ",
            "account open --account ",
            "account deposit --account ",
            "account withdraw --account ",
            "account close --account ",
            "document draft --document ",
            "document submit --document ",
            "document reject --document ",
            "document revise --document ",
            "document approve --document "
        )) {
            if (suggestion.startsWith(prefix)) {
                return "--root <dir>, --actor <actor>, --time <time>";
            }
        }

        for (String prefix : List.of(
            "task show --root ",
            "account show --root ",
            "document show --root "
        )) {
            if (suggestion.startsWith(prefix)) {
                return null;
            }
        }

        return null;
    }

    private static SuggestRequest parseSuggestRequest(String[] args) {
        Path defaultTaskRoot = AppConventions.defaultRoot("task");
        Path defaultAccountRoot = AppConventions.defaultRoot("account");
        Path defaultDocumentRoot = AppConventions.defaultRoot("document");
        Path sharedRoot = null;
        Path taskRoot = null;
        Path accountRoot = null;
        Path documentRoot = null;
        StringBuilder query = new StringBuilder();

        for (int i = 0; i < args.length; i++) {
            String token = args[i];
            if ("--root".equals(token)) {
                sharedRoot = Path.of(requiredOptionValue(args, ++i, token));
                continue;
            }
            if ("--task-root".equals(token)) {
                taskRoot = Path.of(requiredOptionValue(args, ++i, token));
                continue;
            }
            if ("--account-root".equals(token)) {
                accountRoot = Path.of(requiredOptionValue(args, ++i, token));
                continue;
            }
            if ("--document-root".equals(token)) {
                documentRoot = Path.of(requiredOptionValue(args, ++i, token));
                continue;
            }
            if (token.startsWith("--")) {
                throw new IllegalArgumentException("Unknown suggest option: " + token);
            }
            if (query.length() > 0) {
                query.append(' ');
            }
            query.append(token);
        }

        Path taskWorkspace = taskRoot != null ? taskRoot : sharedRoot != null ? sharedRoot : defaultTaskRoot;
        Path accountWorkspace = accountRoot != null ? accountRoot : sharedRoot != null ? sharedRoot : defaultAccountRoot;
        Path documentWorkspace = documentRoot != null ? documentRoot : sharedRoot != null ? sharedRoot : defaultDocumentRoot;
        return new SuggestRequest(query.toString(), taskWorkspace, accountWorkspace, documentWorkspace);
    }

    private static String requiredOptionValue(String[] args, int index, String option) {
        if (index >= args.length) {
            throw new IllegalArgumentException("Missing value for option " + option);
        }
        return args[index];
    }

    private static void printUsage(PrintStream out) {
        out.println("Platform CLI");
        out.println("Usage:");
        out.println("  PlatformCli --gui [command...]");
        out.println("  PlatformCli plugins");
        out.println("  PlatformCli suggest [--root <dir>] [--task-root <dir>] [--account-root <dir>] [--document-root <dir>] [query...]");
        out.println("  PlatformCli task <command> [options]");
        out.println("  PlatformCli account <command> [options]");
        out.println("  PlatformCli document <command> [options]");
        out.println("  PlatformCli help");
        out.println();
        ShowConventions.printGuide(out);
        out.println();
        out.println("Task commands:");
        for (String line : TaskCli.usageLines()) {
            out.println("  " + line);
        }
        out.println();
        out.println("Account commands:");
        for (String line : AccountCli.usageLines()) {
            out.println("  " + line);
        }
        out.println();
        out.println("Document commands:");
        for (String line : DocumentCli.usageLines()) {
            out.println("  " + line);
        }
    }

    private record SuggestRequest(
        String query,
        Path taskWorkspace,
        Path accountWorkspace,
        Path documentWorkspace
    ) {
    }
}
