package kernel.apps.support;

import java.util.ArrayList;
import java.util.List;

public final class CommandLine {
    private CommandLine() {
    }

    public static String[] tokenize(String commandLine) {
        List<String> tokens = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;
        char quoteChar = 0;
        boolean escaping = false;

        for (int i = 0; i < commandLine.length(); i++) {
            char ch = commandLine.charAt(i);
            if (escaping) {
                current.append(ch);
                escaping = false;
                continue;
            }
            if (ch == '\\') {
                escaping = true;
                continue;
            }
            if (inQuotes) {
                if (ch == quoteChar) {
                    inQuotes = false;
                    quoteChar = 0;
                } else {
                    current.append(ch);
                }
                continue;
            }
            if (ch == '"' || ch == '\'') {
                inQuotes = true;
                quoteChar = ch;
                continue;
            }
            if (Character.isWhitespace(ch)) {
                if (current.length() > 0) {
                    tokens.add(current.toString());
                    current.setLength(0);
                }
                continue;
            }
            current.append(ch);
        }

        if (escaping) {
            current.append('\\');
        }
        if (inQuotes) {
            throw new IllegalArgumentException("Unclosed quote in command");
        }
        if (current.length() > 0) {
            tokens.add(current.toString());
        }
        return tokens.toArray(String[]::new);
    }

    public static String join(String[] args) {
        return join(List.of(args));
    }

    public static String join(List<String> args) {
        List<String> parts = new ArrayList<>();
        for (String arg : args) {
            if (arg.indexOf(' ') >= 0) {
                parts.add("\"" + arg.replace("\"", "\\\"") + "\"");
            } else {
                parts.add(arg);
            }
        }
        return String.join(" ", parts);
    }
}
