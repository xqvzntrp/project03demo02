package kernel.apps.support;

import java.nio.file.Path;

public final class RootDisplay {
    private RootDisplay() {
    }

    public static String concise(Path rootDir) {
        Path resolved = rootDir.toAbsolutePath().normalize();
        Path cwd = Path.of("").toAbsolutePath().normalize();
        try {
            Path relative = cwd.relativize(resolved);
            String display = relative.toString();
            return display.isEmpty() ? "." : display;
        } catch (IllegalArgumentException ignored) {
            return resolved.toString();
        }
    }
}
