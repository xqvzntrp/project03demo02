package kernel.apps.support;

public final class ShowConventions {
    private ShowConventions() {
    }

    public static void printGuide(java.io.PrintStream out) {
        out.println("Show output:");
        out.println("  STATE   current truth");
        out.println("  WHY     what explains it");
        out.println("  PATH    the shortest causal path");
        out.println("  TRACE   event-by-event proof");
        out.println("  OUTPUTS derived outputs");
    }
}
