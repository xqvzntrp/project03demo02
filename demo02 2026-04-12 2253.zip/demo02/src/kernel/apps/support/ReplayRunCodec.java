package kernel.apps.support;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

import kernel.core.DerivedOutput;
import kernel.core.ReplayRun;

public final class ReplayRunCodec {
    private static final byte[] FORMAT_MARKER = new byte[] { 'R', 'U', 'N', '1' };

    private ReplayRunCodec() {
    }

    public static byte[] canonicalBytes(ReplayRun replayRun) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        output.writeBytes(FORMAT_MARKER);
        writeString(output, replayRun.lawVersion());
        writeInt(output, replayRun.finalState().eventCount());
        writeLong(output, replayRun.finalState().totalPayloadBytes());
        writeString(output, replayRun.finalState().lastEventId());
        writeStringList(output, replayRun.finalState().appliedEventIds());
        writeOutputs(output, replayRun.outputs());
        return output.toByteArray();
    }

    public static String canonicalHex(ReplayRun replayRun) {
        byte[] bytes = canonicalBytes(replayRun);
        StringBuilder hex = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            hex.append(Character.forDigit((b >>> 4) & 0x0F, 16));
            hex.append(Character.forDigit(b & 0x0F, 16));
        }
        return hex.toString();
    }

    private static void writeOutputs(ByteArrayOutputStream output, Iterable<DerivedOutput> outputs) {
        int count = 0;
        for (DerivedOutput ignored : outputs) {
            count++;
        }
        writeInt(output, count);
        for (DerivedOutput derivedOutput : outputs) {
            writeString(output, derivedOutput.kind());
            writeString(output, derivedOutput.eventId());
            writeString(output, derivedOutput.value());
        }
    }

    private static void writeStringList(ByteArrayOutputStream output, Iterable<String> values) {
        int count = 0;
        for (String ignored : values) {
            count++;
        }
        writeInt(output, count);
        for (String value : values) {
            writeString(output, value);
        }
    }

    private static void writeString(ByteArrayOutputStream output, String value) {
        byte[] utf8 = value.getBytes(StandardCharsets.UTF_8);
        writeInt(output, utf8.length);
        output.writeBytes(utf8);
    }

    private static void writeInt(ByteArrayOutputStream output, int value) {
        output.writeBytes(ByteBuffer.allocate(Integer.BYTES).order(ByteOrder.BIG_ENDIAN).putInt(value).array());
    }

    private static void writeLong(ByteArrayOutputStream output, long value) {
        output.writeBytes(ByteBuffer.allocate(Long.BYTES).order(ByteOrder.BIG_ENDIAN).putLong(value).array());
    }
}
