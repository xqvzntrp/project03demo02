package kernel.apps.support;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class AppConventions {
    private static final DateTimeFormatter SANDBOX_STAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private AppConventions() {
    }

    public static Path defaultRoot(String domain) {
        return Path.of("build", "platform", domain);
    }

    public static Path newSandboxRoot(String domain) throws IOException {
        Path sandboxDir = Path.of("build", "platform", "sandbox");
        Files.createDirectories(sandboxDir);

        String stamp = LocalDateTime.now().format(SANDBOX_STAMP);
        Path candidate = sandboxDir.resolve(domain + "-" + stamp);
        int suffix = 2;
        while (Files.exists(candidate)) {
            candidate = sandboxDir.resolve(domain + "-" + stamp + "-" + suffix);
            suffix++;
        }
        Files.createDirectories(candidate);
        return candidate;
    }
}
