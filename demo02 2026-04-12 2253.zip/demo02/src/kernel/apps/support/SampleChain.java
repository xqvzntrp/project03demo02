package kernel.apps.support;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.core.Event;
import kernel.core.EventCodec;
import kernel.core.EventProperties;
import kernel.core.PayloadCas;

public final class SampleChain {
    private SampleChain() {
    }

    public static SampleData create(Path rootDir) throws IOException {
        Path eventDir = rootDir.resolve("events");
        Path payloadDir = rootDir.resolve("payloads");
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);

        byte[] firstPayload = "hello kernel".getBytes(StandardCharsets.UTF_8);
        String firstPayloadHash = PayloadCas.store(payloadDir, firstPayload);
        Event firstEvent = new Event(
            "evt-0001",
            "DocumentCreated",
            EventCodec.INITIAL_POINTER_SENTINEL,
            firstPayloadHash,
            "law-v1",
            "actor-01",
            1L
        );
        String firstHash = EventCodec.eventHash(firstEvent);
        EventProperties.write(eventDir.resolve(firstHash + ".properties"), firstEvent);

        byte[] secondPayload = "signed".getBytes(StandardCharsets.UTF_8);
        String secondPayloadHash = PayloadCas.store(payloadDir, secondPayload);
        Event secondEvent = new Event(
            "evt-0002",
            "DocumentSigned",
            firstHash,
            secondPayloadHash,
            "law-v1",
            "actor-02",
            2L
        );
        String secondHash = EventCodec.eventHash(secondEvent);
        EventProperties.write(eventDir.resolve(secondHash + ".properties"), secondEvent);

        return new SampleData(eventDir, payloadDir, firstEvent, firstHash, secondEvent, secondHash);
    }

    public record SampleData(
        Path eventDir,
        Path payloadDir,
        Event firstEvent,
        String firstHash,
        Event secondEvent,
        String secondHash
    ) {
    }
}
