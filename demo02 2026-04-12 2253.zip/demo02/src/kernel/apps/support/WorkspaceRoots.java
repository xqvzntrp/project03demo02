package kernel.apps.support;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Stream;

public final class WorkspaceRoots {
    private WorkspaceRoots() {
    }

    public static List<Path> discoverEntityRoots(Path workspaceRoot) throws IOException {
        LinkedHashSet<Path> roots = new LinkedHashSet<>();
        Path normalizedWorkspace = workspaceRoot.toAbsolutePath().normalize();
        if (isEntityRoot(normalizedWorkspace)) {
            roots.add(normalizedWorkspace);
        }
        if (Files.isDirectory(normalizedWorkspace)) {
            try (Stream<Path> stream = Files.list(normalizedWorkspace)) {
                for (Path child : stream.filter(Files::isDirectory).sorted().toList()) {
                    Path normalizedChild = child.toAbsolutePath().normalize();
                    if (isEntityRoot(normalizedChild)) {
                        roots.add(normalizedChild);
                    }
                }
            }
        }
        return new ArrayList<>(roots);
    }

    public static String displayRoot(Path workspaceRoot, Path entityRoot) {
        Path normalizedWorkspace = workspaceRoot.toAbsolutePath().normalize();
        Path normalizedEntity = entityRoot.toAbsolutePath().normalize();
        if (normalizedWorkspace.equals(normalizedEntity)) {
            return ".";
        }
        try {
            return normalizedWorkspace.relativize(normalizedEntity).toString();
        } catch (IllegalArgumentException ignored) {
            return normalizedEntity.toString();
        }
    }

    private static boolean isEntityRoot(Path root) throws IOException {
        Path eventDir = root.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return false;
        }
        try (Stream<Path> stream = Files.list(eventDir)) {
            return stream.anyMatch(path -> Files.isRegularFile(path) && path.getFileName().toString().endsWith(".properties"));
        }
    }
}
