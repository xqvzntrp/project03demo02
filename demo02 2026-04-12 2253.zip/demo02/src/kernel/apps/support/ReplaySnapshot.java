package kernel.apps.support;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

import kernel.core.ChainVerifier;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.VerifiedReplayChain;

public final class ReplaySnapshot {
    private ReplaySnapshot() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("Expected eventDir and payloadDir arguments");
        }
        Path eventDir = Path.of(args[0]);
        Path payloadDir = Path.of(args[1]);
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(eventDir, payloadDir);
        ReplayRun replayRun = new Replayer().replay(replayChain, new Replayer.CountingLaw("law-v1"));
        System.out.write(ReplayRunCodec.canonicalHex(replayRun).getBytes(StandardCharsets.UTF_8));
    }
}
