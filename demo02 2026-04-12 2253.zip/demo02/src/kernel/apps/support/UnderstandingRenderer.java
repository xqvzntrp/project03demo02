package kernel.apps.support;

import java.util.ArrayList;
import java.util.List;

import kernel.domain.spi.UnderstandingSection;
import kernel.domain.spi.UnderstandingView;

public final class UnderstandingRenderer {
    private UnderstandingRenderer() {
    }

    public static String render(UnderstandingView understandingView) {
        List<String> lines = new ArrayList<>();
        for (UnderstandingSection section : understandingView.sections()) {
            lines.add(section.title());
            lines.addAll(section.lines());
        }
        return String.join(System.lineSeparator(), lines);
    }
}
