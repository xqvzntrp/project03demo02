package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class PlatformGuiFallbackCheck {
    private PlatformGuiFallbackCheck() {
    }

    public static void main(String[] args) throws Exception {
        String output = runPlatformCliWithHeadlessGui();
        requireContains(output, "gui unavailable, falling back to CLI");
        requireContains(output, "Platform CLI");
        requireContains(output, "PlatformCli --gui [command...]");
        requireContains(output, "Show output:");
        System.out.println("platformGuiFallbackCheckPassed=true");
    }

    private static String runPlatformCliWithHeadlessGui() throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        Process process = new ProcessBuilder(
            javaBinary,
            "-Djava.awt.headless=true",
            "-cp",
            classpath,
            PlatformCli.class.getName(),
            "--gui"
        ).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected headless GUI fallback to succeed but failed: " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }
}
