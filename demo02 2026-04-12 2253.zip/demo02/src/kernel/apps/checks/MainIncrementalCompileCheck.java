package kernel.apps.checks;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.List;

public final class MainIncrementalCompileCheck {
    private MainIncrementalCompileCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkChangedSourceRequiresCompilation();
        checkMissingPrimaryClassRequiresCompilation();
        System.out.println("mainIncrementalCompileCheckPassed=true");
    }

    private static void checkChangedSourceRequiresCompilation() throws Exception {
        Path workspace = Files.createTempDirectory("main-incremental-compile-check-");
        Path sourceDir = workspace.resolve("src");
        Path outputDir = workspace.resolve("build").resolve("classes");

        Path alphaSource = writeJava(sourceDir.resolve(Path.of("demo", "Alpha.java")), "package demo; final class Alpha {}");
        Path betaSource = writeJava(sourceDir.resolve(Path.of("demo", "Beta.java")), "package demo; final class Beta {}");
        Path platformClass = writeFile(outputDir.resolve(Path.of("kernel", "apps", "PlatformCli.class")));
        Path alphaClass = writeFile(outputDir.resolve(Path.of("demo", "Alpha.class")));
        Path betaClass = writeFile(outputDir.resolve(Path.of("demo", "Beta.class")));

        setTime(alphaSource, 2_000L);
        setTime(alphaClass, 1_000L);
        setTime(betaSource, 1_000L);
        setTime(betaClass, 3_000L);
        setTime(platformClass, 3_000L);

        if (!needsCompilation(List.of(alphaSource, betaSource), sourceDir, outputDir)) {
            throw new IllegalStateException("Expected compilation when a source is newer than its class file");
        }
    }

    private static void checkMissingPrimaryClassRequiresCompilation() throws Exception {
        Path workspace = Files.createTempDirectory("main-missing-class-check-");
        Path sourceDir = workspace.resolve("src");
        Path outputDir = workspace.resolve("build").resolve("classes");

        Path alphaSource = writeJava(sourceDir.resolve(Path.of("demo", "Alpha.java")), "package demo; final class Alpha {}");
        Path betaSource = writeJava(sourceDir.resolve(Path.of("demo", "Beta.java")), "package demo; final class Beta {}");
        Path platformClass = writeFile(outputDir.resolve(Path.of("kernel", "apps", "PlatformCli.class")));
        Path betaClass = writeFile(outputDir.resolve(Path.of("demo", "Beta.class")));

        setTime(alphaSource, 1_000L);
        setTime(betaSource, 1_000L);
        setTime(betaClass, 2_000L);
        setTime(platformClass, 2_000L);

        if (!needsCompilation(List.of(alphaSource, betaSource), sourceDir, outputDir)) {
            throw new IllegalStateException("Expected compilation when a source's primary class file is missing");
        }
    }

    private static boolean needsCompilation(List<Path> javaFiles, Path sourceDir, Path outputDir) throws Exception {
        Method method = Class.forName("Main").getDeclaredMethod("needsCompilation", List.class, Path.class, Path.class);
        method.setAccessible(true);
        return (boolean) method.invoke(null, javaFiles, sourceDir, outputDir);
    }

    private static Path writeJava(Path file, String source) throws Exception {
        return Files.writeString(createParent(file), source);
    }

    private static Path writeFile(Path file) throws Exception {
        return Files.write(createParent(file), new byte[] { 0 });
    }

    private static Path createParent(Path file) throws Exception {
        Path parent = file.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        return file;
    }

    private static void setTime(Path path, long millis) throws Exception {
        Files.setLastModifiedTime(path, FileTime.fromMillis(millis));
    }
}
