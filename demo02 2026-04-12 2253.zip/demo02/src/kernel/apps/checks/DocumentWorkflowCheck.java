package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class DocumentWorkflowCheck {
    private DocumentWorkflowCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("document-workflow-check-");

        String draftOutput = runPlatformCli(rootDir, "document", "draft", "--document", "doc-900", "--actor", "alice", "--time", "1");
        requireContains(draftOutput, "drafted=true");

        runPlatformCli(rootDir, "document", "submit", "--document", "doc-900", "--actor", "alice", "--time", "2");
        runPlatformCli(
            rootDir,
            "document",
            "reject",
            "--document",
            "doc-900",
            "--target-event",
            "doc-evt-000002",
            "--reason",
            "needs signature",
            "--actor",
            "bob",
            "--time",
            "3"
        );
        runPlatformCli(rootDir, "document", "revise", "--document", "doc-900", "--actor", "alice", "--time", "4");
        runPlatformCli(rootDir, "document", "submit", "--document", "doc-900", "--actor", "alice", "--time", "5");
        runPlatformCli(rootDir, "document", "approve", "--document", "doc-900", "--actor", "carol", "--time", "6");

        String verifyOutput = runPlatformCli(rootDir, "document", "verify");
        requireContains(verifyOutput, "verified=true");
        requireContains(verifyOutput, "verifiedEventCount=6");

        String showOutput = runPlatformCli(rootDir, "document", "show");
        requireContains(showOutput, "STATE");
        requireContains(showOutput, "  document: doc-900");
        requireContains(showOutput, "  status: APPROVED");
        requireContains(showOutput, "  revision: 2");
        requireContains(showOutput, "  last change: approved by carol at 6");
        requireContains(showOutput, "WHY");
        requireContains(showOutput, "  last rejection: by bob at 3");
        requireContains(showOutput, "  reason: needs signature");
        requireContains(showOutput, "  recovered by: revised to revision 2 by alice at 4");
        requireContains(showOutput, "  resubmitted by: submitted revision 2 by alice at 5");
        requireContains(showOutput, "PATH");
        requireContains(showOutput, "  Drafted v1 -> Submitted -> Rejected -> Revised v2 -> Submitted -> Approved");
        requireContains(showOutput, "TRACE");
        requireContains(showOutput, "  [doc-evt-000001] drafted revision 1 by alice at 1");
        requireContains(showOutput, "  [doc-evt-000002] submitted revision 1 by alice at 2");
        requireContains(showOutput, "  [doc-evt-000003] rejected by bob at 3");
        requireContains(showOutput, "  [doc-evt-000004] revised to revision 2 by alice at 4");
        requireContains(showOutput, "  [doc-evt-000005] submitted revision 2 by alice at 5");
        requireContains(showOutput, "  [doc-evt-000006] approved by carol at 6");
        requireContains(showOutput, "OUTPUTS");
        requireContains(showOutput, "document-rejected");
        requireContains(showOutput, "document-approved");

        expectFailureAndUnchanged(
            rootDir,
            "DocumentApproved requires status IN_REVIEW but found APPROVED",
            "document",
            "approve",
            "--document",
            "doc-900"
        );

        expectFailureAndUnchanged(
            rootDir,
            "Document id doc-wrong does not match existing chain document doc-900",
            "document",
            "submit",
            "--document",
            "doc-wrong"
        );

        String stableView = runPlatformCli(rootDir, "document", "show");
        if (!showOutput.equals(stableView)) {
            throw new IllegalStateException("Document explanation changed after failed commands");
        }

        System.out.println("documentWorkflowCheckPassed=true");
    }

    private static void expectFailureAndUnchanged(Path rootDir, String expectedMessage, String... cliArgs) throws Exception {
        int before = eventCount(rootDir);
        String beforeListing = eventListing(rootDir);
        String output = runPlatformCliFailure(rootDir, cliArgs);
        requireContains(output, expectedMessage);
        int after = eventCount(rootDir);
        String afterListing = eventListing(rootDir);
        if (before != after || !beforeListing.equals(afterListing)) {
            throw new IllegalStateException("On-disk document chain changed after failed workflow step");
        }
    }

    private static int eventCount(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return 0;
        }
        try (var stream = Files.list(eventDir)) {
            return (int) stream.filter(Files::isRegularFile).count();
        }
    }

    private static String eventListing(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return "";
        }
        try (var stream = Files.list(eventDir)) {
            return stream
                .filter(Files::isRegularFile)
                .map(path -> path.getFileName().toString())
                .sorted()
                .reduce("", (left, right) -> left + "|" + right);
        }
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + result.output());
        }
        return result.output();
    }

    private static String runPlatformCliFailure(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() == 0) {
            throw new IllegalStateException("Expected PlatformCli failure but succeeded: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runPlatformCliProcess(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private record ProcessResult(int exitCode, String output) {
    }
}
