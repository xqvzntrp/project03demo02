package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.accountcli.AccountCli;

public final class AccountFlowShellCheck {
    private AccountFlowShellCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkExplicitRootOpen();
        checkExplicitRootDeposit();
        checkNewRootOpen();
        System.out.println("accountFlowShellCheckPassed=true");
    }

    private static void checkExplicitRootOpen() throws Exception {
        Path rootDir = Files.createTempDirectory("account-flow-shell-open-check-");
        String input = String.join(
            System.lineSeparator(),
            "acct-100",
            "alice",
            "1",
            "",
            ""
        );

        String output = runShell(input, "--root", rootDir.toString());
        requireContains(output, "Account Flow");
        requireContains(output, "next: account open");
        requireContains(output, "account open --account acct-100 --root " + rootDir + " --actor alice --time 1");
        requireContains(output, "[state]");
        requireContains(output, "  account: acct-100");
        requireContains(output, "  status: OPEN");
        requireContains(output, "[next]");
        requireContains(output, "  - account deposit --account acct-100 --amount <n>");
    }

    private static void checkExplicitRootDeposit() throws Exception {
        Path rootDir = Files.createTempDirectory("account-flow-shell-deposit-check-");
        runCli(rootDir, "open", "--account", "acct-200", "--actor", "alice", "--time", "1");

        String input = String.join(
            System.lineSeparator(),
            "50",
            "bob",
            "2",
            "",
            ""
        );

        String output = runShell(input, "--root", rootDir.toString());
        requireContains(output, "next: account deposit");
        requireContains(output, "account deposit --account acct-200 --amount 50 --root " + rootDir + " --actor bob --time 2");
        requireContains(output, "eventType=FundsDeposited");
        requireContains(output, "[state]");
        requireContains(output, "  balance: 50");
        requireContains(output, "[next]");
        requireContains(output, "  - account deposit --account acct-200 --amount <n>");
    }

    private static void checkNewRootOpen() throws Exception {
        String input = String.join(
            System.lineSeparator(),
            "acct-300",
            "alice",
            "1",
            "",
            ""
        );

        String output = runShell(input, "--new");
        requireContains(output, "Using new root: build\\platform\\sandbox\\account-");
        requireContains(output, "Root: build\\platform\\sandbox\\account-");
        requireContains(output, "next: account open");
        requireContains(output, "opened=true");
    }

    private static void runCli(Path rootDir, String... args) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");
        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(AccountCli.class.getName());
        for (String arg : args) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected account CLI success but failed: " + output);
        }
    }

    private static String runShell(String input, String... shellArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(AccountCli.class.getName());
        command.add("flow");
        for (String shellArg : shellArgs) {
            command.add(shellArg);
        }

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        try (OutputStream outputStream = process.getOutputStream()) {
            String normalizedInput = input.endsWith(System.lineSeparator()) ? input : input + System.lineSeparator();
            outputStream.write(normalizedInput.getBytes(StandardCharsets.UTF_8));
        }

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected account flow shell success but failed: " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }
}
