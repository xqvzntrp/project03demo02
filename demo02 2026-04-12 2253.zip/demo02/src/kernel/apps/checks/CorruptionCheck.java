package kernel.apps.checks;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.support.SampleChain;
import kernel.core.ChainVerifier;

public final class CorruptionCheck {
    private CorruptionCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("kernel-corruption-check-");
        SampleChain.SampleData sampleData = SampleChain.create(rootDir);
        Path secondEventPath = sampleData.eventDir().resolve(sampleData.secondHash() + ".properties");

        String original = Files.readString(secondEventPath, StandardCharsets.UTF_8);
        String corrupted = original.replace("actor-02", "actor-99");
        if (original.equals(corrupted)) {
            throw new IllegalStateException("Failed to corrupt event file");
        }
        Files.writeString(secondEventPath, corrupted, StandardCharsets.UTF_8);

        boolean failedAsExpected = false;
        try {
            ChainVerifier.verifiedChain(sampleData.eventDir());
        } catch (Exception expected) {
            failedAsExpected = true;
            System.out.println("corruptionFailure=" + expected.getClass().getSimpleName());
        }

        if (!failedAsExpected) {
            throw new IllegalStateException("Verification unexpectedly succeeded after event corruption");
        }

        System.out.println("corruptionCheckPassed=true");
    }
}
