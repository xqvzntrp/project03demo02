package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.taskcli.TaskCli;

public final class TaskFlowShellCheck {
    private TaskFlowShellCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkExplicitRootCreate();
        checkExplicitRootStart();
        checkExplicitRootComplete();
        checkNewRootCreate();
        System.out.println("taskFlowShellCheckPassed=true");
    }

    private static void checkExplicitRootCreate() throws Exception {
        Path rootDir = Files.createTempDirectory("task-flow-shell-create-check-");
        String input = String.join(
            System.lineSeparator(),
            "task-100",
            "alice",
            "1",
            "",
            ""
        );

        String output = runShell(rootDir, input);
        requireContains(output, "Task Flow");
        requireContains(output, "next: task create");
        requireContains(output, "task create --task task-100 --root " + rootDir + " --actor alice --time 1");
        requireContains(output, "[state]");
        requireContains(output, "  task: task-100");
        requireContains(output, "  status: CREATED");
        requireContains(output, "[next]");
        requireContains(output, "  - task start --task task-100");
        requireContains(output, "  - task cancel --task task-100");
    }

    private static void checkExplicitRootStart() throws Exception {
        Path rootDir = Files.createTempDirectory("task-flow-shell-start-check-");
        runCli(rootDir, "create", "--task", "task-150", "--actor", "alice", "--time", "1");

        String input = String.join(
            System.lineSeparator(),
            "bob",
            "2",
            "",
            ""
        );

        String output = runShell(rootDir, input);
        requireContains(output, "next: task start");
        requireContains(output, "task start --task task-150 --root " + rootDir + " --actor bob --time 2");
        requireContains(output, "eventType=TaskStarted");
        requireContains(output, "[state]");
        requireContains(output, "  status: ACTIVE");
        requireContains(output, "[next]");
        requireContains(output, "  - task complete --task task-150");
        requireContains(output, "  - task cancel --task task-150");
    }

    private static void checkExplicitRootComplete() throws Exception {
        Path rootDir = Files.createTempDirectory("task-flow-shell-complete-check-");
        runCli(rootDir, "create", "--task", "task-175", "--actor", "alice", "--time", "1");
        runCli(rootDir, "start", "--task", "task-175", "--actor", "bob", "--time", "2");

        String input = String.join(
            System.lineSeparator(),
            "carol",
            "3",
            "",
            ""
        );

        String output = runShell(rootDir, input);
        requireContains(output, "next: task complete");
        requireContains(output, "task complete --task task-175 --root " + rootDir + " --actor carol --time 3");
        requireContains(output, "eventType=TaskCompleted");
        requireContains(output, "[state]");
        requireContains(output, "  status: DONE");
        requireContains(output, "[next]");
        requireContains(output, "  - task correct --task task-175 --target-event task-evt-000003 --reason <text>");
    }

    private static void checkNewRootCreate() throws Exception {
        String input = String.join(
            System.lineSeparator(),
            "task-200",
            "alice",
            "1",
            "",
            ""
        );

        String output = runShell(input, "--new");
        requireContains(output, "Using new root: build\\platform\\sandbox\\task-");
        requireContains(output, "Root: build\\platform\\sandbox\\task-");
        requireContains(output, "Task Flow");
        requireContains(output, "created=true");
        requireContains(output, "[next]");
        requireContains(output, "  - task start --task task-200");
    }

    private static String runShell(Path rootDir, String input) throws Exception {
        return runShell(input, "--root", rootDir.toString());
    }

    private static String runShell(String input, String... shellArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(TaskCli.class.getName());
        command.add("flow");
        for (String shellArg : shellArgs) {
            command.add(shellArg);
        }

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        try (OutputStream outputStream = process.getOutputStream()) {
            String normalizedInput = input.endsWith(System.lineSeparator()) ? input : input + System.lineSeparator();
            outputStream.write(normalizedInput.getBytes(StandardCharsets.UTF_8));
        }

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected task flow shell success but failed: " + output);
        }
        return output;
    }

    private static void runCli(Path rootDir, String... args) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(TaskCli.class.getName());
        for (String arg : args) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected task CLI success but failed: " + output);
        }
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }
}
