package kernel.apps.checks;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.support.SampleChain;
import kernel.core.ChainVerifier;
import kernel.core.EventProperties;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.StoredEvent;
import kernel.core.VerifiedReplayChain;

public final class PropertiesLayoutIndependenceCheck {
    private PropertiesLayoutIndependenceCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("kernel-properties-layout-check-");
        SampleChain.SampleData sampleData = SampleChain.create(rootDir);
        Path eventPath = sampleData.eventDir().resolve(sampleData.secondHash() + ".properties");

        String original = Files.readString(eventPath, StandardCharsets.UTF_8);
        String rewritten = String.join(
            "\r\n",
            "# reordered properties with comments and spacing",
            "",
            "  timeValue : 2",
            "eventHash = " + sampleData.secondHash(),
            "! comments must stay non-semantic",
            "payloadHash\t:\t" + sampleData.secondEvent().payloadHash(),
            "eventType = " + sampleData.secondEvent().eventType(),
            "actorId:actor-02",
            "lawVersion = " + sampleData.secondEvent().lawVersion(),
            "previousHash = " + sampleData.firstHash(),
            "",
            "eventId = " + sampleData.secondEvent().eventId(),
            ""
        );
        if (original.equals(rewritten)) {
            throw new IllegalStateException("Expected rewritten event file layout to differ from original");
        }
        Files.writeString(eventPath, rewritten, StandardCharsets.UTF_8);

        StoredEvent storedEvent = EventProperties.read(eventPath);
        if (!storedEvent.event().equals(sampleData.secondEvent())) {
            throw new IllegalStateException("Expected rewritten properties layout to parse to the same canonical event");
        }
        if (!storedEvent.eventHash().equals(sampleData.secondHash())) {
            throw new IllegalStateException("Expected rewritten properties layout to preserve the canonical event hash");
        }

        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(sampleData.eventDir(), sampleData.payloadDir());
        ReplayRun replayRun = new Replayer().replay(replayChain, new Replayer.CountingLaw("law-v1"));
        if (replayRun.finalState().eventCount() != 2) {
            throw new IllegalStateException("Expected replay event count 2 but found " + replayRun.finalState().eventCount());
        }

        System.out.println("propertiesLayoutIndependenceCheckPassed=true");
    }
}
