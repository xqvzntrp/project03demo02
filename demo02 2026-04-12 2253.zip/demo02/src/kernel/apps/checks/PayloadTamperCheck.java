package kernel.apps.checks;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.support.SampleChain;
import kernel.core.ChainVerifier;
import kernel.core.PayloadCas;

public final class PayloadTamperCheck {
    private PayloadTamperCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("kernel-payload-tamper-check-");
        SampleChain.SampleData sampleData = SampleChain.create(rootDir);
        Path payloadPath = PayloadCas.pathForHash(sampleData.payloadDir(), sampleData.secondEvent().payloadHash());

        Files.writeString(payloadPath, "tampered payload", StandardCharsets.UTF_8);

        expectFailureContains(
            "Payload hash mismatch",
            () -> ChainVerifier.verifiedReplayChain(sampleData.eventDir(), sampleData.payloadDir())
        );

        System.out.println("payloadTamperCheckPassed=true");
    }

    private static void expectFailureContains(String expected, ThrowingRunnable runnable) throws Exception {
        try {
            runnable.run();
        } catch (Exception expectedFailure) {
            if (!expectedFailure.getMessage().contains(expected)) {
                throw new IllegalStateException(
                    "Expected failure containing '" + expected + "' but was: " + expectedFailure.getMessage(),
                    expectedFailure
                );
            }
            return;
        }
        throw new IllegalStateException("Expected failure containing '" + expected + "'");
    }

    @FunctionalInterface
    private interface ThrowingRunnable {
        void run() throws Exception;
    }
}
