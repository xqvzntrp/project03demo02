package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class PlatformListCheck {
    private PlatformListCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkTaskList();
        checkAccountList();
        checkDocumentList();
        System.out.println("platformListCheckPassed=true");
    }

    private static void checkTaskList() throws Exception {
        Path workspace = Files.createTempDirectory("task-list-check-");
        runPlatformCli(workspace, "task", "create", "--task", "task-root", "--actor", "alice", "--time", "1");
        Path childRoot = workspace.resolve("task-child");
        runPlatformCli(childRoot, "task", "create", "--task", "task-child-id", "--actor", "bob", "--time", "1");

        String output = runPlatformCli(workspace, "task", "list");
        requireContains(output, "STATE");
        requireContains(output, "  tasks: 2");
        requireContains(output, "TRACE");
        requireContains(output, "  [.] task-root CREATED");
        requireContains(output, "  [task-child] task-child-id CREATED");
        requireContains(output, "OUTPUTS");
        requireContains(output, "  - task show");
        requireContains(output, "  - task show --root " + quote(childRoot.toString()));
    }

    private static void checkAccountList() throws Exception {
        Path workspace = Files.createTempDirectory("account-list-check-");
        runPlatformCli(workspace, "account", "open", "--account", "acct-root", "--actor", "alice", "--time", "1");
        Path childRoot = workspace.resolve("acct-child");
        runPlatformCli(childRoot, "account", "open", "--account", "acct-child-id", "--actor", "bob", "--time", "1");

        String output = runPlatformCli(workspace, "account", "list");
        requireContains(output, "  accounts: 2");
        requireContains(output, "  [.] acct-root OPEN balance=0");
        requireContains(output, "  [acct-child] acct-child-id OPEN balance=0");
        requireContains(output, "  - account show");
        requireContains(output, "  - account show --root " + quote(childRoot.toString()));
    }

    private static void checkDocumentList() throws Exception {
        Path workspace = Files.createTempDirectory("document-list-check-");
        runPlatformCli(workspace, "document", "draft", "--document", "doc-root", "--actor", "alice", "--time", "1");
        Path childRoot = workspace.resolve("doc-child");
        runPlatformCli(childRoot, "document", "draft", "--document", "doc-child-id", "--actor", "bob", "--time", "1");

        String output = runPlatformCli(workspace, "document", "list");
        requireContains(output, "  documents: 2");
        requireContains(output, "  [.] doc-root DRAFT revision=1");
        requireContains(output, "  [doc-child] doc-child-id DRAFT revision=1");
        requireContains(output, "  - document show");
        requireContains(output, "  - document show --root " + quote(childRoot.toString()));
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private static String quote(String value) {
        return value.indexOf(' ') >= 0 ? "\"" + value.replace("\"", "\\\"") + "\"" : value;
    }
}
