package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import kernel.apps.taskcli.TaskCli;

public final class TaskCliRobustnessCheck {
    private TaskCliRobustnessCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-cli-robustness-check-");

        runCliSuccess(rootDir, "create", "--task", "task-300", "--actor", "alice", "--time", "1");
        runCliSuccess(rootDir, "start", "--task", "task-300", "--actor", "alice", "--time", "2");
        assertEventCount(rootDir, 2);

        expectFailureAndUnchanged(rootDir, "Missing required option --task", "complete");
        expectFailureAndUnchanged(rootDir, "does not match existing chain task", "complete", "--task", "task-wrong");
        expectFailureAndUnchanged(rootDir, "For input string: \"nope\"", "complete", "--task", "task-300", "--time", "nope");
        expectFailureAndUnchanged(rootDir, "Task already exists at this root", "create", "--task", "task-300");
        expectFailureAndUnchanged(rootDir, "TaskStarted requires status CREATED or REOPENED but found ACTIVE", "start", "--task", "task-300");

        TaskLawCheck.main(new String[0]);

        System.out.println("taskCliRobustnessCheckPassed=true");
    }

    private static void expectFailureAndUnchanged(Path rootDir, String expectedMessage, String... args) throws Exception {
        int before = eventCount(rootDir);
        String beforeListing = eventListing(rootDir);
        String output = runCliFailure(rootDir, args);
        requireContains(output, expectedMessage);
        int after = eventCount(rootDir);
        String afterListing = eventListing(rootDir);
        if (before != after || !beforeListing.equals(afterListing)) {
            throw new IllegalStateException("On-disk chain changed after failed CLI command");
        }
    }

    private static void assertEventCount(Path rootDir, int expected) throws Exception {
        int actual = eventCount(rootDir);
        if (actual != expected) {
            throw new IllegalStateException("Expected " + expected + " events but found " + actual);
        }
    }

    private static int eventCount(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return 0;
        }
        try (var stream = Files.list(eventDir)) {
            return (int) stream.filter(Files::isRegularFile).count();
        }
    }

    private static String eventListing(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return "";
        }
        try (var stream = Files.list(eventDir)) {
            return stream
                .filter(Files::isRegularFile)
                .map(path -> path.getFileName().toString())
                .sorted()
                .reduce("", (left, right) -> left + "|" + right);
        }
    }

    private static String runCliSuccess(Path rootDir, String... args) throws Exception {
        ProcessResult result = runCli(rootDir, args);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected CLI success but failed: " + result.output());
        }
        return result.output();
    }

    private static String runCliFailure(Path rootDir, String... args) throws Exception {
        ProcessResult result = runCli(rootDir, args);
        if (result.exitCode() == 0) {
            throw new IllegalStateException("Expected CLI failure but succeeded: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runCli(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(TaskCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private record ProcessResult(int exitCode, String output) {
    }
}
