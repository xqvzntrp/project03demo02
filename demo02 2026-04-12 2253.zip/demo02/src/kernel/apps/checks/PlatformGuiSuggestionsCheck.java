package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;
import kernel.apps.PlatformGuiSuggestions;

public final class PlatformGuiSuggestionsCheck {
    private PlatformGuiSuggestionsCheck() {
    }

    public static void main(String[] args) {
        checkBlankSuggestions();
        checkTaskSuggestions();
        checkDocumentSuggestions();
        checkDynamicEntitySuggestions();
        checkCliSuggestions();
        System.out.println("platformGuiSuggestionsCheckPassed=true");
    }

    private static void checkBlankSuggestions() {
        List<String> suggestions = PlatformGuiSuggestions.suggestionsFor("");
        requireContains(suggestions, "task show");
        requireContains(suggestions, "account show");
        requireContains(suggestions, "document show");
    }

    private static void checkTaskSuggestions() {
        List<String> suggestions = PlatformGuiSuggestions.suggestionsFor("task c");
        requireContains(suggestions, "task create --task <taskId>");
        requireContains(suggestions, "task complete --task <taskId>");
        requireContains(suggestions, "task correct --task <taskId> --target-event <eventId> --reason <text>");
    }

    private static void checkDocumentSuggestions() {
        List<String> suggestions = PlatformGuiSuggestions.suggestionsFor("document re");
        requireContains(suggestions, "document reject --document <documentId> --target-event <eventId> --reason <text>");
        requireContains(suggestions, "document revise --document <documentId>");
    }

    private static void checkDynamicEntitySuggestions() {
        try {
            Path taskWorkspace = Files.createTempDirectory("gui-task-suggestions-");
            Path accountWorkspace = Files.createTempDirectory("gui-account-suggestions-");
            Path documentWorkspace = Files.createTempDirectory("gui-document-suggestions-");

            runPlatformCli(taskWorkspace, "task", "create", "--task", "task-known", "--actor", "alice", "--time", "1");
            Path childTaskRoot = taskWorkspace.resolve("task-child");
            runPlatformCli(childTaskRoot, "task", "create", "--task", "task-child-id", "--actor", "bob", "--time", "1");

            runPlatformCli(accountWorkspace, "account", "open", "--account", "acct-known", "--actor", "alice", "--time", "1");
            runPlatformCli(documentWorkspace, "document", "draft", "--document", "doc-known", "--actor", "alice", "--time", "1");

            List<String> taskSuggestions = PlatformGuiSuggestions.suggestionsFor("task show", taskWorkspace, accountWorkspace, documentWorkspace);
            requireContains(taskSuggestions, "task show");
            requireContains(taskSuggestions, "task show --root " + quote(childTaskRoot.toString()));

            List<String> accountSuggestions = PlatformGuiSuggestions.suggestionsFor("account show", taskWorkspace, accountWorkspace, documentWorkspace);
            requireContains(accountSuggestions, "account show");

            List<String> documentSuggestions = PlatformGuiSuggestions.suggestionsFor("document show", taskWorkspace, accountWorkspace, documentWorkspace);
            requireContains(documentSuggestions, "document show");
        } catch (Exception e) {
            throw new IllegalStateException("Dynamic suggestion check failed", e);
        }
    }

    private static void checkCliSuggestions() {
        try {
            Path taskWorkspace = Files.createTempDirectory("cli-task-suggestions-");
            Path childTaskRoot = taskWorkspace.resolve("task-child");

            runPlatformCli(taskWorkspace, "task", "create", "--task", "task-known", "--actor", "alice", "--time", "1");
            runPlatformCli(childTaskRoot, "task", "create", "--task", "task-child-id", "--actor", "bob", "--time", "1");

            String output = runPlatformCliCapture(
                null,
                "suggest",
                "--root",
                taskWorkspace.toString(),
                "task",
                "show"
            );
            requireContains(output, "SUGGESTIONS");
            requireContains(output, "  - task show");
            requireContains(output, "    options: --root <dir>");
            requireContains(output, "  - task show --root " + quote(childTaskRoot.toString()));

            String createOutput = runPlatformCliCapture(
                null,
                "suggest",
                "task",
                "create"
            );
            requireContains(createOutput, "  - task create --task <taskId>");
            requireContains(createOutput, "    options: --root <dir>, --actor <actor>, --time <time>");
        } catch (Exception e) {
            throw new IllegalStateException("CLI suggestion check failed", e);
        }
    }

    private static void requireContains(List<String> suggestions, String expected) {
        if (!suggestions.contains(expected)) {
            throw new IllegalStateException("Expected suggestions to contain '" + expected + "' but were: " + suggestions);
        }
    }

    private static void runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        String output = runPlatformCliCapture(rootDir, commandArgs);
        if (output == null) {
            throw new IllegalStateException("Expected PlatformCli success but got no output");
        }
    }

    private static String runPlatformCliCapture(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        if (rootDir != null) {
            command.add("--root");
            command.add(rootDir.toString());
        }

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private static String quote(String value) {
        return value.indexOf(' ') >= 0 ? "\"" + value.replace("\"", "\\\"") + "\"" : value;
    }
}
