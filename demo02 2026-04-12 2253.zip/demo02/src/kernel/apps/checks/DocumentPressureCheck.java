package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class DocumentPressureCheck {
    private DocumentPressureCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("document-pressure-check-");

        runPlatformCli(rootDir, "document", "draft", "--document", "doc-980", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "document", "submit", "--document", "doc-980", "--actor", "alice", "--time", "2");
        runPlatformCli(
            rootDir,
            "document",
            "reject",
            "--document",
            "doc-980",
            "--target-event",
            "doc-evt-000002",
            "--reason",
            "needs signature",
            "--actor",
            "bob",
            "--time",
            "3"
        );
        runPlatformCli(rootDir, "document", "revise", "--document", "doc-980", "--actor", "alice", "--time", "4");
        runPlatformCli(rootDir, "document", "submit", "--document", "doc-980", "--actor", "alice", "--time", "5");
        runPlatformCli(
            rootDir,
            "document",
            "reject",
            "--document",
            "doc-980",
            "--target-event",
            "doc-evt-000005",
            "--reason",
            "add appendix",
            "--actor",
            "carol",
            "--time",
            "6"
        );
        runPlatformCli(rootDir, "document", "revise", "--document", "doc-980", "--actor", "alice", "--time", "7");
        runPlatformCli(rootDir, "document", "submit", "--document", "doc-980", "--actor", "alice", "--time", "8");
        runPlatformCli(rootDir, "document", "approve", "--document", "doc-980", "--actor", "dana", "--time", "9");

        String showOutput = runPlatformCli(rootDir, "document", "show");
        requireContains(showOutput, "STATE");
        requireContains(showOutput, "  document: doc-980");
        requireContains(showOutput, "  status: APPROVED");
        requireContains(showOutput, "  revision: 3");
        requireContains(showOutput, "  last change: approved by dana at 9");
        requireContains(showOutput, "WHY");
        requireContains(showOutput, "  review cycles: 2 rejections before approval");
        requireContains(showOutput, "  last rejection: by carol at 6");
        requireContains(showOutput, "  reason: add appendix");
        requireContains(showOutput, "  earlier rejection: needs signature by bob at 3");
        requireContains(showOutput, "  recovered by: revised to revision 3 by alice at 7");
        requireContains(showOutput, "  resubmitted by: submitted revision 3 by alice at 8");
        requireContains(showOutput, "PATH");
        requireContains(showOutput, "  Drafted v1 -> Submitted -> Rejected -> Revised v2 -> Submitted -> Rejected -> Revised v3 -> Submitted -> Approved");
        requireContains(showOutput, "TRACE");
        requireContains(showOutput, "  [doc-evt-000003] rejected by bob at 3");
        requireContains(showOutput, "  [doc-evt-000006] rejected by carol at 6");
        requireContains(showOutput, "  [doc-evt-000009] approved by dana at 9");

        expectFailureAndUnchanged(
            rootDir,
            "DocumentApproved requires status IN_REVIEW but found APPROVED",
            "document",
            "approve",
            "--document",
            "doc-980",
            "--actor",
            "erin",
            "--time",
            "10"
        );

        String stableView = runPlatformCli(rootDir, "document", "show");
        if (!showOutput.equals(stableView)) {
            throw new IllegalStateException("Document explanation changed after failed approval retry");
        }

        System.out.println("documentPressureCheckPassed=true");
    }

    private static void expectFailureAndUnchanged(Path rootDir, String expectedMessage, String... cliArgs) throws Exception {
        int before = eventCount(rootDir);
        String beforeListing = eventListing(rootDir);
        String output = runPlatformCliFailure(rootDir, cliArgs);
        requireContains(output, expectedMessage);
        int after = eventCount(rootDir);
        String afterListing = eventListing(rootDir);
        if (before != after || !beforeListing.equals(afterListing)) {
            throw new IllegalStateException("On-disk document chain changed after failed workflow step");
        }
    }

    private static int eventCount(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return 0;
        }
        try (var stream = Files.list(eventDir)) {
            return (int) stream.filter(Files::isRegularFile).count();
        }
    }

    private static String eventListing(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return "";
        }
        try (var stream = Files.list(eventDir)) {
            return stream
                .filter(Files::isRegularFile)
                .map(path -> path.getFileName().toString())
                .sorted()
                .reduce("", (left, right) -> left + "|" + right);
        }
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + result.output());
        }
        return result.output();
    }

    private static String runPlatformCliFailure(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() == 0) {
            throw new IllegalStateException("Expected PlatformCli failure but succeeded: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runPlatformCliProcess(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private record ProcessResult(int exitCode, String output) {
    }
}
