package kernel.apps.checks;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.Replayer;
import kernel.core.VerifiedReplayChain;
import kernel.laws.task.TaskEventWriter;
import kernel.laws.task.TaskLaw;

public final class TaskLawCheck {
    private TaskLawCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-law-check-");
        Path eventDir = rootDir.resolve("events");
        Path payloadDir = rootDir.resolve("payloads");
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);

        String lawVersion = "task-law-v1";
        TaskEventWriter.WrittenTaskEvent created = TaskEventWriter.write(
            eventDir,
            payloadDir,
            "task-evt-0001",
            "TaskCreated",
            EventCodec.INITIAL_POINTER_SENTINEL,
            "task-001",
            lawVersion,
            "actor-01",
            1L
        );
        TaskEventWriter.write(
            eventDir,
            payloadDir,
            "task-evt-0002",
            "TaskCompleted",
            created.eventHash(),
            "task-001",
            lawVersion,
            "actor-01",
            2L
        );

        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(eventDir, payloadDir);

        boolean failedAsExpected = false;
        try {
            new Replayer().replay(replayChain, new TaskLaw(lawVersion));
        } catch (Exception expected) {
            failedAsExpected = true;
            System.out.println("invalidTransitionFailure=" + expected.getClass().getSimpleName());
        }

        if (!failedAsExpected) {
            throw new IllegalStateException("Task law unexpectedly accepted an impossible transition");
        }

        System.out.println("taskLawCheckPassed=true");
    }
}
