package kernel.apps.checks;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.flow.TaskFlow;

public final class TaskFlowCheck {
    private TaskFlowCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-flow-check-");

        TaskFlow.TaskFlowSession session = TaskFlow.begin(rootDir);
        requireEquals("task", session.currentField());
        session = session.answer("task-100");
        requireEquals("actor", session.currentField());
        session = session.answer("alice");
        requireEquals("time", session.currentField());
        session = session.answer("1");
        requireEquals(
            "task create --task task-100 --root " + rootDir + " --actor alice --time 1",
            session.commandPreview()
        );
        TaskFlow.TaskFlowExecution create = session.execute();
        requireEquals(0, create.exitCode());
        requireContains(create.output(), "created=true");

        session = create.nextSession();
        requireEquals(TaskFlow.Action.START, session.action());
        session = session.answer("bob").answer("2");
        requireEquals(
            "task start --task task-100 --root " + rootDir + " --actor bob --time 2",
            session.commandPreview()
        );
        TaskFlow.TaskFlowExecution start = session.execute();
        requireEquals(0, start.exitCode());
        requireContains(start.output(), "eventType=TaskStarted");

        session = start.nextSession();
        requireEquals(TaskFlow.Action.COMPLETE, session.action());
        session = session.answer("carol").answer("3");
        requireEquals(
            "task complete --task task-100 --root " + rootDir + " --actor carol --time 3",
            session.commandPreview()
        );
        TaskFlow.TaskFlowExecution complete = session.execute();
        requireEquals(0, complete.exitCode());
        requireContains(complete.output(), "eventType=TaskCompleted");

        session = complete.nextSession();
        if (!session.isFinished()) {
            throw new IllegalStateException("Expected guided task flow to stop after complete but found " + session.action());
        }

        System.out.println("taskFlowCheckPassed=true");
    }

    private static void requireContains(String actual, String expected) {
        if (!actual.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + actual);
        }
    }

    private static void requireEquals(Object expected, Object actual) {
        if (!expected.equals(actual)) {
            throw new IllegalStateException("Expected '" + expected + "' but was '" + actual + "'");
        }
    }
}
