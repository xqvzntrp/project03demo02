package kernel.apps.checks;

import java.nio.charset.StandardCharsets;
import java.util.Properties;

import kernel.core.Event;
import kernel.core.EventCodec;
import kernel.core.EventPropertiesAccess;

public final class CanonicalizationCheck {
    private CanonicalizationCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkEmptyStringDeterminism();
        checkNullRejected();
        checkAbsentRejected();
        checkUnicodeDeterminism();
        checkBoundaryPayloadHashes();
        System.out.println("canonicalizationCheckPassed=true");
    }

    private static void checkEmptyStringDeterminism() {
        Event event = new Event(
            "evt-empty",
            "DocumentCreated",
            EventCodec.INITIAL_POINTER_SENTINEL,
            EventCodec.payloadHash(new byte[0]),
            "law-v1",
            "",
            0L
        );
        String firstHash = EventCodec.eventHash(event);
        String secondHash = EventCodec.eventHash(event);
        if (!firstHash.equals(secondHash)) {
            throw new IllegalStateException("Empty-string event hash is not deterministic");
        }
    }

    private static void checkNullRejected() {
        Event event = new Event(
            "evt-null",
            "DocumentCreated",
            null,
            EventCodec.payloadHash(new byte[0]),
            "law-v1",
            "actor-01",
            1L
        );
        expectFailure("null previousHash should be rejected", () -> EventCodec.eventHash(event));
    }

    private static void checkAbsentRejected() {
        Properties properties = new Properties();
        properties.setProperty("eventId", "evt-absent");
        properties.setProperty("eventType", "DocumentCreated");
        properties.setProperty("previousHash", EventCodec.INITIAL_POINTER_SENTINEL);
        properties.setProperty("payloadHash", EventCodec.payloadHash(new byte[0]));
        properties.setProperty("lawVersion", "law-v1");
        properties.setProperty("timeValue", "1");
        expectFailure("absent actorId should be rejected", () -> {
            EventPropertiesAccess.readFromProperties(properties);
        });
    }

    private static void checkUnicodeDeterminism() {
        byte[] payload = "snowman-☃-雪".getBytes(StandardCharsets.UTF_8);
        Event event = new Event(
            "evt-unicode-☃",
            "DocumentSigned",
            EventCodec.INITIAL_POINTER_SENTINEL,
            EventCodec.payloadHash(payload),
            "law-v1",
            "actor-雪",
            2L
        );
        String firstHash = EventCodec.eventHash(event);
        String secondHash = EventCodec.eventHash(event);
        if (!firstHash.equals(secondHash)) {
            throw new IllegalStateException("Unicode event hash is not deterministic");
        }
    }

    private static void checkBoundaryPayloadHashes() {
        assertPayloadHashDeterministic(new byte[0], "payload length 0");
        assertPayloadHashDeterministic(new byte[] { 0x41 }, "payload length 1");
        assertPayloadHashDeterministic(new byte[65536], "payload length 65536");
    }

    private static void assertPayloadHashDeterministic(byte[] payload, String label) {
        String firstHash = EventCodec.payloadHash(payload);
        String secondHash = EventCodec.payloadHash(payload);
        if (!firstHash.equals(secondHash)) {
            throw new IllegalStateException(label + " hash is not deterministic");
        }
    }

    private static void expectFailure(String message, ThrowingRunnable runnable) {
        try {
            runnable.run();
        } catch (Exception expected) {
            return;
        }
        throw new IllegalStateException(message);
    }

    @FunctionalInterface
    private interface ThrowingRunnable {
        void run() throws Exception;
    }
}
