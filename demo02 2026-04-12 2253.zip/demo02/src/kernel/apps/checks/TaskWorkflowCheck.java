package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class TaskWorkflowCheck {
    private TaskWorkflowCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-workflow-check-");

        String createOutput = runPlatformCli(rootDir, "task", "create", "--task", "task-900", "--actor", "alice", "--time", "1");
        requireContains(createOutput, "created=true");

        String createdView = runPlatformCli(rootDir, "task", "show");
        requireContains(createdView, "STATE");
        requireContains(createdView, "  task: task-900");
        requireContains(createdView, "  status: CREATED");
        requireContains(createdView, "  last change: created by alice at 1");

        String startOutput = runPlatformCli(rootDir, "task", "start", "--task", "task-900", "--actor", "alice", "--time", "2");
        requireContains(startOutput, "appended=true");
        requireContains(startOutput, "eventType=TaskStarted");

        String verifyAfterRestart = runPlatformCli(rootDir, "task", "verify");
        requireContains(verifyAfterRestart, "verified=true");
        requireContains(verifyAfterRestart, "verifiedEventCount=2");

        String activeView = runPlatformCli(rootDir, "task", "show");
        requireContains(activeView, "  status: ACTIVE");
        requireContains(activeView, "  last change: started by alice at 2");
        requireContains(activeView, "  Created -> Started");

        expectFailureAndUnchanged(
            rootDir,
            "does not match existing chain task",
            "task",
            "complete",
            "--task",
            "task-wrong"
        );

        expectFailureAndUnchanged(
            rootDir,
            "TaskStarted requires status CREATED or REOPENED but found ACTIVE",
            "task",
            "start",
            "--task",
            "task-900"
        );

        String completeOutput = runPlatformCli(rootDir, "task", "complete", "--task", "task-900", "--actor", "alice", "--time", "3");
        requireContains(completeOutput, "appended=true");
        requireContains(completeOutput, "eventType=TaskCompleted");

        String doneView = runPlatformCli(rootDir, "task", "show");
        requireContains(doneView, "  status: DONE");
        requireContains(doneView, "  last change: completed by alice at 3");
        requireContains(doneView, "  no correction or conflict");
        requireContains(doneView, "  Created -> Started -> Completed");
        requireContains(doneView, "task-completed");

        String correctionOutput = runPlatformCli(
            rootDir,
            "task",
            "correct",
            "--task",
            "task-900",
            "--target-event",
            "task-evt-000003",
            "--reason",
            "mistaken completion",
            "--actor",
            "alice",
            "--time",
            "4"
        );
        requireContains(correctionOutput, "corrected=true");
        requireContains(correctionOutput, "eventType=TaskCorrected");

        String verifyAfterCorrectionRestart = runPlatformCli(rootDir, "task", "verify");
        requireContains(verifyAfterCorrectionRestart, "verified=true");
        requireContains(verifyAfterCorrectionRestart, "verifiedEventCount=4");

        String reopenedView = runPlatformCli(rootDir, "task", "show");
        requireContains(reopenedView, "  status: REOPENED");
        requireContains(reopenedView, "  last change: corrected completion by alice at 4");
        requireContains(reopenedView, "  corrected completion: by alice at 3");
        requireContains(reopenedView, "  correction made by: alice at 4");
        requireContains(reopenedView, "  reason: mistaken completion");
        requireContains(reopenedView, "  Created -> Started -> Completed (corrected)");
        requireContains(reopenedView, "task-corrected");

        String restartOutput = runPlatformCli(rootDir, "task", "start", "--task", "task-900", "--actor", "alice", "--time", "5");
        requireContains(restartOutput, "appended=true");
        requireContains(restartOutput, "eventType=TaskStarted");

        String recompleteOutput = runPlatformCli(rootDir, "task", "complete", "--task", "task-900", "--actor", "alice", "--time", "6");
        requireContains(recompleteOutput, "appended=true");
        requireContains(recompleteOutput, "eventType=TaskCompleted");

        expectFailureAndUnchanged(
            rootDir,
            "does not match last completion event task-evt-000006",
            "task",
            "correct",
            "--task",
            "task-900",
            "--target-event",
            "task-evt-000003",
            "--reason",
            "wrong target"
        );

        String retryCorrectionOutput = runPlatformCli(
            rootDir,
            "task",
            "correct",
            "--task",
            "task-900",
            "--target-event",
            "task-evt-000006",
            "--reason",
            "second correction",
            "--actor",
            "alice",
            "--time",
            "7"
        );
        requireContains(retryCorrectionOutput, "corrected=true");

        String verifyFinal = runPlatformCli(rootDir, "task", "verify");
        requireContains(verifyFinal, "verified=true");
        requireContains(verifyFinal, "verifiedEventCount=7");

        String finalView = runPlatformCli(rootDir, "task", "show");
        requireContains(finalView, "  status: REOPENED");
        requireContains(finalView, "  last change: corrected completion by alice at 7");
        requireContains(finalView, "  corrected completion: by alice at 6");
        requireContains(finalView, "  correction made by: alice at 7");
        requireContains(finalView, "  reason: second correction");
        requireContains(finalView, "  Created -> Started -> Completed (corrected) -> Started -> Completed (corrected)");
        requireContains(finalView, "task-corrected");

        System.out.println("taskWorkflowCheckPassed=true");
    }

    private static void expectFailureAndUnchanged(Path rootDir, String expectedMessage, String... cliArgs) throws Exception {
        int before = eventCount(rootDir);
        String beforeListing = eventListing(rootDir);
        String output = runPlatformCliFailure(rootDir, cliArgs);
        requireContains(output, expectedMessage);
        int after = eventCount(rootDir);
        String afterListing = eventListing(rootDir);
        if (before != after || !beforeListing.equals(afterListing)) {
            throw new IllegalStateException("On-disk task chain changed after failed workflow step");
        }
    }

    private static int eventCount(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return 0;
        }
        try (var stream = Files.list(eventDir)) {
            return (int) stream.filter(Files::isRegularFile).count();
        }
    }

    private static String eventListing(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return "";
        }
        try (var stream = Files.list(eventDir)) {
            return stream
                .filter(Files::isRegularFile)
                .map(path -> path.getFileName().toString())
                .sorted()
                .reduce("", (left, right) -> left + "|" + right);
        }
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + result.output());
        }
        return result.output();
    }

    private static String runPlatformCliFailure(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() == 0) {
            throw new IllegalStateException("Expected PlatformCli failure but succeeded: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runPlatformCliProcess(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private record ProcessResult(int exitCode, String output) {
    }
}
