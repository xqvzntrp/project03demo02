package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class TaskMultiActorCorrectionCheck {
    private TaskMultiActorCorrectionCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-multi-actor-correction-check-");

        runPlatformCli(rootDir, "task", "create", "--task", "task-950", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "task", "start", "--task", "task-950", "--actor", "bob", "--time", "2");
        runPlatformCli(rootDir, "task", "complete", "--task", "task-950", "--actor", "carol", "--time", "3");

        String correctionOutput = runPlatformCli(
            rootDir,
            "task",
            "correct",
            "--task",
            "task-950",
            "--target-event",
            "task-evt-000003",
            "--reason",
            "completion needs follow-up",
            "--actor",
            "dave",
            "--time",
            "4"
        );
        requireContains(correctionOutput, "corrected=true");

        String restartOutput = runPlatformCli(rootDir, "task", "start", "--task", "task-950", "--actor", "alice", "--time", "5");
        requireContains(restartOutput, "appended=true");
        requireContains(restartOutput, "eventType=TaskStarted");

        String showOutput = runPlatformCli(rootDir, "task", "show");
        requireContains(showOutput, "STATE");
        requireContains(showOutput, "  status: ACTIVE");
        requireContains(showOutput, "  last change: started by alice at 5");
        requireContains(showOutput, "WHY");
        requireContains(showOutput, "  corrected completion: by carol at 3");
        requireContains(showOutput, "  correction made by: dave at 4");
        requireContains(showOutput, "  reason: completion needs follow-up");
        requireContains(showOutput, "PATH");
        requireContains(showOutput, "  Created -> Started -> Completed (corrected) -> Started");
        requireContains(showOutput, "TRACE");
        requireContains(showOutput, "  [task-evt-000001] created by alice at 1");
        requireContains(showOutput, "  [task-evt-000002] started by bob at 2");
        requireContains(showOutput, "  [task-evt-000003] completed by carol at 3");
        requireContains(showOutput, "  [task-evt-000004] corrected completion by dave at 4");
        requireContains(showOutput, "  [task-evt-000005] started by alice at 5");

        System.out.println("taskMultiActorCorrectionCheckPassed=true");
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }
}
