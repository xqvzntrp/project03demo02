package kernel.apps.checks;

import kernel.apps.PlatformGui;

public final class PlatformGuiNextActionCheck {
    private PlatformGuiNextActionCheck() {
    }

    public static void main(String[] args) {
        checkPrimaryNextActionExtracted();
        checkNoActionWhenNextIsEmpty();
        System.out.println("platformGuiNextActionCheckPassed=true");
    }

    private static void checkPrimaryNextActionExtracted() {
        String output = String.join(
            System.lineSeparator(),
            "Root: build\\platform\\task",
            "NEXT",
            "  - task complete --task task-500",
            "  - task cancel --task task-500"
        );
        String action = PlatformGui.primaryNextActionFromOutput(output);
        requireEquals("task complete --task task-500", action);
    }

    private static void checkNoActionWhenNextIsEmpty() {
        String output = String.join(
            System.lineSeparator(),
            "Root: build\\platform\\account",
            "NEXT",
            "  (no valid next events: account is CLOSED)"
        );
        String action = PlatformGui.primaryNextActionFromOutput(output);
        if (action != null) {
            throw new IllegalStateException("Expected no primary next action but found: " + action);
        }
    }

    private static void requireEquals(String expected, String actual) {
        if (!expected.equals(actual)) {
            throw new IllegalStateException("Expected '" + expected + "' but was '" + actual + "'");
        }
    }
}
