package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.accountcli.AccountCli;

public final class AccountCliPersistenceCheck {
    private AccountCliPersistenceCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("account-cli-persistence-check-");

        runCli(rootDir, "open", "--account", "acct-200", "--actor", "alice", "--time", "1");
        runCli(rootDir, "deposit", "--account", "acct-200", "--amount", "100", "--actor", "alice", "--time", "2");
        runCli(rootDir, "withdraw", "--account", "acct-200", "--amount", "30", "--actor", "alice", "--time", "3");
        runCli(rootDir, "close", "--account", "acct-200", "--actor", "alice", "--time", "4");

        String verifyOutput = runCli(rootDir, "verify");
        String showOutput = runCli(rootDir, "show");

        requireContains(verifyOutput, "verified=true");
        requireContains(verifyOutput, "verifiedEventCount=4");
        requireContains(showOutput, "STATE");
        requireContains(showOutput, "  account: acct-200");
        requireContains(showOutput, "  status: CLOSED");
        requireContains(showOutput, "  balance: 70");
        requireContains(showOutput, "  last change: closed by alice at 4");
        requireContains(showOutput, "  event count: 4");
        requireContains(showOutput, "  last event id: acct-evt-000004");
        requireContains(showOutput, "WHY");
        requireContains(showOutput, "  account closed: by alice at 4");
        requireContains(showOutput, "  balance frozen at: 70");
        requireContains(showOutput, "PATH");
        requireContains(showOutput, "  Opened -> Deposited 100 -> Withdrew 30 -> Closed");
        requireContains(showOutput, "TRACE");
        requireContains(showOutput, "  [acct-evt-000001] opened by alice at 1");
        requireContains(showOutput, "  [acct-evt-000002] deposited 100 by alice at 2");
        requireContains(showOutput, "  [acct-evt-000003] withdrew 30 by alice at 3");
        requireContains(showOutput, "  [acct-evt-000004] closed by alice at 4");
        requireContains(showOutput, "OUTPUTS");
        requireContains(showOutput, "account-opened");
        requireContains(showOutput, "account-closed");

        System.out.println("accountCliPersistenceCheckPassed=true");
    }

    private static String runCli(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(AccountCli.class.getName());
        command.add(commandArgs[0]);
        command.add("--root");
        command.add(rootDir.toString());
        for (int i = 1; i < commandArgs.length; i++) {
            command.add(commandArgs[i]);
        }

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("AccountCli command failed with exit code " + exitCode + ": " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }
}
