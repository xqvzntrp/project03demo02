package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class AccountWorkflowCheck {
    private AccountWorkflowCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("account-workflow-check-");

        runPlatformCli(rootDir, "account", "open", "--account", "acct-950", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "account", "deposit", "--account", "acct-950", "--amount", "100", "--actor", "bob", "--time", "2");
        runPlatformCli(rootDir, "account", "withdraw", "--account", "acct-950", "--amount", "30", "--actor", "carol", "--time", "3");

        String activeView = runPlatformCli(rootDir, "account", "show");
        requireContains(activeView, "STATE");
        requireContains(activeView, "  account: acct-950");
        requireContains(activeView, "  status: OPEN");
        requireContains(activeView, "  balance: 70");
        requireContains(activeView, "  last change: withdrew 30 by carol at 3");
        requireContains(activeView, "WHY");
        requireContains(activeView, "  no anomaly or closure");
        requireContains(activeView, "PATH");
        requireContains(activeView, "  Opened -> Deposited 100 -> Withdrew 30");
        requireContains(activeView, "TRACE");
        requireContains(activeView, "  [acct-evt-000001] opened by alice at 1");
        requireContains(activeView, "  [acct-evt-000002] deposited 100 by bob at 2");
        requireContains(activeView, "  [acct-evt-000003] withdrew 30 by carol at 3");

        String overdraftOutput = runPlatformCli(
            rootDir,
            "account",
            "withdraw",
            "--account",
            "acct-950",
            "--amount",
            "90",
            "--actor",
            "dana",
            "--time",
            "4"
        );
        requireContains(overdraftOutput, "appended=true");
        requireContains(overdraftOutput, "eventType=FundsWithdrawn");

        String overdraftView = runPlatformCli(rootDir, "account", "show");
        requireContains(overdraftView, "  status: OPEN");
        requireContains(overdraftView, "  balance: 70");
        requireContains(overdraftView, "  last change: withdrew 30 by carol at 3");
        requireContains(overdraftView, "  rejected withdrawal: by dana at 4");
        requireContains(overdraftView, "  requested: 90");
        requireContains(overdraftView, "  balance stayed: 70");
        requireContains(overdraftView, "  Opened -> Deposited 100 -> Withdrew 30 -> Withdrawal rejected 90");
        requireContains(overdraftView, "  [acct-evt-000004] withdrawal attempted 90 by dana at 4 (rejected)");
        requireContains(overdraftView, "overdraft-attempted");

        expectFailureAndUnchanged(
            rootDir,
            "Account id acct-wrong does not match existing chain account acct-950",
            "account",
            "deposit",
            "--account",
            "acct-wrong",
            "--amount",
            "5"
        );

        expectFailureAndUnchanged(
            rootDir,
            "For input string: \"oops\"",
            "account",
            "withdraw",
            "--account",
            "acct-950",
            "--amount",
            "oops"
        );

        String stableView = runPlatformCli(rootDir, "account", "show");
        if (!overdraftView.equals(stableView)) {
            throw new IllegalStateException("Account explanation changed after failed commands");
        }

        String closeOutput = runPlatformCli(rootDir, "account", "close", "--account", "acct-950", "--actor", "erin", "--time", "5");
        requireContains(closeOutput, "closed=true");

        String closedView = runPlatformCli(rootDir, "account", "show");
        requireContains(closedView, "  status: CLOSED");
        requireContains(closedView, "  last change: closed by erin at 5");
        requireContains(closedView, "  account closed: by erin at 5");
        requireContains(closedView, "  balance frozen at: 70");
        requireContains(closedView, "  Opened -> Deposited 100 -> Withdrew 30 -> Withdrawal rejected 90 -> Closed");

        System.out.println("accountWorkflowCheckPassed=true");
    }

    private static void expectFailureAndUnchanged(Path rootDir, String expectedMessage, String... cliArgs) throws Exception {
        int before = eventCount(rootDir);
        String beforeListing = eventListing(rootDir);
        String output = runPlatformCliFailure(rootDir, cliArgs);
        requireContains(output, expectedMessage);
        int after = eventCount(rootDir);
        String afterListing = eventListing(rootDir);
        if (before != after || !beforeListing.equals(afterListing)) {
            throw new IllegalStateException("On-disk account chain changed after failed workflow step");
        }
    }

    private static int eventCount(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return 0;
        }
        try (var stream = Files.list(eventDir)) {
            return (int) stream.filter(Files::isRegularFile).count();
        }
    }

    private static String eventListing(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return "";
        }
        try (var stream = Files.list(eventDir)) {
            return stream
                .filter(Files::isRegularFile)
                .map(path -> path.getFileName().toString())
                .sorted()
                .reduce("", (left, right) -> left + "|" + right);
        }
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + result.output());
        }
        return result.output();
    }

    private static String runPlatformCliFailure(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() == 0) {
            throw new IllegalStateException("Expected PlatformCli failure but succeeded: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runPlatformCliProcess(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private record ProcessResult(int exitCode, String output) {
    }
}
