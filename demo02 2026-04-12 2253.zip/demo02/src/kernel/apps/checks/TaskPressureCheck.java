package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class TaskPressureCheck {
    private TaskPressureCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-pressure-check-");

        runPlatformCli(rootDir, "task", "create", "--task", "task-980", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "task", "start", "--task", "task-980", "--actor", "bob", "--time", "2");
        runPlatformCli(rootDir, "task", "complete", "--task", "task-980", "--actor", "carol", "--time", "3");
        runPlatformCli(
            rootDir,
            "task",
            "correct",
            "--task",
            "task-980",
            "--target-event",
            "task-evt-000003",
            "--reason",
            "needs follow-up",
            "--actor",
            "dave",
            "--time",
            "4"
        );
        runPlatformCli(rootDir, "task", "start", "--task", "task-980", "--actor", "erin", "--time", "5");
        runPlatformCli(rootDir, "task", "complete", "--task", "task-980", "--actor", "frank", "--time", "6");
        runPlatformCli(
            rootDir,
            "task",
            "correct",
            "--task",
            "task-980",
            "--target-event",
            "task-evt-000006",
            "--reason",
            "second pass required",
            "--actor",
            "grace",
            "--time",
            "7"
        );
        runPlatformCli(rootDir, "task", "start", "--task", "task-980", "--actor", "hank", "--time", "8");

        String showOutput = runPlatformCli(rootDir, "task", "show");
        requireContains(showOutput, "STATE");
        requireContains(showOutput, "  task: task-980");
        requireContains(showOutput, "  status: ACTIVE");
        requireContains(showOutput, "  last change: started by hank at 8");
        requireContains(showOutput, "WHY");
        requireContains(showOutput, "  correction cycles: 2 corrected completions");
        requireContains(showOutput, "  corrected completion: by frank at 6");
        requireContains(showOutput, "  correction made by: grace at 7");
        requireContains(showOutput, "  earlier correction: needs follow-up by dave at 4");
        requireContains(showOutput, "  reason: second pass required");
        requireContains(showOutput, "PATH");
        requireContains(showOutput, "  Created -> Started -> Completed (corrected) -> Started -> Completed (corrected) -> Started");

        System.out.println("taskPressureCheckPassed=true");
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runPlatformCliProcess(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private record ProcessResult(int exitCode, String output) {
    }
}
