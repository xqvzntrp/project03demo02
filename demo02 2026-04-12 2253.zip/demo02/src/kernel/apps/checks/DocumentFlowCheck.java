package kernel.apps.checks;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.flow.DocumentFlow;

public final class DocumentFlowCheck {
    private DocumentFlowCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("document-flow-check-");

        DocumentFlow.DocumentFlowSession session = DocumentFlow.begin(rootDir);
        requireEquals("document", session.currentField());
        session = session.answer("doc-100");
        requireEquals("actor", session.currentField());
        session = session.answer("alice");
        requireEquals("time", session.currentField());
        session = session.answer("1");
        requireEquals(
            "document draft --document doc-100 --root " + rootDir + " --actor alice --time 1",
            session.commandPreview()
        );
        DocumentFlow.DocumentFlowExecution draft = session.execute();
        requireEquals(0, draft.exitCode());
        requireContains(draft.output(), "drafted=true");

        session = draft.nextSession();
        requireEquals(DocumentFlow.Action.SUBMIT, session.action());
        session = session.answer("bob").answer("2");
        requireEquals(
            "document submit --document doc-100 --root " + rootDir + " --actor bob --time 2",
            session.commandPreview()
        );
        DocumentFlow.DocumentFlowExecution submit = session.execute();
        requireEquals(0, submit.exitCode());
        requireContains(submit.output(), "eventType=DocumentSubmitted");

        session = submit.nextSession();
        requireEquals(DocumentFlow.Action.REJECT, session.action());
        requireEquals("reason", session.currentField());
        session = session.answer("needs signature").answer("carol").answer("3");
        requireEquals(
            "document reject --document doc-100 --target-event doc-evt-000002 --reason \"needs signature\" --root "
                + rootDir + " --actor carol --time 3",
            session.commandPreview()
        );
        DocumentFlow.DocumentFlowExecution reject = session.execute();
        requireEquals(0, reject.exitCode());
        requireContains(reject.output(), "eventType=DocumentRejected");

        System.out.println("documentFlowCheckPassed=true");
    }

    private static void requireContains(String actual, String expected) {
        if (!actual.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + actual);
        }
    }

    private static void requireEquals(Object expected, Object actual) {
        if (!expected.equals(actual)) {
            throw new IllegalStateException("Expected '" + expected + "' but was '" + actual + "'");
        }
    }
}
