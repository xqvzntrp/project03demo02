package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.PlatformCli;

public final class AccountMessyWorkflowCheck {
    private AccountMessyWorkflowCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("account-messy-workflow-check-");

        runPlatformCli(rootDir, "account", "open", "--account", "acct-980", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "account", "deposit", "--account", "acct-980", "--amount", "100", "--actor", "bob", "--time", "2");
        runPlatformCli(rootDir, "account", "withdraw", "--account", "acct-980", "--amount", "30", "--actor", "carol", "--time", "3");
        runPlatformCli(rootDir, "account", "withdraw", "--account", "acct-980", "--amount", "90", "--actor", "dana", "--time", "4");
        runPlatformCli(rootDir, "account", "deposit", "--account", "acct-980", "--amount", "50", "--actor", "erin", "--time", "5");
        runPlatformCli(rootDir, "account", "withdraw", "--account", "acct-980", "--amount", "90", "--actor", "frank", "--time", "6");

        String recoveredView = runPlatformCli(rootDir, "account", "show");
        requireContains(recoveredView, "STATE");
        requireContains(recoveredView, "  account: acct-980");
        requireContains(recoveredView, "  status: OPEN");
        requireContains(recoveredView, "  balance: 30");
        requireContains(recoveredView, "  last change: withdrew 90 by frank at 6");
        requireContains(recoveredView, "WHY");
        requireContains(recoveredView, "  earlier rejected withdrawal: 90 by dana at 4");
        requireContains(recoveredView, "  recovered by: deposited 50 by erin at 5");
        requireContains(recoveredView, "PATH");
        requireContains(recoveredView, "  Opened -> Deposited 100 -> Withdrew 30 -> Withdrawal rejected 90 -> Deposited 50 -> Withdrew 90");
        requireContains(recoveredView, "TRACE");
        requireContains(recoveredView, "  [acct-evt-000004] withdrawal attempted 90 by dana at 4 (rejected)");
        requireContains(recoveredView, "  [acct-evt-000005] deposited 50 by erin at 5");
        requireContains(recoveredView, "  [acct-evt-000006] withdrew 90 by frank at 6");

        runPlatformCli(rootDir, "account", "close", "--account", "acct-980", "--actor", "grace", "--time", "7");

        String closedView = runPlatformCli(rootDir, "account", "show");
        requireContains(closedView, "  status: CLOSED");
        requireContains(closedView, "  last change: closed by grace at 7");
        requireContains(closedView, "  account closed: by grace at 7");
        requireContains(closedView, "  balance frozen at: 30");
        requireContains(closedView, "  earlier rejected withdrawal: 90 by dana at 4");
        requireContains(closedView, "  recovered by: deposited 50 by erin at 5");
        requireContains(closedView, "  Opened -> Deposited 100 -> Withdrew 30 -> Withdrawal rejected 90 -> Deposited 50 -> Withdrew 90 -> Closed");

        expectFailureAndUnchanged(
            rootDir,
            "FundsDeposited requires status OPEN but found CLOSED",
            "account",
            "deposit",
            "--account",
            "acct-980",
            "--amount",
            "10",
            "--actor",
            "hank",
            "--time",
            "8"
        );

        String stableView = runPlatformCli(rootDir, "account", "show");
        if (!closedView.equals(stableView)) {
            throw new IllegalStateException("Account explanation changed after failed post-close mutation");
        }

        System.out.println("accountMessyWorkflowCheckPassed=true");
    }

    private static void expectFailureAndUnchanged(Path rootDir, String expectedMessage, String... cliArgs) throws Exception {
        int before = eventCount(rootDir);
        String beforeListing = eventListing(rootDir);
        String output = runPlatformCliFailure(rootDir, cliArgs);
        requireContains(output, expectedMessage);
        int after = eventCount(rootDir);
        String afterListing = eventListing(rootDir);
        if (before != after || !beforeListing.equals(afterListing)) {
            throw new IllegalStateException("On-disk account chain changed after failed workflow step");
        }
    }

    private static int eventCount(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return 0;
        }
        try (var stream = Files.list(eventDir)) {
            return (int) stream.filter(Files::isRegularFile).count();
        }
    }

    private static String eventListing(Path rootDir) throws Exception {
        Path eventDir = rootDir.resolve("events");
        if (!Files.isDirectory(eventDir)) {
            return "";
        }
        try (var stream = Files.list(eventDir)) {
            return stream
                .filter(Files::isRegularFile)
                .map(path -> path.getFileName().toString())
                .sorted()
                .reduce("", (left, right) -> left + "|" + right);
        }
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + result.output());
        }
        return result.output();
    }

    private static String runPlatformCliFailure(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() == 0) {
            throw new IllegalStateException("Expected PlatformCli failure but succeeded: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runPlatformCliProcess(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private record ProcessResult(int exitCode, String output) {
    }
}
