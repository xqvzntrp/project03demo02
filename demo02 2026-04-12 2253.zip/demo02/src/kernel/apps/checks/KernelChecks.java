package kernel.apps.checks;

public final class KernelChecks {
    private KernelChecks() {
    }

    public static void main(String[] args) throws Exception {
        CorruptionCheck.main(new String[0]);
        ReplayDeterminismCheck.main(new String[0]);
        CanonicalizationCheck.main(new String[0]);
        PropertiesLayoutIndependenceCheck.main(new String[0]);
        PayloadTamperCheck.main(new String[0]);
        ChainInvariantCheck.main(new String[0]);
        System.out.println("allKernelChecksPassed=true");
    }
}
