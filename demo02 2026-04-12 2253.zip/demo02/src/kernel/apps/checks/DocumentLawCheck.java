package kernel.apps.checks;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.VerifiedReplayChain;
import kernel.laws.document.DocumentEventWriter;
import kernel.laws.document.DocumentLaw;
import kernel.laws.document.DocumentStateView;
import kernel.laws.document.DocumentStatus;

public final class DocumentLawCheck {
    private DocumentLawCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkRejectedDocumentCanBeRevisedAndApproved();
        checkApproveWithoutResubmitFails();
        System.out.println("documentLawCheckPassed=true");
    }

    private static void checkRejectedDocumentCanBeRevisedAndApproved() throws Exception {
        Path rootDir = Files.createTempDirectory("document-law-flow-check-");
        Path eventDir = rootDir.resolve("events");
        Path payloadDir = rootDir.resolve("payloads");
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);

        String lawVersion = "document-law-v1";
        DocumentEventWriter.WrittenDocumentEvent drafted = DocumentEventWriter.write(
            eventDir,
            payloadDir,
            "doc-evt-0001",
            "DocumentDrafted",
            EventCodec.INITIAL_POINTER_SENTINEL,
            "doc-001",
            lawVersion,
            "alice",
            1L
        );
        DocumentEventWriter.WrittenDocumentEvent submitted = DocumentEventWriter.write(
            eventDir,
            payloadDir,
            "doc-evt-0002",
            "DocumentSubmitted",
            drafted.eventHash(),
            "doc-001",
            lawVersion,
            "alice",
            2L
        );
        DocumentEventWriter.WrittenDocumentEvent rejected = DocumentEventWriter.writeRejection(
            eventDir,
            payloadDir,
            "doc-evt-0003",
            submitted.eventHash(),
            "doc-001",
            "doc-evt-0002",
            "needs signature",
            lawVersion,
            "bob",
            3L
        );
        DocumentEventWriter.WrittenDocumentEvent revised = DocumentEventWriter.write(
            eventDir,
            payloadDir,
            "doc-evt-0004",
            "DocumentRevised",
            rejected.eventHash(),
            "doc-001",
            lawVersion,
            "alice",
            4L
        );
        DocumentEventWriter.WrittenDocumentEvent resubmitted = DocumentEventWriter.write(
            eventDir,
            payloadDir,
            "doc-evt-0005",
            "DocumentSubmitted",
            revised.eventHash(),
            "doc-001",
            lawVersion,
            "alice",
            5L
        );
        DocumentEventWriter.write(
            eventDir,
            payloadDir,
            "doc-evt-0006",
            "DocumentApproved",
            resubmitted.eventHash(),
            "doc-001",
            lawVersion,
            "carol",
            6L
        );

        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(eventDir, payloadDir);
        ReplayRun replayRun = new Replayer().replay(replayChain, new DocumentLaw(lawVersion));
        DocumentStateView finalState = DocumentStateView.from(replayRun.finalState());

        if (finalState.status() != DocumentStatus.APPROVED) {
            throw new IllegalStateException("Document did not end in APPROVED state");
        }
        if (finalState.currentRevision() != 2) {
            throw new IllegalStateException("Document did not advance to revision 2");
        }
        boolean sawRejection = replayRun.outputs().stream().anyMatch(output -> "document-rejected".equals(output.kind()));
        boolean sawApproval = replayRun.outputs().stream().anyMatch(output -> "document-approved".equals(output.kind()));
        if (!sawRejection || !sawApproval) {
            throw new IllegalStateException("Expected rejection and approval derived outputs");
        }
        System.out.println("documentRevisionFlowCheckPassed=true");
    }

    private static void checkApproveWithoutResubmitFails() throws Exception {
        Path rootDir = Files.createTempDirectory("document-law-invalid-check-");
        Path eventDir = rootDir.resolve("events");
        Path payloadDir = rootDir.resolve("payloads");
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);

        String lawVersion = "document-law-v1";
        DocumentEventWriter.WrittenDocumentEvent drafted = DocumentEventWriter.write(
            eventDir,
            payloadDir,
            "doc-evt-0001",
            "DocumentDrafted",
            EventCodec.INITIAL_POINTER_SENTINEL,
            "doc-002",
            lawVersion,
            "alice",
            1L
        );
        DocumentEventWriter.WrittenDocumentEvent submitted = DocumentEventWriter.write(
            eventDir,
            payloadDir,
            "doc-evt-0002",
            "DocumentSubmitted",
            drafted.eventHash(),
            "doc-002",
            lawVersion,
            "alice",
            2L
        );
        DocumentEventWriter.WrittenDocumentEvent rejected = DocumentEventWriter.writeRejection(
            eventDir,
            payloadDir,
            "doc-evt-0003",
            submitted.eventHash(),
            "doc-002",
            "doc-evt-0002",
            "missing appendix",
            lawVersion,
            "bob",
            3L
        );
        DocumentEventWriter.write(
            eventDir,
            payloadDir,
            "doc-evt-0004",
            "DocumentApproved",
            rejected.eventHash(),
            "doc-002",
            lawVersion,
            "carol",
            4L
        );

        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(eventDir, payloadDir);

        boolean failedAsExpected = false;
        try {
            new Replayer().replay(replayChain, new DocumentLaw(lawVersion));
        } catch (Exception expected) {
            failedAsExpected = true;
            System.out.println("documentInvalidTransition=" + expected.getClass().getSimpleName());
        }

        if (!failedAsExpected) {
            throw new IllegalStateException("Document law unexpectedly accepted approval without resubmission");
        }
        System.out.println("documentInvalidTransitionCheckPassed=true");
    }
}
