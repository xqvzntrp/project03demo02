package kernel.apps.checks;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.VerifiedReplayChain;
import kernel.laws.account.AccountEventWriter;
import kernel.laws.account.AccountLaw;
import kernel.laws.account.AccountStateView;

public final class AccountLawCheck {
    private AccountLawCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkOverdraftIsExplicitOutput();
        checkMutationAfterCloseFails();
        System.out.println("accountLawCheckPassed=true");
    }

    private static void checkOverdraftIsExplicitOutput() throws Exception {
        Path rootDir = Files.createTempDirectory("account-law-overdraft-check-");
        Path eventDir = rootDir.resolve("events");
        Path payloadDir = rootDir.resolve("payloads");
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);

        String lawVersion = "account-law-v1";
        AccountEventWriter.WrittenAccountEvent opened = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0001",
            "AccountOpened",
            EventCodec.INITIAL_POINTER_SENTINEL,
            "acct-001",
            0L,
            lawVersion,
            "actor-01",
            1L
        );
        AccountEventWriter.WrittenAccountEvent deposited = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0002",
            "FundsDeposited",
            opened.eventHash(),
            "acct-001",
            50L,
            lawVersion,
            "actor-01",
            2L
        );
        AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0003",
            "FundsWithdrawn",
            deposited.eventHash(),
            "acct-001",
            80L,
            lawVersion,
            "actor-01",
            3L
        );

        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(eventDir, payloadDir);
        ReplayRun replayRun = new Replayer().replay(replayChain, new AccountLaw(lawVersion));
        AccountStateView finalAccount = AccountStateView.from(replayRun.finalState());

        if (finalAccount.balance() != 50L) {
            throw new IllegalStateException("Overdraft attempt changed the balance");
        }
        boolean sawOverdraftOutput = replayRun.outputs().stream().anyMatch(output -> "overdraft-attempted".equals(output.kind()));
        if (!sawOverdraftOutput) {
            throw new IllegalStateException("Overdraft attempt did not emit an explicit derived output");
        }
        System.out.println("overdraftCheckPassed=true");
    }

    private static void checkMutationAfterCloseFails() throws Exception {
        Path rootDir = Files.createTempDirectory("account-law-close-check-");
        Path eventDir = rootDir.resolve("events");
        Path payloadDir = rootDir.resolve("payloads");
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);

        String lawVersion = "account-law-v1";
        AccountEventWriter.WrittenAccountEvent opened = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0001",
            "AccountOpened",
            EventCodec.INITIAL_POINTER_SENTINEL,
            "acct-001",
            0L,
            lawVersion,
            "actor-01",
            1L
        );
        AccountEventWriter.WrittenAccountEvent deposited = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0002",
            "FundsDeposited",
            opened.eventHash(),
            "acct-001",
            50L,
            lawVersion,
            "actor-01",
            2L
        );
        AccountEventWriter.WrittenAccountEvent closed = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0003",
            "AccountClosed",
            deposited.eventHash(),
            "acct-001",
            0L,
            lawVersion,
            "actor-01",
            3L
        );
        AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0004",
            "FundsDeposited",
            closed.eventHash(),
            "acct-001",
            10L,
            lawVersion,
            "actor-01",
            4L
        );

        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(eventDir, payloadDir);

        boolean failedAsExpected = false;
        try {
            new Replayer().replay(replayChain, new AccountLaw(lawVersion));
        } catch (Exception expected) {
            failedAsExpected = true;
            System.out.println("postCloseFailure=" + expected.getClass().getSimpleName());
        }

        if (!failedAsExpected) {
            throw new IllegalStateException("Account law unexpectedly accepted mutation after close");
        }
        System.out.println("postCloseCheckPassed=true");
    }
}
