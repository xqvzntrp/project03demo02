package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import kernel.apps.support.ReplaySnapshot;
import kernel.apps.support.SampleChain;

public final class ReplayDeterminismCheck {
    private ReplayDeterminismCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("kernel-determinism-check-");
        SampleChain.SampleData sampleData = SampleChain.create(rootDir);

        String firstRun = runSnapshot(sampleData.eventDir(), sampleData.payloadDir());
        String secondRun = runSnapshot(sampleData.eventDir(), sampleData.payloadDir());

        if (!firstRun.equals(secondRun)) {
            throw new IllegalStateException("Replay snapshots differ across JVM runs");
        }

        System.out.println("replayDeterministic=true");
        System.out.println("snapshotHex=" + firstRun);
    }

    private static String runSnapshot(Path eventDir, Path payloadDir) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");
        Process process = new ProcessBuilder(
            List.of(
                javaBinary,
                "-cp",
                classpath,
                ReplaySnapshot.class.getName(),
                eventDir.toString(),
                payloadDir.toString()
            )
        ).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("ReplaySnapshot failed with exit code " + exitCode + ": " + output);
        }
        return output;
    }
}
