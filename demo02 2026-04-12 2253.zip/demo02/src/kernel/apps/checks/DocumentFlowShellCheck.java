package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.documentcli.DocumentCli;

public final class DocumentFlowShellCheck {
    private DocumentFlowShellCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkExplicitRootDraft();
        checkExplicitRootSubmit();
        checkExplicitRootReject();
        checkNewRootDraft();
        System.out.println("documentFlowShellCheckPassed=true");
    }

    private static void checkExplicitRootDraft() throws Exception {
        Path rootDir = Files.createTempDirectory("document-flow-shell-draft-check-");
        String input = String.join(
            System.lineSeparator(),
            "doc-100",
            "alice",
            "1",
            "",
            ""
        );

        String output = runShell(input, "--root", rootDir.toString());
        requireContains(output, "Document Flow");
        requireContains(output, "next: document draft");
        requireContains(output, "document draft --document doc-100 --root " + rootDir + " --actor alice --time 1");
        requireContains(output, "[state]");
        requireContains(output, "  document: doc-100");
        requireContains(output, "  status: DRAFT");
        requireContains(output, "[next]");
        requireContains(output, "  - document submit --document doc-100");
    }

    private static void checkExplicitRootSubmit() throws Exception {
        Path rootDir = Files.createTempDirectory("document-flow-shell-submit-check-");
        runCli(rootDir, "draft", "--document", "doc-200", "--actor", "alice", "--time", "1");

        String input = String.join(
            System.lineSeparator(),
            "bob",
            "2",
            "",
            ""
        );

        String output = runShell(input, "--root", rootDir.toString());
        requireContains(output, "next: document submit");
        requireContains(output, "document submit --document doc-200 --root " + rootDir + " --actor bob --time 2");
        requireContains(output, "eventType=DocumentSubmitted");
        requireContains(output, "[state]");
        requireContains(output, "  status: IN_REVIEW");
        requireContains(output, "[next]");
        requireContains(output, "  - document reject --document doc-200 --target-event doc-evt-000002 --reason <text>");
        requireContains(output, "  - document approve --document doc-200");
    }

    private static void checkExplicitRootReject() throws Exception {
        Path rootDir = Files.createTempDirectory("document-flow-shell-reject-check-");
        runCli(rootDir, "draft", "--document", "doc-250", "--actor", "alice", "--time", "1");
        runCli(rootDir, "submit", "--document", "doc-250", "--actor", "bob", "--time", "2");

        String input = String.join(
            System.lineSeparator(),
            "needs signature",
            "carol",
            "3",
            "",
            ""
        );

        String output = runShell(input, "--root", rootDir.toString());
        requireContains(output, "next: document reject");
        requireContains(
            output,
            "document reject --document doc-250 --target-event doc-evt-000002 --reason \"needs signature\" --root "
                + rootDir + " --actor carol --time 3"
        );
        requireContains(output, "eventType=DocumentRejected");
        requireContains(output, "[state]");
        requireContains(output, "  status: CHANGES_REQUESTED");
        requireContains(output, "  reason: needs signature");
        requireContains(output, "[next]");
        requireContains(output, "  - document revise --document doc-250");
    }

    private static void checkNewRootDraft() throws Exception {
        String input = String.join(
            System.lineSeparator(),
            "doc-300",
            "alice",
            "1",
            "",
            ""
        );

        String output = runShell(input, "--new");
        requireContains(output, "Using new root: build\\platform\\sandbox\\document-");
        requireContains(output, "Root: build\\platform\\sandbox\\document-");
        requireContains(output, "next: document draft");
        requireContains(output, "drafted=true");
    }

    private static void runCli(Path rootDir, String... args) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(DocumentCli.class.getName());
        for (String arg : args) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected document CLI success but failed: " + output);
        }
    }

    private static String runShell(String input, String... shellArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(DocumentCli.class.getName());
        command.add("flow");
        for (String shellArg : shellArgs) {
            command.add(shellArg);
        }

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
        try (OutputStream outputStream = process.getOutputStream()) {
            String normalizedInput = input.endsWith(System.lineSeparator()) ? input : input + System.lineSeparator();
            outputStream.write(normalizedInput.getBytes(StandardCharsets.UTF_8));
        }

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected document flow shell success but failed: " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }
}
