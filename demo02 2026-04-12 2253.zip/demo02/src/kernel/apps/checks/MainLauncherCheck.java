package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

public final class MainLauncherCheck {
    private MainLauncherCheck() {
    }

    public static void main(String[] args) throws Exception {
        String output = runMain("help");
        requireContains(output, "Platform CLI");
        requireContains(output, "PlatformCli --gui [command...]");
        requireContains(output, "Show output:");
        System.out.println("mainLauncherCheckPassed=true");
    }

    private static String runMain(String... args) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("Main.java");
        for (String arg : args) {
            command.add(arg);
        }

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("Expected Main launcher success but failed: " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }
}
