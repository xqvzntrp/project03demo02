package kernel.apps.checks;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.support.SampleChain;
import kernel.core.ChainVerifier;
import kernel.core.Event;
import kernel.core.EventProperties;
import kernel.core.PayloadCas;

public final class ChainInvariantCheck {
    private ChainInvariantCheck() {
    }

    public static void main(String[] args) throws Exception {
        checkMissingParentRejected();
        checkDuplicateParentRejected();
        System.out.println("chainInvariantCheckPassed=true");
    }

    private static void checkMissingParentRejected() throws Exception {
        Path rootDir = Files.createTempDirectory("kernel-chain-break-check-");
        SampleChain.SampleData sampleData = SampleChain.create(rootDir);
        Path secondEventPath = sampleData.eventDir().resolve(sampleData.secondHash() + ".properties");
        Event brokenEvent = new Event(
            sampleData.secondEvent().eventId(),
            sampleData.secondEvent().eventType(),
            "missing-parent-hash",
            sampleData.secondEvent().payloadHash(),
            sampleData.secondEvent().lawVersion(),
            sampleData.secondEvent().actorId(),
            sampleData.secondEvent().timeValue()
        );
        EventProperties.write(secondEventPath, brokenEvent);

        expectFailureContains(
            "references missing parent",
            () -> ChainVerifier.verifiedChain(sampleData.eventDir())
        );
    }

    private static void checkDuplicateParentRejected() throws Exception {
        Path rootDir = Files.createTempDirectory("kernel-duplicate-parent-check-");
        SampleChain.SampleData sampleData = SampleChain.create(rootDir);
        byte[] payload = "duplicate-child".getBytes(StandardCharsets.UTF_8);
        String payloadHash = PayloadCas.store(sampleData.payloadDir(), payload);
        Event duplicateChild = new Event(
            "evt-0003",
            "DocumentSigned",
            sampleData.firstHash(),
            payloadHash,
            "law-v1",
            "actor-03",
            3L
        );
        EventProperties.write(sampleData.eventDir().resolve("duplicate-child.properties"), duplicateChild);

        expectFailureContains(
            "referenced by more than one child",
            () -> ChainVerifier.verifiedChain(sampleData.eventDir())
        );
    }

    private static void expectFailureContains(String expected, ThrowingRunnable runnable) throws Exception {
        try {
            runnable.run();
        } catch (Exception expectedFailure) {
            if (!expectedFailure.getMessage().contains(expected)) {
                throw new IllegalStateException(
                    "Expected failure containing '" + expected + "' but was: " + expectedFailure.getMessage(),
                    expectedFailure
                );
            }
            return;
        }
        throw new IllegalStateException("Expected failure containing '" + expected + "'");
    }

    @FunctionalInterface
    private interface ThrowingRunnable {
        void run() throws Exception;
    }
}
