package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import kernel.apps.taskcli.TaskCli;

public final class TaskCliPersistenceCheck {
    private TaskCliPersistenceCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-cli-persistence-check-");

        runCli(rootDir, "create", "--task", "task-200", "--actor", "alice", "--time", "1");
        runCli(rootDir, "start", "--task", "task-200", "--actor", "alice", "--time", "2");
        runCli(rootDir, "complete", "--task", "task-200", "--actor", "alice", "--time", "3");

        String verifyOutput = runCli(rootDir, "verify");
        String showOutput = runCli(rootDir, "show");

        requireContains(verifyOutput, "verified=true");
        requireContains(verifyOutput, "verifiedEventCount=3");
        requireContains(showOutput, "STATE");
        requireContains(showOutput, "  task: task-200");
        requireContains(showOutput, "  status: DONE");
        requireContains(showOutput, "  last change: completed by alice at 3");
        requireContains(showOutput, "WHY");
        requireContains(showOutput, "  no correction or conflict");
        requireContains(showOutput, "PATH");
        requireContains(showOutput, "  Created -> Started -> Completed");
        requireContains(showOutput, "TRACE");
        requireContains(showOutput, "  [task-evt-000003] completed by alice at 3");

        System.out.println("taskCliPersistenceCheckPassed=true");
    }

    private static String runCli(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(TaskCli.class.getName());
        command.add(commandArgs[0]);
        command.add("--root");
        command.add(rootDir.toString());
        for (int i = 1; i < commandArgs.length; i++) {
            command.add(commandArgs[i]);
        }

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IllegalStateException("TaskCli command failed with exit code " + exitCode + ": " + output);
        }
        return output;
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }
}
