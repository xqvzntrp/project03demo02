package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import kernel.apps.PlatformCli;
import kernel.core.Event;
import kernel.core.EventProperties;
import kernel.core.StoredEvent;

public final class PlatformLawVersionMismatchCheck {
    private PlatformLawVersionMismatchCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("platform-law-version-mismatch-check-");
        runPlatformCli(rootDir, "task", "create", "--task", "task-001", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "task", "start", "--task", "task-001", "--actor", "alice", "--time", "2");

        Path secondEventPath = findEventPath(rootDir.resolve("events"), "task-evt-000002");
        StoredEvent storedEvent = EventProperties.read(secondEventPath);
        Event mismatchedEvent = new Event(
            storedEvent.event().eventId(),
            storedEvent.event().eventType(),
            storedEvent.event().previousHash(),
            storedEvent.event().payloadHash(),
            "task-law-v2",
            storedEvent.event().actorId(),
            storedEvent.event().timeValue()
        );
        EventProperties.write(secondEventPath, mismatchedEvent);

        ProcessResult result = runPlatformCliProcess(rootDir, "task", "show");
        if (result.exitCode() == 0) {
            throw new IllegalStateException("Expected task show to fail on replay law mismatch");
        }
        requireContains(result.output(), "Replay law version task-law-v1 does not match event law version task-law-v2");

        System.out.println("platformLawVersionMismatchCheckPassed=true");
    }

    private static Path findEventPath(Path eventDir, String eventId) throws Exception {
        try (var stream = Files.list(eventDir)) {
            List<Path> paths = stream.filter(Files::isRegularFile).filter(path -> path.toString().endsWith(".properties")).toList();
            for (Path path : paths) {
                StoredEvent storedEvent = EventProperties.read(path);
                if (eventId.equals(storedEvent.event().eventId())) {
                    return path;
                }
            }
        }
        throw new IllegalStateException("Unable to find event file for " + eventId);
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runPlatformCliProcess(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        command.add("--root");
        command.add(rootDir.toString());

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private record ProcessResult(int exitCode, String output) {
    }
}
