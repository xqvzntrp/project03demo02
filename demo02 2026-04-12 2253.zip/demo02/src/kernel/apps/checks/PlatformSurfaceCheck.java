package kernel.apps.checks;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

import kernel.apps.PlatformCli;
import kernel.apps.support.RootDisplay;

public final class PlatformSurfaceCheck {
    private PlatformSurfaceCheck() {
    }

    public static void main(String[] args) throws Exception {
        MainLauncherCheck.main(new String[0]);
        MainIncrementalCompileCheck.main(new String[0]);
        PlatformLawVersionMismatchCheck.main(new String[0]);
        PlatformGuiSuggestionsCheck.main(new String[0]);
        PlatformGuiNextActionCheck.main(new String[0]);
        PlatformListCheck.main(new String[0]);
        checkPlatformHelp();
        PlatformGuiFallbackCheck.main(new String[0]);
        checkTaskNextSurface();
        checkAccountNextSurface();
        checkDocumentNextSurface();
        checkTaskShowSurface();
        checkAccountShowSurface();
        checkDocumentShowSurface();
        checkEmptyChainMessages();
        checkShowRejectsEntityOptions();
        System.out.println("platformSurfaceCheckPassed=true");
    }

    private static void checkPlatformHelp() throws Exception {
        String output = runPlatformCli(null, "help");
        requireContains(output, "  PlatformCli --gui [command...]");
        requireContains(output, "  PlatformCli suggest [--root <dir>] [--task-root <dir>] [--account-root <dir>] [--document-root <dir>] [query...]");
        requireContains(output, "Show output:");
        requireContains(output, "  STATE   current truth");
        requireContains(output, "  WHY     what explains it");
        requireContains(output, "  PATH    the shortest causal path");
        requireContains(output, "  TRACE   event-by-event proof");
        requireContains(output, "  OUTPUTS derived outputs");
    }

    private static void checkTaskNextSurface() throws Exception {
        Path rootDir = java.nio.file.Files.createTempDirectory("platform-task-next-check-");
        String emptyOutput = runPlatformCli(rootDir, "task", "next");
        requireContains(emptyOutput, "Root: " + RootDisplay.concise(rootDir));
        requireContains(emptyOutput, "NEXT");
        requireContains(emptyOutput, "  - task create --task <taskId>");

        runPlatformCli(rootDir, "task", "create", "--task", "task-next", "--actor", "alice", "--time", "1");
        String createdOutput = runPlatformCli(rootDir, "task", "next");
        requireContains(createdOutput, "  - task start --task task-next");
        requireContains(createdOutput, "  - task cancel --task task-next");
    }

    private static void checkAccountNextSurface() throws Exception {
        Path rootDir = java.nio.file.Files.createTempDirectory("platform-account-next-check-");
        String emptyOutput = runPlatformCli(rootDir, "account", "next");
        requireContains(emptyOutput, "Root: " + RootDisplay.concise(rootDir));
        requireContains(emptyOutput, "  - account open --account <accountId>");

        runPlatformCli(rootDir, "account", "open", "--account", "acct-next", "--actor", "alice", "--time", "1");
        String openOutput = runPlatformCli(rootDir, "account", "next");
        requireContains(openOutput, "  - account deposit --account acct-next --amount <n>");
        requireContains(openOutput, "  - account withdraw --account acct-next --amount <n>");
        requireContains(openOutput, "  - account close --account acct-next");
        runPlatformCli(rootDir, "account", "close", "--account", "acct-next", "--actor", "alice", "--time", "2");
        String closedOutput = runPlatformCli(rootDir, "account", "next");
        requireContains(closedOutput, "  (no valid next events: account is CLOSED)");
    }

    private static void checkDocumentNextSurface() throws Exception {
        Path rootDir = java.nio.file.Files.createTempDirectory("platform-document-next-check-");
        String emptyOutput = runPlatformCli(rootDir, "document", "next");
        requireContains(emptyOutput, "Root: " + RootDisplay.concise(rootDir));
        requireContains(emptyOutput, "  - document draft --document <documentId>");

        runPlatformCli(rootDir, "document", "draft", "--document", "doc-next", "--actor", "alice", "--time", "1");
        String draftedOutput = runPlatformCli(rootDir, "document", "next");
        requireContains(draftedOutput, "  - document submit --document doc-next");

        runPlatformCli(rootDir, "document", "submit", "--document", "doc-next", "--actor", "alice", "--time", "2");
        String reviewOutput = runPlatformCli(rootDir, "document", "next");
        requireContains(reviewOutput, "  - document reject --document doc-next --target-event doc-evt-000002 --reason <text>");
        requireContains(reviewOutput, "  - document approve --document doc-next");
    }

    private static void checkTaskShowSurface() throws Exception {
        Path rootDir = java.nio.file.Files.createTempDirectory("platform-task-surface-check-");
        runPlatformCli(rootDir, "task", "create", "--task", "task-001", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "task", "start", "--task", "task-001", "--actor", "alice", "--time", "2");
        String output = runPlatformCli(rootDir, "task", "show");
        requireContains(output, "Root: " + RootDisplay.concise(rootDir));
        requireCommonShowShape(output);
        requireContains(output, "  task: task-001");
    }

    private static void checkAccountShowSurface() throws Exception {
        Path rootDir = java.nio.file.Files.createTempDirectory("platform-account-surface-check-");
        runPlatformCli(rootDir, "account", "open", "--account", "acct-001", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "account", "deposit", "--account", "acct-001", "--amount", "20", "--actor", "alice", "--time", "2");
        String output = runPlatformCli(rootDir, "account", "show");
        requireContains(output, "Root: " + RootDisplay.concise(rootDir));
        requireCommonShowShape(output);
        requireContains(output, "  account: acct-001");
    }

    private static void checkDocumentShowSurface() throws Exception {
        Path rootDir = java.nio.file.Files.createTempDirectory("platform-document-surface-check-");
        runPlatformCli(rootDir, "document", "draft", "--document", "doc-001", "--actor", "alice", "--time", "1");
        runPlatformCli(rootDir, "document", "submit", "--document", "doc-001", "--actor", "alice", "--time", "2");
        String output = runPlatformCli(rootDir, "document", "show");
        requireContains(output, "Root: " + RootDisplay.concise(rootDir));
        requireCommonShowShape(output);
        requireContains(output, "  document: doc-001");
    }

    private static void checkEmptyChainMessages() throws Exception {
        Path taskRoot = java.nio.file.Files.createTempDirectory("platform-task-empty-show-check-");
        Path accountRoot = java.nio.file.Files.createTempDirectory("platform-account-empty-show-check-");
        Path documentRoot = java.nio.file.Files.createTempDirectory("platform-document-empty-show-check-");

        requireFailureContains(runPlatformCliProcess(taskRoot, "task", "show"), "No task chain exists at this root yet");
        requireFailureContains(runPlatformCliProcess(taskRoot, "task", "verify"), "No task chain exists at this root yet");
        requireFailureContains(runPlatformCliProcess(accountRoot, "account", "show"), "No account chain exists at this root yet");
        requireFailureContains(runPlatformCliProcess(accountRoot, "account", "verify"), "No account chain exists at this root yet");
        requireFailureContains(runPlatformCliProcess(documentRoot, "document", "show"), "No document chain exists at this root yet");
        requireFailureContains(runPlatformCliProcess(documentRoot, "document", "verify"), "No document chain exists at this root yet");
    }

    private static void checkShowRejectsEntityOptions() throws Exception {
        Path taskRoot = java.nio.file.Files.createTempDirectory("platform-task-show-options-check-");
        Path accountRoot = java.nio.file.Files.createTempDirectory("platform-account-show-options-check-");
        Path documentRoot = java.nio.file.Files.createTempDirectory("platform-document-show-options-check-");

        runPlatformCli(taskRoot, "task", "create", "--task", "task-001", "--actor", "alice", "--time", "1");
        runPlatformCli(accountRoot, "account", "open", "--account", "acct-001", "--actor", "alice", "--time", "1");
        runPlatformCli(documentRoot, "document", "draft", "--document", "doc-001", "--actor", "alice", "--time", "1");

        requireFailureContains(
            runPlatformCliProcess(taskRoot, "task", "show", "--task", "task-001"),
            "Unsupported option for task command: --task"
        );
        requireFailureContains(
            runPlatformCliProcess(accountRoot, "account", "show", "--account", "acct-001"),
            "Unsupported option for account command: --account"
        );
        requireFailureContains(
            runPlatformCliProcess(documentRoot, "document", "show", "--document", "doc-001"),
            "Unsupported option for document command: --document"
        );
    }

    private static void requireCommonShowShape(String output) {
        requireContains(output, "STATE");
        requireContains(output, "WHY");
        requireContains(output, "PATH");
        requireContains(output, "TRACE");
        requireContains(output, "OUTPUTS");
        requireContains(output, "  status: ");
        requireContains(output, "  last change: ");
        requireContains(output, "  event count: ");
        requireContains(output, "  last event id: ");
        requireInOrder(output, "STATE", "WHY", "PATH", "TRACE", "OUTPUTS");
    }

    private static void requireInOrder(String output, String... tokens) {
        int index = -1;
        for (String token : tokens) {
            int next = output.indexOf(token, index + 1);
            if (next < 0) {
                throw new IllegalStateException("Expected output to contain '" + token + "' but was: " + output);
            }
            if (next < index) {
                throw new IllegalStateException("Expected sections in order but was: " + output);
            }
            index = next;
        }
    }

    private static String runPlatformCli(Path rootDir, String... commandArgs) throws Exception {
        ProcessResult result = runPlatformCliProcess(rootDir, commandArgs);
        if (result.exitCode() != 0) {
            throw new IllegalStateException("Expected PlatformCli success but failed: " + result.output());
        }
        return result.output();
    }

    private static ProcessResult runPlatformCliProcess(Path rootDir, String... commandArgs) throws Exception {
        String javaBinary = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String classpath = System.getProperty("java.class.path");

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(javaBinary);
        command.add("-cp");
        command.add(classpath);
        command.add(PlatformCli.class.getName());
        for (String arg : commandArgs) {
            command.add(arg);
        }
        if (rootDir != null) {
            command.add("--root");
            command.add(rootDir.toString());
        }

        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();

        String output;
        try (InputStream inputStream = process.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            inputStream.transferTo(buffer);
            output = buffer.toString(StandardCharsets.UTF_8);
        }

        int exitCode = process.waitFor();
        return new ProcessResult(exitCode, output);
    }

    private static void requireContains(String output, String expected) {
        if (!output.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + output);
        }
    }

    private static void requireFailureContains(ProcessResult result, String expected) {
        if (result.exitCode() == 0) {
            throw new IllegalStateException("Expected PlatformCli failure but succeeded: " + result.output());
        }
        requireContains(result.output(), expected);
    }

    private record ProcessResult(int exitCode, String output) {
    }

}
