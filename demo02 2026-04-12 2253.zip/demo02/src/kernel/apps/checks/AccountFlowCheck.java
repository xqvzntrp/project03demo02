package kernel.apps.checks;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.flow.AccountFlow;

public final class AccountFlowCheck {
    private AccountFlowCheck() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("account-flow-check-");

        AccountFlow.AccountFlowSession session = AccountFlow.begin(rootDir);
        requireEquals("account", session.currentField());
        session = session.answer("acct-100");
        requireEquals("actor", session.currentField());
        session = session.answer("alice");
        requireEquals("time", session.currentField());
        session = session.answer("1");
        requireEquals(
            "account open --account acct-100 --root " + rootDir + " --actor alice --time 1",
            session.commandPreview()
        );
        AccountFlow.AccountFlowExecution open = session.execute();
        requireEquals(0, open.exitCode());
        requireContains(open.output(), "opened=true");

        session = open.nextSession();
        requireEquals(AccountFlow.Action.DEPOSIT, session.action());
        requireEquals("amount", session.currentField());
        session = session.answer("25").answer("bob").answer("2");
        requireEquals(
            "account deposit --account acct-100 --amount 25 --root " + rootDir + " --actor bob --time 2",
            session.commandPreview()
        );
        AccountFlow.AccountFlowExecution deposit = session.execute();
        requireEquals(0, deposit.exitCode());
        requireContains(deposit.output(), "eventType=FundsDeposited");

        System.out.println("accountFlowCheckPassed=true");
    }

    private static void requireContains(String actual, String expected) {
        if (!actual.contains(expected)) {
            throw new IllegalStateException("Expected output to contain '" + expected + "' but was: " + actual);
        }
    }

    private static void requireEquals(Object expected, Object actual) {
        if (!expected.equals(actual)) {
            throw new IllegalStateException("Expected '" + expected + "' but was '" + actual + "'");
        }
    }
}
