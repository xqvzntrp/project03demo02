package kernel.apps;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

import kernel.apps.accountcli.AccountCli;
import kernel.apps.documentcli.DocumentCli;
import kernel.apps.support.AppConventions;
import kernel.apps.taskcli.TaskCli;

public final class PlatformGuiSuggestions {
    private static final List<String> ROOT_SUGGESTIONS = List.of(
        "help",
        "task list",
        "account list",
        "document list",
        "task flow --new",
        "task show",
        "task flow",
        "account flow --new",
        "account show",
        "account flow",
        "document flow --new",
        "document show",
        "document flow",
        "task create --task <taskId>",
        "account open --account <accountId>",
        "document draft --document <documentId>"
    );

    private static final List<String> TASK_SUGGESTIONS = List.of(
        "task help",
        "task list",
        "task show",
        "task verify",
        "task flow --new",
        "task flow",
        "task create --task <taskId>",
        "task start --task <taskId>",
        "task complete --task <taskId>",
        "task correct --task <taskId> --target-event <eventId> --reason <text>",
        "task cancel --task <taskId>"
    );

    private static final List<String> ACCOUNT_SUGGESTIONS = List.of(
        "account help",
        "account list",
        "account show",
        "account verify",
        "account flow --new",
        "account flow",
        "account open --account <accountId>",
        "account deposit --account <accountId> --amount <n>",
        "account withdraw --account <accountId> --amount <n>",
        "account close --account <accountId>"
    );

    private static final List<String> DOCUMENT_SUGGESTIONS = List.of(
        "document help",
        "document list",
        "document show",
        "document verify",
        "document flow --new",
        "document flow",
        "document draft --document <documentId>",
        "document submit --document <documentId>",
        "document reject --document <documentId> --target-event <eventId> --reason <text>",
        "document revise --document <documentId>",
        "document approve --document <documentId>"
    );

    private PlatformGuiSuggestions() {
    }

    public static List<String> suggestionsFor(String input) {
        return suggestionsFor(
            input,
            AppConventions.defaultRoot("task"),
            AppConventions.defaultRoot("account"),
            AppConventions.defaultRoot("document")
        );
    }

    public static List<String> suggestionsFor(String input, Path taskWorkspace, Path accountWorkspace, Path documentWorkspace) {
        String trimmed = input == null ? "" : input.trim();
        if (trimmed.isEmpty()) {
            LinkedHashSet<String> root = new LinkedHashSet<>(ROOT_SUGGESTIONS);
            root.addAll(dynamicSuggestions("task", taskWorkspace));
            root.addAll(dynamicSuggestions("account", accountWorkspace));
            root.addAll(dynamicSuggestions("document", documentWorkspace));
            return List.copyOf(root);
        }

        String normalized = trimmed.toLowerCase(Locale.ROOT);
        String firstToken = firstToken(normalized);
        List<String> domainSuggestions = switch (firstToken) {
            case "task" -> TASK_SUGGESTIONS;
            case "account" -> ACCOUNT_SUGGESTIONS;
            case "document" -> DOCUMENT_SUGGESTIONS;
            default -> ROOT_SUGGESTIONS;
        };
        List<String> dynamicSuggestions = switch (firstToken) {
            case "task" -> dynamicSuggestions("task", taskWorkspace);
            case "account" -> dynamicSuggestions("account", accountWorkspace);
            case "document" -> dynamicSuggestions("document", documentWorkspace);
            default -> List.of();
        };

        LinkedHashSet<String> ranked = new LinkedHashSet<>();
        addMatches(ranked, domainSuggestions, normalized);
        addMatches(ranked, dynamicSuggestions, normalized);
        addMatches(ranked, ROOT_SUGGESTIONS, normalized);

        if (ranked.isEmpty()) {
            ranked.addAll(domainSuggestions);
            ranked.addAll(dynamicSuggestions);
        }
            return List.copyOf(ranked);
        }

    private static void addMatches(LinkedHashSet<String> ranked, List<String> candidates, String normalized) {
        for (String candidate : candidates) {
            String candidateLower = candidate.toLowerCase(Locale.ROOT);
            if (candidateLower.startsWith(normalized) || candidateLower.contains(normalized)) {
                ranked.add(candidate);
            }
        }
    }

    private static String firstToken(String value) {
        int whitespace = value.indexOf(' ');
        return whitespace < 0 ? value : value.substring(0, whitespace);
    }

    private static List<String> dynamicSuggestions(String domain, Path workspaceRoot) {
        try {
            return switch (domain) {
                case "task" -> TaskCli.listEntries(workspaceRoot).stream().map(entry -> entry.showCommand(workspaceRoot)).toList();
                case "account" -> AccountCli.listEntries(workspaceRoot).stream().map(entry -> entry.showCommand(workspaceRoot)).toList();
                case "document" -> DocumentCli.listEntries(workspaceRoot).stream().map(entry -> entry.showCommand(workspaceRoot)).toList();
                default -> List.of();
            };
        } catch (IOException e) {
            return List.of();
        } catch (Exception e) {
            return List.of();
        }
    }
}
