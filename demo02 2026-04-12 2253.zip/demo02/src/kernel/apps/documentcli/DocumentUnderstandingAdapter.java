package kernel.apps.documentcli;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Function;
import java.util.stream.Collectors;

import kernel.core.DerivedOutput;
import kernel.core.ReplayRun;
import kernel.core.VerifiedEvent;
import kernel.domain.spi.UnderstandingView;
import kernel.laws.document.DocumentStateView;
import kernel.laws.document.DocumentStatus;

final class DocumentUnderstandingAdapter {
    private DocumentUnderstandingAdapter() {
    }

    static UnderstandingView understand(DocumentStateView state, ReplayRun replayRun, List<VerifiedEvent> verifiedEvents) {
        Map<String, VerifiedEvent> eventsById = verifiedEvents.stream()
            .collect(Collectors.toMap(VerifiedEvent::eventId, Function.identity(), (left, right) -> left, LinkedHashMap::new));
        Map<String, Integer> revisionsByEventId = revisionsByEventId(verifiedEvents);
        List<VerifiedEvent> rejectionEvents = filterEvents(verifiedEvents, "DocumentRejected");
        VerifiedEvent lastStateEvent = state.lastStateEventId() == null ? null : eventsById.get(state.lastStateEventId());
        VerifiedEvent rejectionEvent = state.lastRejectionEventId() == null ? null : eventsById.get(state.lastRejectionEventId());
        VerifiedEvent revisedEvent = rejectionEvent == null ? null : findNextEvent(verifiedEvents, rejectionEvent.eventId(), "DocumentRevised");
        VerifiedEvent resubmittedEvent = revisedEvent == null ? null : findNextEvent(verifiedEvents, revisedEvent.eventId(), "DocumentSubmitted");

        List<String> stateLines = new ArrayList<>();
        stateLines.add("  document: " + state.documentId());
        stateLines.add("  status: " + humanStatus(state.status()));
        stateLines.add("  revision: " + state.currentRevision());
        if (lastStateEvent != null) {
            stateLines.add("  last change: " + humanEvent(lastStateEvent, revisionsByEventId));
        }
        stateLines.add("  event count: " + replayRun.finalState().eventCount());
        stateLines.add("  last event id: " + replayRun.finalState().lastEventId());

        List<String> whyLines = new ArrayList<>();
        if (rejectionEvent != null) {
            whyLines.add("  review cycles: " + rejectionEvents.size() + " rejection" + (rejectionEvents.size() == 1 ? "" : "s") + " before approval");
            whyLines.add("  last rejection: by " + rejectionEvent.actorId() + " at " + rejectionEvent.timeValue());
            whyLines.add("  reason: " + state.lastRejectionReason());
            if (rejectionEvents.size() > 1) {
                VerifiedEvent priorRejectionEvent = rejectionEvents.get(rejectionEvents.size() - 2);
                whyLines.add("  earlier rejection: " + rejectionReason(priorRejectionEvent) + " by "
                    + priorRejectionEvent.actorId() + " at " + priorRejectionEvent.timeValue());
            }
            if (revisedEvent != null) {
                whyLines.add("  recovered by: " + humanEvent(revisedEvent, revisionsByEventId));
            }
            if (resubmittedEvent != null && state.status() != DocumentStatus.CHANGES_REQUESTED && state.status() != DocumentStatus.DRAFT) {
                whyLines.add("  resubmitted by: " + humanEvent(resubmittedEvent, revisionsByEventId));
            }
        } else if (state.status() == DocumentStatus.IN_REVIEW && lastStateEvent != null) {
            whyLines.add("  awaiting review since " + humanEvent(lastStateEvent, revisionsByEventId));
        } else if (state.status() == DocumentStatus.APPROVED && lastStateEvent != null) {
            whyLines.add("  approved without rejection history");
        } else {
            whyLines.add("  no rejection or approval yet");
        }

        List<String> pathLines = List.of("  " + String.join(" -> ", summarizedPath(verifiedEvents, revisionsByEventId)));

        List<String> traceLines = new ArrayList<>();
        for (String eventId : state.eventIds()) {
            VerifiedEvent event = eventsById.get(eventId);
            if (event != null) {
                traceLines.add("  [" + event.eventId() + "] " + humanEvent(event, revisionsByEventId));
            }
        }

        List<String> outputLines = new ArrayList<>();
        for (DerivedOutput output : replayRun.outputs()) {
            outputLines.add("  - " + output.kind() + " eventId=" + output.eventId() + " value=" + output.value());
        }

        return new UnderstandingView(List.of(
            UnderstandingView.section("STATE", stateLines),
            UnderstandingView.section("WHY", whyLines),
            UnderstandingView.section("PATH", pathLines),
            UnderstandingView.section("TRACE", traceLines),
            UnderstandingView.section("OUTPUTS", outputLines)
        ));
    }

    private static Map<String, Integer> revisionsByEventId(List<VerifiedEvent> verifiedEvents) {
        Map<String, Integer> revisions = new LinkedHashMap<>();
        int currentRevision = 0;
        for (VerifiedEvent event : verifiedEvents) {
            switch (event.eventType()) {
                case "DocumentDrafted" -> currentRevision = 1;
                case "DocumentRevised" -> currentRevision++;
                default -> {
                }
            }
            revisions.put(event.eventId(), currentRevision);
        }
        return revisions;
    }

    private static List<VerifiedEvent> filterEvents(List<VerifiedEvent> verifiedEvents, String eventType) {
        List<VerifiedEvent> filtered = new ArrayList<>();
        for (VerifiedEvent event : verifiedEvents) {
            if (eventType.equals(event.eventType())) {
                filtered.add(event);
            }
        }
        return filtered;
    }

    private static VerifiedEvent findNextEvent(List<VerifiedEvent> verifiedEvents, String afterEventId, String eventType) {
        boolean pastTarget = false;
        for (VerifiedEvent event : verifiedEvents) {
            if (!pastTarget) {
                pastTarget = event.eventId().equals(afterEventId);
                continue;
            }
            if (eventType.equals(event.eventType())) {
                return event;
            }
        }
        return null;
    }

    private static List<String> summarizedPath(List<VerifiedEvent> verifiedEvents, Map<String, Integer> revisionsByEventId) {
        List<String> path = new ArrayList<>();
        for (VerifiedEvent event : verifiedEvents) {
            path.add(summarize(event, revisionsByEventId));
        }
        return path;
    }

    private static String summarize(VerifiedEvent event, Map<String, Integer> revisionsByEventId) {
        return switch (event.eventType()) {
            case "DocumentDrafted" -> "Drafted v" + revisionsByEventId.get(event.eventId());
            case "DocumentSubmitted" -> "Submitted";
            case "DocumentRejected" -> "Rejected";
            case "DocumentRevised" -> "Revised v" + revisionsByEventId.get(event.eventId());
            case "DocumentApproved" -> "Approved";
            default -> event.eventType();
        };
    }

    private static String humanEvent(VerifiedEvent event, Map<String, Integer> revisionsByEventId) {
        return switch (event.eventType()) {
            case "DocumentDrafted" -> "drafted revision " + revisionsByEventId.get(event.eventId())
                + " by " + event.actorId() + " at " + event.timeValue();
            case "DocumentSubmitted" -> "submitted revision " + revisionsByEventId.get(event.eventId())
                + " by " + event.actorId() + " at " + event.timeValue();
            case "DocumentRejected" -> "rejected by " + event.actorId() + " at " + event.timeValue();
            case "DocumentRevised" -> "revised to revision " + revisionsByEventId.get(event.eventId())
                + " by " + event.actorId() + " at " + event.timeValue();
            case "DocumentApproved" -> "approved by " + event.actorId() + " at " + event.timeValue();
            default -> event.eventType() + " by " + event.actorId() + " at " + event.timeValue();
        };
    }

    private static String humanStatus(DocumentStatus status) {
        return switch (status) {
            case DRAFT -> "DRAFT";
            case IN_REVIEW -> "IN_REVIEW";
            case CHANGES_REQUESTED -> "CHANGES_REQUESTED";
            case APPROVED -> "APPROVED";
        };
    }

    private static String rejectionReason(VerifiedEvent event) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(event.payloadBytes()), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse document payload for eventId " + event.eventId(), e);
        }
        return properties.getProperty("reason", "unknown");
    }
}
