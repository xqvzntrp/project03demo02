package kernel.apps.flow;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

import kernel.apps.PlatformCli;
import kernel.apps.taskcli.TaskCli;

public final class TaskFlowShell {
    private TaskFlowShell() {
    }

    public static int run(Path rootDir, InputStream in, PrintStream out, PrintStream err) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        TaskFlow.TaskFlowSession session = TaskFlow.begin(rootDir);

        out.println("Task Flow");
        out.println("Scope: one guided action (create, start, complete, or correct when next exposes it)");
        out.println("Type 'exit' at any prompt to stop.");
        out.println();

        if (session.isFinished()) {
            out.println("flowComplete=true");
            out.println("reason=no guided task action available in minimal flow");
            return 0;
        }

        out.println("next: task " + session.action().commandName());
        while (!session.readyToExecute()) {
            TaskFlow.TaskFlowPrompt prompt = session.prompt();
            out.println("[preview]");
            out.println(prompt.commandPreview());
            out.print(prompt.field() + ": ");
            out.flush();

            String answer = reader.readLine();
            if (answer == null) {
                out.println();
                out.println("aborted=true");
                out.println("reason=input closed");
                return 0;
            }
            if (isExit(answer)) {
                out.println("aborted=true");
                return 0;
            }

            try {
                session = session.answer(answer);
            } catch (RuntimeException e) {
                err.println("error=" + e.getMessage());
            }
        }

        out.println("[preview]");
        out.println(session.commandPreview());
        out.print("[enter = run | exit = quit] ");
        out.flush();

        String confirmation = reader.readLine();
        if (confirmation == null) {
            out.println();
            out.println("aborted=true");
            out.println("reason=input closed");
            return 0;
        }
        if (isExit(confirmation)) {
            out.println("aborted=true");
            return 0;
        }
        if (!confirmation.isBlank()) {
            err.println("error=Press Enter to run or type exit to quit");
            return 1;
        }

        TaskFlow.TaskFlowExecution execution = session.execute();
        out.println("[result]");
        out.println(execution.output());
        out.println();

        if (execution.exitCode() != 0) {
            return execution.exitCode();
        }

        out.println("[state]");
        out.println(runPlatformCli("task", "show", "--root", rootDir.toString()));
        out.println();
        out.println("[next]");
        for (String command : TaskCli.nextCommands(rootDir)) {
            out.println("  - " + command);
        }
        return 0;
    }

    private static String runPlatformCli(String... args) throws Exception {
        ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
        ByteArrayOutputStream errBuffer = new ByteArrayOutputStream();
        int exitCode = PlatformCli.run(
            args,
            new PrintStream(outBuffer, true, StandardCharsets.UTF_8),
            new PrintStream(errBuffer, true, StandardCharsets.UTF_8)
        );

        String output = outBuffer.toString(StandardCharsets.UTF_8);
        String error = errBuffer.toString(StandardCharsets.UTF_8);
        StringBuilder builder = new StringBuilder();
        if (!output.isBlank()) {
            builder.append(output.stripTrailing());
        }
        if (!error.isBlank()) {
            if (builder.length() > 0) {
                builder.append(System.lineSeparator());
            }
            builder.append(error.stripTrailing());
        }
        if (builder.length() == 0) {
            builder.append("exitCode=").append(exitCode);
        } else if (exitCode != 0) {
            builder.append(System.lineSeparator()).append("exitCode=").append(exitCode);
        }
        return builder.toString();
    }

    private static boolean isExit(String value) {
        String normalized = value == null ? "" : value.trim();
        return "exit".equalsIgnoreCase(normalized) || "quit".equalsIgnoreCase(normalized);
    }
}
