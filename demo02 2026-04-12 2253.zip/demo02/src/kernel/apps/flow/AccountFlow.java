package kernel.apps.flow;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;

import kernel.apps.PlatformCli;
import kernel.apps.accountcli.AccountCli;
import kernel.apps.support.CommandLine;

public final class AccountFlow {
    private AccountFlow() {
    }

    public static AccountFlowSession begin(Path rootDir) throws Exception {
        Objects.requireNonNull(rootDir, "rootDir");
        return AccountFlowSession.fromRoot(rootDir);
    }

    public record AccountFlowPrompt(
        String title,
        String field,
        String instruction,
        String commandPreview
    ) {
    }

    public record AccountFlowExecution(
        String command,
        String output,
        int exitCode,
        AccountFlowSession nextSession
    ) {
    }

    public record AccountFlowSession(
        Path rootDir,
        Action action,
        String accountId,
        String amount,
        String actor,
        String time
    ) {
        public static AccountFlowSession fromRoot(Path rootDir) throws Exception {
            for (String nextCommand : AccountCli.nextCommands(rootDir)) {
                Action action = Action.fromCommand(nextCommand);
                if (action == Action.DONE) {
                    continue;
                }
                String parsedAccountId = commandOption(nextCommand, "--account");
                if (parsedAccountId != null && parsedAccountId.startsWith("<") && parsedAccountId.endsWith(">")) {
                    parsedAccountId = null;
                }
                String parsedAmount = commandOption(nextCommand, "--amount");
                if (parsedAmount != null && parsedAmount.startsWith("<") && parsedAmount.endsWith(">")) {
                    parsedAmount = null;
                }
                return new AccountFlowSession(rootDir, action, parsedAccountId, parsedAmount, null, null);
            }
            return new AccountFlowSession(rootDir, Action.DONE, null, null, null, null);
        }

        public boolean isFinished() {
            return action == Action.DONE;
        }

        public boolean readyToExecute() {
            return !isFinished() && currentField() == null;
        }

        public AccountFlowPrompt prompt() {
            if (isFinished()) {
                throw new IllegalStateException("Account flow is finished");
            }

            String field = currentField();
            return switch (field) {
                case "account" -> new AccountFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter account id for the new root-scoped account.",
                    commandPreview()
                );
                case "amount" -> new AccountFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter amount as a positive integer.",
                    commandPreview()
                );
                case "actor" -> new AccountFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter actor id for this command.",
                    commandPreview()
                );
                case "time" -> new AccountFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter event time as an integer.",
                    commandPreview()
                );
                default -> throw new IllegalStateException("No prompt is available when the command is ready to execute");
            };
        }

        public AccountFlowSession answer(String value) {
            if (isFinished()) {
                throw new IllegalStateException("Account flow is finished");
            }

            String normalized = requireValue(value);
            String field = currentField();
            if (field == null) {
                throw new IllegalStateException("Command is ready to execute");
            }

            return switch (field) {
                case "account" -> new AccountFlowSession(rootDir, action, normalized, amount, actor, time);
                case "amount" -> {
                    Long.parseLong(normalized);
                    yield new AccountFlowSession(rootDir, action, accountId, normalized, actor, time);
                }
                case "actor" -> new AccountFlowSession(rootDir, action, accountId, amount, normalized, time);
                case "time" -> {
                    Long.parseLong(normalized);
                    yield new AccountFlowSession(rootDir, action, accountId, amount, actor, normalized);
                }
                default -> throw new IllegalStateException("Unknown account flow field: " + field);
            };
        }

        public String commandPreview() {
            if (isFinished()) {
                return "(no guided account action available)";
            }
            return CommandLine.join(commandArgs(
                accountId != null ? accountId : "<accountId>",
                amount != null ? amount : "<n>",
                actor != null ? actor : "<actor>",
                time != null ? time : "<time>"
            ));
        }

        public AccountFlowExecution execute() throws Exception {
            if (!readyToExecute()) {
                throw new IllegalStateException("Account flow command is not ready to execute");
            }

            List<String> args = commandArgs(accountId, amount, actor, time);
            ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
            ByteArrayOutputStream errBuffer = new ByteArrayOutputStream();
            int exitCode = PlatformCli.run(
                args.toArray(String[]::new),
                new PrintStream(outBuffer, true, StandardCharsets.UTF_8),
                new PrintStream(errBuffer, true, StandardCharsets.UTF_8)
            );

            String output = renderOutput(outBuffer, errBuffer, exitCode);
            AccountFlowSession nextSession = exitCode == 0 ? fromRoot(rootDir) : this;
            return new AccountFlowExecution(CommandLine.join(args), output, exitCode, nextSession);
        }

        public String currentField() {
            if (isFinished()) {
                return null;
            }
            if (accountId == null) {
                return "account";
            }
            if (requiresAmount() && amount == null) {
                return "amount";
            }
            if (actor == null) {
                return "actor";
            }
            if (time == null) {
                return "time";
            }
            return null;
        }

        private boolean requiresAmount() {
            return action == Action.DEPOSIT;
        }

        private List<String> commandArgs(String commandAccountId, String commandAmount, String commandActor, String commandTime) {
            java.util.ArrayList<String> args = new java.util.ArrayList<>();
            args.add("account");
            args.add(action.commandName());
            args.add("--account");
            args.add(commandAccountId);
            if (requiresAmount()) {
                args.add("--amount");
                args.add(commandAmount);
            }
            args.add("--root");
            args.add(rootDir.toString());
            args.add("--actor");
            args.add(commandActor);
            args.add("--time");
            args.add(commandTime);
            return List.copyOf(args);
        }

        private static String renderOutput(ByteArrayOutputStream outBuffer, ByteArrayOutputStream errBuffer, int exitCode) {
            String output = outBuffer.toString(StandardCharsets.UTF_8);
            String error = errBuffer.toString(StandardCharsets.UTF_8);
            StringBuilder builder = new StringBuilder();
            if (!output.isBlank()) {
                builder.append(output.stripTrailing());
            }
            if (!error.isBlank()) {
                if (builder.length() > 0) {
                    builder.append(System.lineSeparator());
                }
                builder.append(error.stripTrailing());
            }
            if (builder.length() == 0) {
                builder.append("exitCode=").append(exitCode);
            } else if (exitCode != 0) {
                builder.append(System.lineSeparator()).append("exitCode=").append(exitCode);
            }
            return builder.toString();
        }

        private static String commandOption(String command, String option) {
            String[] tokens = CommandLine.tokenize(command);
            for (int i = 0; i < tokens.length - 1; i++) {
                if (option.equals(tokens[i])) {
                    return tokens[i + 1];
                }
            }
            return null;
        }

        private static String requireValue(String value) {
            String normalized = value == null ? "" : value.trim();
            if (normalized.isEmpty()) {
                throw new IllegalArgumentException("Account flow input must not be blank");
            }
            return normalized;
        }
    }

    public enum Action {
        OPEN("open", "Open Account"),
        DEPOSIT("deposit", "Deposit Funds"),
        DONE("", "Done");

        private final String commandName;
        private final String promptTitle;

        Action(String commandName, String promptTitle) {
            this.commandName = commandName;
            this.promptTitle = promptTitle;
        }

        public String commandName() {
            return commandName;
        }

        public String promptTitle() {
            return promptTitle;
        }

        public static Action fromCommand(String command) {
            String[] tokens = CommandLine.tokenize(command);
            if (tokens.length < 2 || !"account".equals(tokens[0])) {
                return DONE;
            }
            return switch (tokens[1]) {
                case "open" -> OPEN;
                case "deposit" -> DEPOSIT;
                default -> DONE;
            };
        }
    }
}
