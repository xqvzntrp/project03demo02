package kernel.apps.flow;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;

import kernel.apps.PlatformCli;
import kernel.apps.support.CommandLine;
import kernel.apps.taskcli.TaskCli;

public final class TaskFlow {
    private TaskFlow() {
    }

    public static TaskFlowSession begin(Path rootDir) throws Exception {
        Objects.requireNonNull(rootDir, "rootDir");
        return TaskFlowSession.fromRoot(rootDir);
    }

    public record TaskFlowPrompt(
        String title,
        String field,
        String instruction,
        String commandPreview
    ) {
    }

    public record TaskFlowExecution(
        String command,
        String output,
        int exitCode,
        TaskFlowSession nextSession
    ) {
    }

    public record TaskFlowSession(
        Path rootDir,
        Action action,
        String taskId,
        String actor,
        String time
    ) {
        public static TaskFlowSession fromRoot(Path rootDir) throws Exception {
            for (String nextCommand : TaskCli.nextCommands(rootDir)) {
                Action action = Action.fromCommand(nextCommand);
                if (action == Action.DONE) {
                    continue;
                }
                String parsedTaskId = commandOption(nextCommand, "--task");
                if (parsedTaskId != null && parsedTaskId.startsWith("<") && parsedTaskId.endsWith(">")) {
                    parsedTaskId = null;
                }
                return new TaskFlowSession(rootDir, action, parsedTaskId, null, null);
            }
            return new TaskFlowSession(rootDir, Action.DONE, null, null, null);
        }

        public boolean isFinished() {
            return action == Action.DONE;
        }

        public boolean readyToExecute() {
            return !isFinished() && currentField() == null;
        }

        public TaskFlowPrompt prompt() {
            if (isFinished()) {
                throw new IllegalStateException("Task flow is finished");
            }

            String field = currentField();
            return switch (field) {
                case "task" -> new TaskFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter task id for the new root-scoped task.",
                    commandPreview()
                );
                case "actor" -> new TaskFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter actor id for this command.",
                    commandPreview()
                );
                case "time" -> new TaskFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter event time as an integer.",
                    commandPreview()
                );
                default -> throw new IllegalStateException("No prompt is available when the command is ready to execute");
            };
        }

        public TaskFlowSession answer(String value) {
            if (isFinished()) {
                throw new IllegalStateException("Task flow is finished");
            }

            String normalized = requireValue(value);
            String field = currentField();
            if (field == null) {
                throw new IllegalStateException("Command is ready to execute");
            }

            return switch (field) {
                case "task" -> new TaskFlowSession(rootDir, action, normalized, actor, time);
                case "actor" -> new TaskFlowSession(rootDir, action, taskId, normalized, time);
                case "time" -> {
                    Long.parseLong(normalized);
                    yield new TaskFlowSession(rootDir, action, taskId, actor, normalized);
                }
                default -> throw new IllegalStateException("Unknown task flow field: " + field);
            };
        }

        public String commandPreview() {
            if (isFinished()) {
                return "(no guided task action available)";
            }
            return CommandLine.join(commandArgs(
                taskId != null ? taskId : "<taskId>",
                actor != null ? actor : "<actor>",
                time != null ? time : "<time>"
            ));
        }

        public TaskFlowExecution execute() throws Exception {
            if (!readyToExecute()) {
                throw new IllegalStateException("Task flow command is not ready to execute");
            }

            List<String> args = commandArgs(taskId, actor, time);
            ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
            ByteArrayOutputStream errBuffer = new ByteArrayOutputStream();
            int exitCode = PlatformCli.run(
                args.toArray(String[]::new),
                new PrintStream(outBuffer, true, StandardCharsets.UTF_8),
                new PrintStream(errBuffer, true, StandardCharsets.UTF_8)
            );

            String output = renderOutput(outBuffer, errBuffer, exitCode);
            TaskFlowSession nextSession = exitCode == 0 ? fromRoot(rootDir) : this;
            return new TaskFlowExecution(CommandLine.join(args), output, exitCode, nextSession);
        }

        public String currentField() {
            if (isFinished()) {
                return null;
            }
            if (taskId == null) {
                return "task";
            }
            if (actor == null) {
                return "actor";
            }
            if (time == null) {
                return "time";
            }
            return null;
        }

        private List<String> commandArgs(String commandTaskId, String commandActor, String commandTime) {
            return List.of(
                "task",
                action.commandName(),
                "--task",
                commandTaskId,
                "--root",
                rootDir.toString(),
                "--actor",
                commandActor,
                "--time",
                commandTime
            );
        }

        private static String renderOutput(ByteArrayOutputStream outBuffer, ByteArrayOutputStream errBuffer, int exitCode) {
            String output = outBuffer.toString(StandardCharsets.UTF_8);
            String error = errBuffer.toString(StandardCharsets.UTF_8);
            StringBuilder builder = new StringBuilder();
            if (!output.isBlank()) {
                builder.append(output.stripTrailing());
            }
            if (!error.isBlank()) {
                if (builder.length() > 0) {
                    builder.append(System.lineSeparator());
                }
                builder.append(error.stripTrailing());
            }
            if (builder.length() == 0) {
                builder.append("exitCode=").append(exitCode);
            } else if (exitCode != 0) {
                builder.append(System.lineSeparator()).append("exitCode=").append(exitCode);
            }
            return builder.toString();
        }

        private static String commandOption(String command, String option) {
            String[] tokens = CommandLine.tokenize(command);
            for (int i = 0; i < tokens.length - 1; i++) {
                if (option.equals(tokens[i])) {
                    return tokens[i + 1];
                }
            }
            return null;
        }

        private static String requireValue(String value) {
            String normalized = value == null ? "" : value.trim();
            if (normalized.isEmpty()) {
                throw new IllegalArgumentException("Task flow input must not be blank");
            }
            return normalized;
        }
    }

    public enum Action {
        CREATE("create", "Create Task"),
        START("start", "Start Task"),
        COMPLETE("complete", "Complete Task"),
        DONE("", "Done");

        private final String commandName;
        private final String promptTitle;

        Action(String commandName, String promptTitle) {
            this.commandName = commandName;
            this.promptTitle = promptTitle;
        }

        public String commandName() {
            return commandName;
        }

        public String promptTitle() {
            return promptTitle;
        }

        public static Action fromCommand(String command) {
            String[] tokens = CommandLine.tokenize(command);
            if (tokens.length < 2 || !"task".equals(tokens[0])) {
                return DONE;
            }
            return switch (tokens[1]) {
                case "create" -> CREATE;
                case "start" -> START;
                case "complete" -> COMPLETE;
                default -> DONE;
            };
        }
    }
}
