package kernel.apps.flow;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;

import kernel.apps.PlatformCli;
import kernel.apps.documentcli.DocumentCli;
import kernel.apps.support.CommandLine;

public final class DocumentFlow {
    private DocumentFlow() {
    }

    public static DocumentFlowSession begin(Path rootDir) throws Exception {
        Objects.requireNonNull(rootDir, "rootDir");
        return DocumentFlowSession.fromRoot(rootDir);
    }

    public record DocumentFlowPrompt(
        String title,
        String field,
        String instruction,
        String commandPreview
    ) {
    }

    public record DocumentFlowExecution(
        String command,
        String output,
        int exitCode,
        DocumentFlowSession nextSession
    ) {
    }

    public record DocumentFlowSession(
        Path rootDir,
        Action action,
        String documentId,
        String targetEventId,
        String reason,
        String actor,
        String time
    ) {
        public static DocumentFlowSession fromRoot(Path rootDir) throws Exception {
            for (String nextCommand : DocumentCli.nextCommands(rootDir)) {
                Action action = Action.fromCommand(nextCommand);
                if (action == Action.DONE) {
                    continue;
                }
                String parsedDocumentId = commandOption(nextCommand, "--document");
                if (parsedDocumentId != null && parsedDocumentId.startsWith("<") && parsedDocumentId.endsWith(">")) {
                    parsedDocumentId = null;
                }
                String parsedTargetEventId = commandOption(nextCommand, "--target-event");
                if (parsedTargetEventId != null && parsedTargetEventId.startsWith("<") && parsedTargetEventId.endsWith(">")) {
                    parsedTargetEventId = null;
                }
                String parsedReason = commandOption(nextCommand, "--reason");
                if (parsedReason != null && parsedReason.startsWith("<") && parsedReason.endsWith(">")) {
                    parsedReason = null;
                }
                return new DocumentFlowSession(rootDir, action, parsedDocumentId, parsedTargetEventId, parsedReason, null, null);
            }
            return new DocumentFlowSession(rootDir, Action.DONE, null, null, null, null, null);
        }

        public boolean isFinished() {
            return action == Action.DONE;
        }

        public boolean readyToExecute() {
            return !isFinished() && currentField() == null;
        }

        public DocumentFlowPrompt prompt() {
            if (isFinished()) {
                throw new IllegalStateException("Document flow is finished");
            }

            String field = currentField();
            return switch (field) {
                case "document" -> new DocumentFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter document id for the new root-scoped document.",
                    commandPreview()
                );
                case "reason" -> new DocumentFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter rejection reason for the linked submission.",
                    commandPreview()
                );
                case "actor" -> new DocumentFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter actor id for this command.",
                    commandPreview()
                );
                case "time" -> new DocumentFlowPrompt(
                    action.promptTitle(),
                    field,
                    "Enter event time as an integer.",
                    commandPreview()
                );
                default -> throw new IllegalStateException("No prompt is available when the command is ready to execute");
            };
        }

        public DocumentFlowSession answer(String value) {
            if (isFinished()) {
                throw new IllegalStateException("Document flow is finished");
            }

            String normalized = requireValue(value);
            String field = currentField();
            if (field == null) {
                throw new IllegalStateException("Command is ready to execute");
            }

            return switch (field) {
                case "document" -> new DocumentFlowSession(rootDir, action, normalized, targetEventId, reason, actor, time);
                case "reason" -> new DocumentFlowSession(rootDir, action, documentId, targetEventId, normalized, actor, time);
                case "actor" -> new DocumentFlowSession(rootDir, action, documentId, targetEventId, reason, normalized, time);
                case "time" -> {
                    Long.parseLong(normalized);
                    yield new DocumentFlowSession(rootDir, action, documentId, targetEventId, reason, actor, normalized);
                }
                default -> throw new IllegalStateException("Unknown document flow field: " + field);
            };
        }

        public String commandPreview() {
            if (isFinished()) {
                return "(no guided document action available)";
            }
            return CommandLine.join(commandArgs(
                documentId != null ? documentId : "<documentId>",
                targetEventId != null ? targetEventId : "<eventId>",
                reason != null ? reason : "<text>",
                actor != null ? actor : "<actor>",
                time != null ? time : "<time>"
            ));
        }

        public DocumentFlowExecution execute() throws Exception {
            if (!readyToExecute()) {
                throw new IllegalStateException("Document flow command is not ready to execute");
            }

            List<String> args = commandArgs(documentId, targetEventId, reason, actor, time);
            ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
            ByteArrayOutputStream errBuffer = new ByteArrayOutputStream();
            int exitCode = PlatformCli.run(
                args.toArray(String[]::new),
                new PrintStream(outBuffer, true, StandardCharsets.UTF_8),
                new PrintStream(errBuffer, true, StandardCharsets.UTF_8)
            );

            String output = renderOutput(outBuffer, errBuffer, exitCode);
            DocumentFlowSession nextSession = exitCode == 0 ? fromRoot(rootDir) : this;
            return new DocumentFlowExecution(CommandLine.join(args), output, exitCode, nextSession);
        }

        public String currentField() {
            if (isFinished()) {
                return null;
            }
            if (documentId == null) {
                return "document";
            }
            if (requiresReason() && reason == null) {
                return "reason";
            }
            if (actor == null) {
                return "actor";
            }
            if (time == null) {
                return "time";
            }
            return null;
        }

        private boolean requiresReason() {
            return action == Action.REJECT;
        }

        private List<String> commandArgs(
            String commandDocumentId,
            String commandTargetEventId,
            String commandReason,
            String commandActor,
            String commandTime
        ) {
            java.util.ArrayList<String> args = new java.util.ArrayList<>();
            args.add("document");
            args.add(action.commandName());
            args.add("--document");
            args.add(commandDocumentId);
            if (action == Action.REJECT) {
                args.add("--target-event");
                args.add(commandTargetEventId);
                args.add("--reason");
                args.add(commandReason);
            }
            args.add("--root");
            args.add(rootDir.toString());
            args.add("--actor");
            args.add(commandActor);
            args.add("--time");
            args.add(commandTime);
            return List.copyOf(args);
        }

        private static String renderOutput(ByteArrayOutputStream outBuffer, ByteArrayOutputStream errBuffer, int exitCode) {
            String output = outBuffer.toString(StandardCharsets.UTF_8);
            String error = errBuffer.toString(StandardCharsets.UTF_8);
            StringBuilder builder = new StringBuilder();
            if (!output.isBlank()) {
                builder.append(output.stripTrailing());
            }
            if (!error.isBlank()) {
                if (builder.length() > 0) {
                    builder.append(System.lineSeparator());
                }
                builder.append(error.stripTrailing());
            }
            if (builder.length() == 0) {
                builder.append("exitCode=").append(exitCode);
            } else if (exitCode != 0) {
                builder.append(System.lineSeparator()).append("exitCode=").append(exitCode);
            }
            return builder.toString();
        }

        private static String commandOption(String command, String option) {
            String[] tokens = CommandLine.tokenize(command);
            for (int i = 0; i < tokens.length - 1; i++) {
                if (option.equals(tokens[i])) {
                    return tokens[i + 1];
                }
            }
            return null;
        }

        private static String requireValue(String value) {
            String normalized = value == null ? "" : value.trim();
            if (normalized.isEmpty()) {
                throw new IllegalArgumentException("Document flow input must not be blank");
            }
            return normalized;
        }
    }

    public enum Action {
        DRAFT("draft", "Draft Document"),
        SUBMIT("submit", "Submit Document"),
        REJECT("reject", "Reject Document"),
        DONE("", "Done");

        private final String commandName;
        private final String promptTitle;

        Action(String commandName, String promptTitle) {
            this.commandName = commandName;
            this.promptTitle = promptTitle;
        }

        public String commandName() {
            return commandName;
        }

        public String promptTitle() {
            return promptTitle;
        }

        public static Action fromCommand(String command) {
            String[] tokens = CommandLine.tokenize(command);
            if (tokens.length < 2 || !"document".equals(tokens[0])) {
                return DONE;
            }
            return switch (tokens[1]) {
                case "draft" -> DRAFT;
                case "submit" -> SUBMIT;
                case "reject" -> REJECT;
                default -> DONE;
            };
        }
    }
}
