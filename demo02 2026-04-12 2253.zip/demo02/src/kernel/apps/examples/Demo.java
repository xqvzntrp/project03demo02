package kernel.apps.examples;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import kernel.apps.support.SampleChain;
import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.EventProperties;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.StoredEvent;
import kernel.core.VerifiedEvent;
import kernel.core.VerifiedReplayChain;

public final class Demo {
    private Demo() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Path.of("build");
        Files.createDirectories(rootDir);
        SampleChain.SampleData sampleData = SampleChain.create(rootDir);

        String firstHash = EventCodec.eventHash(sampleData.firstEvent());
        String repeatedHash = EventCodec.eventHash(sampleData.firstEvent());
        if (!firstHash.equals(repeatedHash)) {
            throw new IllegalStateException("Hash generation is not deterministic");
        }

        StoredEvent storedEvent = EventProperties.read(sampleData.eventDir().resolve(sampleData.secondHash() + ".properties"));
        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(sampleData.eventDir(), sampleData.payloadDir());
        List<VerifiedEvent> verifiedEvents = replayChain.stream().toList();
        ReplayRun replayRun = new Replayer().replay(replayChain, new Replayer.CountingLaw("law-v1"));

        System.out.println("eventHash=" + storedEvent.eventHash());
        System.out.println("payloadHash=" + sampleData.secondEvent().payloadHash());
        System.out.println("path=" + sampleData.eventDir().resolve(sampleData.secondHash() + ".properties"));
        System.out.println("chainVerified=true");
        System.out.println("payloadsVerified=true");
        System.out.println("verifiedEventCount=" + verifiedEvents.size());
        System.out.println("replayInputTrusted=true");
        System.out.println("replayedEventCount=" + replayRun.finalState().eventCount());
        System.out.println("replayTotalPayloadBytes=" + replayRun.finalState().totalPayloadBytes());
        System.out.println("replayLawVersion=" + replayRun.lawVersion());
        System.out.println("replayLastEventId=" + replayRun.finalState().lastEventId());
        System.out.println("derivedOutputCount=" + replayRun.outputs().size());
    }
}
