package kernel.apps.examples;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.apps.flow.TaskFlow;

public final class TaskFlowDemo {
    private TaskFlowDemo() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-flow-demo-");
        TaskFlow.TaskFlowSession session = TaskFlow.begin(rootDir);

        session = run(session, "task-100", "alice", "1");
        session = run(session, "bob", "2");
        session = run(session, "carol", "3");

        System.out.println("taskFlowDemoPassed=true");
        System.out.println("rootDir=" + rootDir);
    }

    private static TaskFlow.TaskFlowSession run(TaskFlow.TaskFlowSession session, String... answers) throws Exception {
        System.out.println(session.prompt().title());
        System.out.println("preview: " + session.commandPreview());
        for (String answer : answers) {
            System.out.println("input " + session.currentField() + ": " + answer);
            session = session.answer(answer);
            System.out.println("preview: " + session.commandPreview());
        }
        TaskFlow.TaskFlowExecution execution = session.execute();
        System.out.println("run: " + execution.command());
        System.out.println(execution.output());
        System.out.println();
        return execution.nextSession();
    }
}
