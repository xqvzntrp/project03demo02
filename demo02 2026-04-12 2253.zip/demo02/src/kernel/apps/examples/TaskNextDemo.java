package kernel.apps.examples;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import kernel.apps.PlatformCli;

public final class TaskNextDemo {
    private TaskNextDemo() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Files.createTempDirectory("task-next-demo-");

        run(rootDir, "task", "next");
        run(rootDir, "task", "create", "--task", "task-100", "--actor", "alice", "--time", "1");
        run(rootDir, "task", "next");
        run(rootDir, "task", "start", "--task", "task-100", "--actor", "alice", "--time", "2");
        run(rootDir, "task", "next");
        run(rootDir, "task", "complete", "--task", "task-100", "--actor", "alice", "--time", "3");
        run(rootDir, "task", "next");
        run(
            rootDir,
            "task",
            "correct",
            "--task",
            "task-100",
            "--target-event",
            "task-evt-000003",
            "--reason",
            "mistaken completion",
            "--actor",
            "alice",
            "--time",
            "4"
        );
        run(rootDir, "task", "show");

        System.out.println("taskNextDemoPassed=true");
        System.out.println("rootDir=" + rootDir);
    }

    private static void run(Path rootDir, String... args) {
        List<String> effectiveArgs = new ArrayList<>(List.of(args));
        effectiveArgs.add("--root");
        effectiveArgs.add(rootDir.toString());

        ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
        ByteArrayOutputStream errBuffer = new ByteArrayOutputStream();
        int exitCode = PlatformCli.run(
            effectiveArgs.toArray(String[]::new),
            new PrintStream(outBuffer, true, StandardCharsets.UTF_8),
            new PrintStream(errBuffer, true, StandardCharsets.UTF_8)
        );

        String output = outBuffer.toString(StandardCharsets.UTF_8);
        String error = errBuffer.toString(StandardCharsets.UTF_8);
        if (exitCode != 0) {
            throw new IllegalStateException("Command failed: " + String.join(" ", args) + System.lineSeparator() + error);
        }

        System.out.println("> " + String.join(" ", args));
        if (!output.isBlank()) {
            System.out.print(output);
            if (!output.endsWith(System.lineSeparator())) {
                System.out.println();
            }
        }
        System.out.println();
    }
}
