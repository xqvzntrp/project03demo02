package kernel.apps.examples;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.VerifiedReplayChain;
import kernel.laws.task.TaskEventWriter;
import kernel.laws.task.TaskLaw;
import kernel.laws.task.TaskStateView;

public final class TaskLawDemo {
    private TaskLawDemo() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Path.of("build", "task-law-demo");
        Path eventDir = rootDir.resolve("events");
        Path payloadDir = rootDir.resolve("payloads");
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);

        String lawVersion = "task-law-v1";
        TaskEventWriter.WrittenTaskEvent created = TaskEventWriter.write(
            eventDir,
            payloadDir,
            "task-evt-0001",
            "TaskCreated",
            EventCodec.INITIAL_POINTER_SENTINEL,
            "task-001",
            lawVersion,
            "actor-01",
            1L
        );
        TaskEventWriter.WrittenTaskEvent started = TaskEventWriter.write(
            eventDir,
            payloadDir,
            "task-evt-0002",
            "TaskStarted",
            created.eventHash(),
            "task-001",
            lawVersion,
            "actor-01",
            2L
        );
        TaskEventWriter.WrittenTaskEvent completed = TaskEventWriter.write(
            eventDir,
            payloadDir,
            "task-evt-0003",
            "TaskCompleted",
            started.eventHash(),
            "task-001",
            lawVersion,
            "actor-01",
            3L
        );

        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(eventDir, payloadDir);
        ReplayRun replayRun = new Replayer().replay(replayChain, new TaskLaw(lawVersion));
        TaskStateView finalTask = TaskStateView.from(replayRun.finalState());

        System.out.println("taskLawDemoPassed=true");
        System.out.println("finalTaskId=" + finalTask.taskId());
        System.out.println("finalTaskStatus=" + finalTask.status());
        System.out.println("derivedOutputCount=" + replayRun.outputs().size());
        System.out.println("lastEventHash=" + completed.eventHash());
    }
}
