package kernel.apps.examples;

import java.nio.file.Files;
import java.nio.file.Path;

import kernel.core.ChainVerifier;
import kernel.core.EventCodec;
import kernel.core.ReplayRun;
import kernel.core.Replayer;
import kernel.core.VerifiedReplayChain;
import kernel.laws.account.AccountEventWriter;
import kernel.laws.account.AccountLaw;
import kernel.laws.account.AccountStateView;

public final class AccountLawDemo {
    private AccountLawDemo() {
    }

    public static void main(String[] args) throws Exception {
        Path rootDir = Path.of("build", "account-law-demo");
        Path eventDir = rootDir.resolve("events");
        Path payloadDir = rootDir.resolve("payloads");
        Files.createDirectories(eventDir);
        Files.createDirectories(payloadDir);

        String lawVersion = "account-law-v1";
        AccountEventWriter.WrittenAccountEvent opened = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0001",
            "AccountOpened",
            EventCodec.INITIAL_POINTER_SENTINEL,
            "acct-001",
            0L,
            lawVersion,
            "actor-01",
            1L
        );
        AccountEventWriter.WrittenAccountEvent deposited = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0002",
            "FundsDeposited",
            opened.eventHash(),
            "acct-001",
            100L,
            lawVersion,
            "actor-01",
            2L
        );
        AccountEventWriter.WrittenAccountEvent withdrawn = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0003",
            "FundsWithdrawn",
            deposited.eventHash(),
            "acct-001",
            30L,
            lawVersion,
            "actor-01",
            3L
        );
        AccountEventWriter.WrittenAccountEvent closed = AccountEventWriter.write(
            eventDir,
            payloadDir,
            "acct-evt-0004",
            "AccountClosed",
            withdrawn.eventHash(),
            "acct-001",
            0L,
            lawVersion,
            "actor-01",
            4L
        );

        VerifiedReplayChain replayChain = ChainVerifier.verifiedReplayChain(eventDir, payloadDir);
        ReplayRun replayRun = new Replayer().replay(replayChain, new AccountLaw(lawVersion));
        AccountStateView finalAccount = AccountStateView.from(replayRun.finalState());

        System.out.println("accountLawDemoPassed=true");
        System.out.println("finalAccountId=" + finalAccount.accountId());
        System.out.println("finalAccountStatus=" + finalAccount.status());
        System.out.println("finalBalance=" + finalAccount.balance());
        System.out.println("derivedOutputCount=" + replayRun.outputs().size());
        System.out.println("lastEventHash=" + closed.eventHash());
    }
}
