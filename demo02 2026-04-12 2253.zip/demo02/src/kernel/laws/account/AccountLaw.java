package kernel.laws.account;

import java.util.List;

import kernel.core.DerivedOutput;
import kernel.core.Law;
import kernel.core.ReplayResult;
import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;

public final class AccountLaw implements Law {
    private final String version;

    public AccountLaw(String version) {
        this.version = version;
    }

    @Override
    public String version() {
        return version;
    }

    @Override
    public ReplayResult apply(ReplayState state, VerifiedEvent event) {
        AccountPayload payload = AccountPayload.fromBytes(event.payloadBytes());
        AccountStateView current = AccountStateView.from(state);

        return switch (event.eventType()) {
            case "AccountOpened" -> applyOpened(state, current, payload, event);
            case "FundsDeposited" -> applyDeposit(state, current, payload, event);
            case "FundsWithdrawn" -> applyWithdraw(state, current, payload, event);
            case "AccountClosed" -> applyClosed(state, current, payload, event);
            default -> throw new IllegalStateException("Unsupported account eventType: " + event.eventType());
        };
    }

    private ReplayResult applyOpened(ReplayState state, AccountStateView current, AccountPayload payload, VerifiedEvent event) {
        if (current.exists()) {
            throw new IllegalStateException("AccountOpened is only valid for an empty lifecycle");
        }
        if (payload.amount() != 0L) {
            throw new IllegalStateException("AccountOpened must initialize with zero amount");
        }
        ReplayState nextState = current.next(payload.accountId(), AccountStatus.OPEN, 0L, event, state);
        return new ReplayResult(nextState, List.of(accountOutput("account-opened", event, payload.accountId(), "0")));
    }

    private ReplayResult applyDeposit(ReplayState state, AccountStateView current, AccountPayload payload, VerifiedEvent event) {
        requireOpenAccount(current, payload, event);
        requirePositiveAmount(payload.amount(), event);
        long nextBalance = current.balance() + payload.amount();
        ReplayState nextState = current.next(payload.accountId(), AccountStatus.OPEN, nextBalance, event, state);
        return new ReplayResult(nextState, List.of(accountOutput("funds-deposited", event, payload.accountId(), Long.toString(nextBalance))));
    }

    private ReplayResult applyWithdraw(ReplayState state, AccountStateView current, AccountPayload payload, VerifiedEvent event) {
        requireOpenAccount(current, payload, event);
        requirePositiveAmount(payload.amount(), event);

        if (payload.amount() > current.balance()) {
            ReplayState nextState = current.next(payload.accountId(), AccountStatus.OPEN, current.balance(), event, state);
            DerivedOutput output = accountOutput(
                "overdraft-attempted",
                event,
                payload.accountId(),
                Long.toString(current.balance())
            );
            return new ReplayResult(nextState, List.of(output));
        }

        long nextBalance = current.balance() - payload.amount();
        ReplayState nextState = current.next(payload.accountId(), AccountStatus.OPEN, nextBalance, event, state);
        return new ReplayResult(nextState, List.of(accountOutput("funds-withdrawn", event, payload.accountId(), Long.toString(nextBalance))));
    }

    private ReplayResult applyClosed(ReplayState state, AccountStateView current, AccountPayload payload, VerifiedEvent event) {
        requireOpenAccount(current, payload, event);
        if (payload.amount() != 0L) {
            throw new IllegalStateException("AccountClosed must not carry a non-zero amount");
        }
        ReplayState nextState = current.next(payload.accountId(), AccountStatus.CLOSED, current.balance(), event, state);
        return new ReplayResult(nextState, List.of(accountOutput("account-closed", event, payload.accountId(), Long.toString(current.balance()))));
    }

    private void requireOpenAccount(AccountStateView current, AccountPayload payload, VerifiedEvent event) {
        if (!current.exists()) {
            throw new IllegalStateException("Account lifecycle has not been opened");
        }
        if (!current.accountId().equals(payload.accountId())) {
            throw new IllegalStateException(
                "Account payload accountId " + payload.accountId() + " does not match lifecycle accountId " + current.accountId()
            );
        }
        if (current.status() != AccountStatus.OPEN) {
            throw new IllegalStateException(
                event.eventType() + " is invalid from status " + current.status() + " for eventId " + event.eventId()
            );
        }
    }

    private void requirePositiveAmount(long amount, VerifiedEvent event) {
        if (amount <= 0L) {
            throw new IllegalStateException(event.eventType() + " requires a positive amount for eventId " + event.eventId());
        }
    }

    private DerivedOutput accountOutput(String kind, VerifiedEvent event, String accountId, String value) {
        return new DerivedOutput(kind, event.eventId(), accountId + "|" + value);
    }
}
