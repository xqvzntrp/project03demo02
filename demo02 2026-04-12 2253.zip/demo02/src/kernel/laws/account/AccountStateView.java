package kernel.laws.account;

import java.util.ArrayList;
import java.util.List;

import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;

public record AccountStateView(
    String accountId,
    AccountStatus status,
    long balance,
    List<String> eventIds
) {
    private static final String PREFIX = "ACCOUNT_STATE:";

    public static AccountStateView from(ReplayState state) {
        if (state.eventCount() == 0) {
            return new AccountStateView(null, null, 0L, List.of());
        }
        if (state.appliedEventIds().isEmpty()) {
            throw new IllegalStateException("ReplayState is missing account state marker");
        }

        String marker = state.appliedEventIds().getFirst();
        if (!marker.startsWith(PREFIX)) {
            throw new IllegalStateException("ReplayState marker is invalid: " + marker);
        }

        String[] parts = marker.substring(PREFIX.length()).split("\\|", -1);
        if (parts.length != 3 || parts[0].isEmpty() || parts[1].isEmpty()) {
            throw new IllegalStateException("ReplayState marker is malformed: " + marker);
        }

        List<String> eventIds = List.copyOf(state.appliedEventIds().subList(1, state.appliedEventIds().size()));
        return new AccountStateView(parts[0], AccountStatus.valueOf(parts[1]), Long.parseLong(parts[2]), eventIds);
    }

    boolean exists() {
        return accountId != null;
    }

    ReplayState next(String accountId, AccountStatus status, long balance, VerifiedEvent event, ReplayState priorState) {
        List<String> nextEntries = new ArrayList<>();
        nextEntries.add(PREFIX + accountId + "|" + status.name() + "|" + balance);
        nextEntries.addAll(eventIds);
        nextEntries.add(event.eventId());
        return new ReplayState(
            nextEntries,
            priorState.eventCount() + 1,
            priorState.totalPayloadBytes() + event.payloadBytes().length,
            event.eventId()
        );
    }
}
