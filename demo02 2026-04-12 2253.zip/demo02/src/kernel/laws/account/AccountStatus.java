package kernel.laws.account;

public enum AccountStatus {
    OPEN,
    CLOSED
}
