package kernel.laws.account;

import java.io.IOException;
import java.nio.file.Path;

import kernel.core.Event;
import kernel.core.EventCodec;
import kernel.core.EventProperties;
import kernel.core.PayloadCas;

public final class AccountEventWriter {
    private AccountEventWriter() {
    }

    public static WrittenAccountEvent write(
        Path eventDir,
        Path payloadDir,
        String eventId,
        String eventType,
        String previousHash,
        String accountId,
        long amount,
        String lawVersion,
        String actorId,
        long timeValue
    ) throws IOException {
        byte[] payloadBytes = new AccountPayload(accountId, amount).toBytes();
        String payloadHash = PayloadCas.store(payloadDir, payloadBytes);
        Event event = new Event(eventId, eventType, previousHash, payloadHash, lawVersion, actorId, timeValue);
        String eventHash = EventCodec.eventHash(event);
        EventProperties.write(eventDir.resolve(eventHash + ".properties"), event);
        return new WrittenAccountEvent(event, eventHash);
    }

    public record WrittenAccountEvent(Event event, String eventHash) {
    }
}
