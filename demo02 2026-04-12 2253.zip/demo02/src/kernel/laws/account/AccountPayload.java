package kernel.laws.account;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

record AccountPayload(String accountId, long amount) {
    static AccountPayload fromBytes(byte[] payloadBytes) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(payloadBytes), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse account payload", e);
        }

        String accountId = properties.getProperty("accountId");
        if (accountId == null || accountId.isEmpty()) {
            throw new IllegalStateException("Account payload is missing required accountId");
        }

        String amountValue = properties.getProperty("amount", "0");
        long amount = Long.parseLong(amountValue);
        return new AccountPayload(accountId, amount);
    }

    byte[] toBytes() {
        StringBuilder builder = new StringBuilder();
        builder.append("accountId=").append(escape(accountId)).append('\n');
        builder.append("amount=").append(amount).append('\n');
        return builder.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static String escape(String value) {
        StringBuilder escaped = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            switch (ch) {
                case '\\':
                    escaped.append("\\\\");
                    break;
                case '\n':
                    escaped.append("\\n");
                    break;
                case '\r':
                    escaped.append("\\r");
                    break;
                case '\t':
                    escaped.append("\\t");
                    break;
                case '=':
                case ':':
                case '#':
                case '!':
                    escaped.append('\\').append(ch);
                    break;
                default:
                    escaped.append(ch);
                    break;
            }
        }
        return escaped.toString();
    }
}
