package kernel.laws.document;

import java.util.List;

import kernel.core.DerivedOutput;
import kernel.core.Law;
import kernel.core.ReplayResult;
import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;

public final class DocumentLaw implements Law {
    private final String version;

    public DocumentLaw(String version) {
        this.version = version;
    }

    @Override
    public String version() {
        return version;
    }

    @Override
    public ReplayResult apply(ReplayState state, VerifiedEvent event) {
        DocumentPayload payload = DocumentPayload.fromBytes(event.payloadBytes());
        DocumentStateView current = DocumentStateView.from(state);

        return switch (event.eventType()) {
            case "DocumentDrafted" -> applyDrafted(state, current, payload, event);
            case "DocumentSubmitted" -> applySubmitted(state, current, payload, event);
            case "DocumentRejected" -> applyRejected(state, current, payload, event);
            case "DocumentRevised" -> applyRevised(state, current, payload, event);
            case "DocumentApproved" -> applyApproved(state, current, payload, event);
            default -> throw new IllegalStateException("Unsupported document eventType: " + event.eventType());
        };
    }

    private ReplayResult applyDrafted(ReplayState state, DocumentStateView current, DocumentPayload payload, VerifiedEvent event) {
        if (current.exists()) {
            throw new IllegalStateException("DocumentDrafted is only valid for an empty lifecycle");
        }
        ReplayState nextState = current.next(
            payload.documentId(),
            DocumentStatus.DRAFT,
            1,
            event.eventId(),
            null,
            null,
            null,
            event,
            state
        );
        return new ReplayResult(nextState, List.of(documentOutput("document-drafted", event, payload.documentId(), "v1")));
    }

    private ReplayResult applySubmitted(ReplayState state, DocumentStateView current, DocumentPayload payload, VerifiedEvent event) {
        requireExistingDocument(current, payload);
        requireStatus(current, DocumentStatus.DRAFT, event);
        ReplayState nextState = current.next(
            payload.documentId(),
            DocumentStatus.IN_REVIEW,
            current.currentRevision(),
            event.eventId(),
            event.eventId(),
            current.lastRejectionEventId(),
            current.lastRejectionReason(),
            event,
            state
        );
        return new ReplayResult(
            nextState,
            List.of(documentOutput("document-submitted", event, payload.documentId(), "v" + current.currentRevision()))
        );
    }

    private ReplayResult applyRejected(ReplayState state, DocumentStateView current, DocumentPayload payload, VerifiedEvent event) {
        requireExistingDocument(current, payload);
        requireStatus(current, DocumentStatus.IN_REVIEW, event);
        if (payload.targetEventId() == null || payload.reason() == null) {
            throw new IllegalStateException("DocumentRejected requires targetEventId and reason");
        }
        if (!payload.targetEventId().equals(current.lastSubmissionEventId())) {
            throw new IllegalStateException(
                "DocumentRejected target " + payload.targetEventId()
                    + " does not match last submission event " + current.lastSubmissionEventId()
            );
        }
        ReplayState nextState = current.next(
            payload.documentId(),
            DocumentStatus.CHANGES_REQUESTED,
            current.currentRevision(),
            event.eventId(),
            current.lastSubmissionEventId(),
            event.eventId(),
            payload.reason(),
            event,
            state
        );
        return new ReplayResult(
            nextState,
            List.of(documentOutput("document-rejected", event, payload.documentId(), payload.targetEventId() + "|" + payload.reason()))
        );
    }

    private ReplayResult applyRevised(ReplayState state, DocumentStateView current, DocumentPayload payload, VerifiedEvent event) {
        requireExistingDocument(current, payload);
        requireStatus(current, DocumentStatus.CHANGES_REQUESTED, event);
        int nextRevision = current.currentRevision() + 1;
        ReplayState nextState = current.next(
            payload.documentId(),
            DocumentStatus.DRAFT,
            nextRevision,
            event.eventId(),
            current.lastSubmissionEventId(),
            current.lastRejectionEventId(),
            current.lastRejectionReason(),
            event,
            state
        );
        return new ReplayResult(
            nextState,
            List.of(documentOutput("document-revised", event, payload.documentId(), "v" + nextRevision))
        );
    }

    private ReplayResult applyApproved(ReplayState state, DocumentStateView current, DocumentPayload payload, VerifiedEvent event) {
        requireExistingDocument(current, payload);
        requireStatus(current, DocumentStatus.IN_REVIEW, event);
        ReplayState nextState = current.next(
            payload.documentId(),
            DocumentStatus.APPROVED,
            current.currentRevision(),
            event.eventId(),
            current.lastSubmissionEventId(),
            current.lastRejectionEventId(),
            current.lastRejectionReason(),
            event,
            state
        );
        return new ReplayResult(
            nextState,
            List.of(documentOutput("document-approved", event, payload.documentId(), "v" + current.currentRevision()))
        );
    }

    private void requireExistingDocument(DocumentStateView current, DocumentPayload payload) {
        if (!current.exists()) {
            throw new IllegalStateException("Document lifecycle has not been drafted");
        }
        if (!current.documentId().equals(payload.documentId())) {
            throw new IllegalStateException(
                "Document payload documentId " + payload.documentId()
                    + " does not match lifecycle documentId " + current.documentId()
            );
        }
    }

    private void requireStatus(DocumentStateView current, DocumentStatus expected, VerifiedEvent event) {
        if (current.status() != expected) {
            throw new IllegalStateException(
                event.eventType() + " is invalid from status " + current.status() + " for eventId " + event.eventId()
            );
        }
    }

    private DerivedOutput documentOutput(String kind, VerifiedEvent event, String documentId, String value) {
        return new DerivedOutput(kind, event.eventId(), documentId + "|" + value);
    }
}
