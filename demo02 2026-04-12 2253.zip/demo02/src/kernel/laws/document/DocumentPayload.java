package kernel.laws.document;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

record DocumentPayload(String documentId, String targetEventId, String reason) {
    static DocumentPayload fromBytes(byte[] payloadBytes) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(payloadBytes), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse document payload", e);
        }

        String documentId = properties.getProperty("documentId");
        if (documentId == null || documentId.isEmpty()) {
            throw new IllegalStateException("Document payload is missing required documentId");
        }

        return new DocumentPayload(
            documentId,
            emptyToNull(properties.getProperty("targetEventId")),
            emptyToNull(properties.getProperty("reason"))
        );
    }

    byte[] toBytes() {
        StringWriter writer = new StringWriter();
        writer.write("documentId=");
        writer.write(escape(documentId));
        writer.write('\n');
        if (targetEventId != null) {
            writer.write("targetEventId=");
            writer.write(escape(targetEventId));
            writer.write('\n');
        }
        if (reason != null) {
            writer.write("reason=");
            writer.write(escape(reason));
            writer.write('\n');
        }
        return writer.toString().getBytes(StandardCharsets.UTF_8);
    }

    static DocumentPayload simple(String documentId) {
        return new DocumentPayload(documentId, null, null);
    }

    static DocumentPayload rejection(String documentId, String targetEventId, String reason) {
        if (targetEventId == null || targetEventId.isEmpty()) {
            throw new IllegalArgumentException("Rejection payload requires targetEventId");
        }
        if (reason == null || reason.isEmpty()) {
            throw new IllegalArgumentException("Rejection payload requires reason");
        }
        return new DocumentPayload(documentId, targetEventId, reason);
    }

    private static String emptyToNull(String value) {
        return value == null || value.isEmpty() ? null : value;
    }

    private static String escape(String value) {
        StringBuilder escaped = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            switch (ch) {
                case '\\':
                    escaped.append("\\\\");
                    break;
                case '\n':
                    escaped.append("\\n");
                    break;
                case '\r':
                    escaped.append("\\r");
                    break;
                case '\t':
                    escaped.append("\\t");
                    break;
                case '=':
                case ':':
                case '#':
                case '!':
                    escaped.append('\\').append(ch);
                    break;
                default:
                    escaped.append(ch);
                    break;
            }
        }
        return escaped.toString();
    }
}
