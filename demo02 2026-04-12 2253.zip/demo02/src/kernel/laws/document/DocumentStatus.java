package kernel.laws.document;

public enum DocumentStatus {
    DRAFT,
    IN_REVIEW,
    CHANGES_REQUESTED,
    APPROVED
}
