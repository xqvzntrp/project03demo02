package kernel.laws.document;

import java.io.IOException;
import java.nio.file.Path;

import kernel.core.Event;
import kernel.core.EventCodec;
import kernel.core.EventProperties;
import kernel.core.PayloadCas;

public final class DocumentEventWriter {
    private DocumentEventWriter() {
    }

    public static WrittenDocumentEvent write(
        Path eventDir,
        Path payloadDir,
        String eventId,
        String eventType,
        String previousHash,
        String documentId,
        String lawVersion,
        String actorId,
        long timeValue
    ) throws IOException {
        byte[] payloadBytes = DocumentPayload.simple(documentId).toBytes();
        String payloadHash = PayloadCas.store(payloadDir, payloadBytes);
        Event event = new Event(eventId, eventType, previousHash, payloadHash, lawVersion, actorId, timeValue);
        String eventHash = EventCodec.eventHash(event);
        EventProperties.write(eventDir.resolve(eventHash + ".properties"), event);
        return new WrittenDocumentEvent(event, eventHash);
    }

    public static WrittenDocumentEvent writeRejection(
        Path eventDir,
        Path payloadDir,
        String eventId,
        String previousHash,
        String documentId,
        String targetEventId,
        String reason,
        String lawVersion,
        String actorId,
        long timeValue
    ) throws IOException {
        byte[] payloadBytes = DocumentPayload.rejection(documentId, targetEventId, reason).toBytes();
        String payloadHash = PayloadCas.store(payloadDir, payloadBytes);
        Event event = new Event(eventId, "DocumentRejected", previousHash, payloadHash, lawVersion, actorId, timeValue);
        String eventHash = EventCodec.eventHash(event);
        EventProperties.write(eventDir.resolve(eventHash + ".properties"), event);
        return new WrittenDocumentEvent(event, eventHash);
    }

    public record WrittenDocumentEvent(Event event, String eventHash) {
    }
}
