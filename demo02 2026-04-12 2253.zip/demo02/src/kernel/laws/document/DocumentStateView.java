package kernel.laws.document;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;

public record DocumentStateView(
    String documentId,
    DocumentStatus status,
    int currentRevision,
    String lastStateEventId,
    String lastSubmissionEventId,
    String lastRejectionEventId,
    String lastRejectionReason,
    List<String> eventIds
) {
    private static final String PREFIX = "DOCUMENT_STATE:";

    public static DocumentStateView from(ReplayState state) {
        if (state.eventCount() == 0) {
            return new DocumentStateView(null, null, 0, null, null, null, null, List.of());
        }
        if (state.appliedEventIds().isEmpty()) {
            throw new IllegalStateException("ReplayState is missing document state marker");
        }

        String marker = state.appliedEventIds().getFirst();
        if (!marker.startsWith(PREFIX)) {
            throw new IllegalStateException("ReplayState marker is invalid: " + marker);
        }

        String[] parts = marker.substring(PREFIX.length()).split("\\|", -1);
        if (parts.length != 7 || parts[0].isEmpty() || parts[1].isEmpty() || parts[2].isEmpty()) {
            throw new IllegalStateException("ReplayState marker is malformed: " + marker);
        }

        List<String> eventIds = List.copyOf(state.appliedEventIds().subList(1, state.appliedEventIds().size()));
        return new DocumentStateView(
            decode(parts[0]),
            DocumentStatus.valueOf(parts[1]),
            Integer.parseInt(parts[2]),
            decodeNullable(parts[3]),
            decodeNullable(parts[4]),
            decodeNullable(parts[5]),
            decodeNullable(parts[6]),
            eventIds
        );
    }

    public boolean exists() {
        return documentId != null;
    }

    public ReplayState next(
        String documentId,
        DocumentStatus status,
        int currentRevision,
        String lastStateEventId,
        String lastSubmissionEventId,
        String lastRejectionEventId,
        String lastRejectionReason,
        VerifiedEvent event,
        ReplayState priorState
    ) {
        List<String> nextEntries = new ArrayList<>();
        nextEntries.add(
            PREFIX
                + encode(documentId) + "|"
                + status.name() + "|"
                + currentRevision + "|"
                + encodeNullable(lastStateEventId) + "|"
                + encodeNullable(lastSubmissionEventId) + "|"
                + encodeNullable(lastRejectionEventId) + "|"
                + encodeNullable(lastRejectionReason)
        );
        nextEntries.addAll(eventIds);
        nextEntries.add(event.eventId());
        return new ReplayState(
            nextEntries,
            priorState.eventCount() + 1,
            priorState.totalPayloadBytes() + event.payloadBytes().length,
            event.eventId()
        );
    }

    private static String encode(String value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String encodeNullable(String value) {
        return value == null ? "" : encode(value);
    }

    private static String decode(String value) {
        return new String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8);
    }

    private static String decodeNullable(String value) {
        return value == null || value.isEmpty() ? null : decode(value);
    }
}
