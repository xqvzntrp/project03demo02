package kernel.laws.task;

import java.io.IOException;
import java.nio.file.Path;

import kernel.core.Event;
import kernel.core.EventCodec;
import kernel.core.EventProperties;
import kernel.core.PayloadCas;

public final class TaskEventWriter {
    private TaskEventWriter() {
    }

    public static WrittenTaskEvent write(
        Path eventDir,
        Path payloadDir,
        String eventId,
        String eventType,
        String previousHash,
        String taskId,
        String lawVersion,
        String actorId,
        long timeValue
    ) throws IOException {
        byte[] payloadBytes = TaskPayload.simple(taskId).toBytes();
        String payloadHash = PayloadCas.store(payloadDir, payloadBytes);
        Event event = new Event(eventId, eventType, previousHash, payloadHash, lawVersion, actorId, timeValue);
        String eventHash = EventCodec.eventHash(event);
        EventProperties.write(eventDir.resolve(eventHash + ".properties"), event);
        return new WrittenTaskEvent(event, eventHash);
    }

    public static WrittenTaskEvent writeCorrection(
        Path eventDir,
        Path payloadDir,
        String eventId,
        String previousHash,
        String taskId,
        String targetEventId,
        String reason,
        String lawVersion,
        String actorId,
        long timeValue
    ) throws IOException {
        byte[] payloadBytes = TaskPayload.correction(taskId, targetEventId, reason).toBytes();
        String payloadHash = PayloadCas.store(payloadDir, payloadBytes);
        Event event = new Event(eventId, "TaskCorrected", previousHash, payloadHash, lawVersion, actorId, timeValue);
        String eventHash = EventCodec.eventHash(event);
        EventProperties.write(eventDir.resolve(eventHash + ".properties"), event);
        return new WrittenTaskEvent(event, eventHash);
    }

    public record WrittenTaskEvent(Event event, String eventHash) {
    }
}
