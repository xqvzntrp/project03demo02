package kernel.laws.task;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

record TaskPayload(String taskId, String targetEventId, String reason) {
    static TaskPayload fromBytes(byte[] payloadBytes) {
        Properties properties = new Properties();
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(payloadBytes), StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to parse task payload", e);
        }
        String taskId = properties.getProperty("taskId");
        if (taskId == null || taskId.isEmpty()) {
            throw new IllegalStateException("Task payload is missing required taskId");
        }
        return new TaskPayload(taskId, emptyToNull(properties.getProperty("targetEventId")), emptyToNull(properties.getProperty("reason")));
    }

    byte[] toBytes() {
        StringWriter writer = new StringWriter();
        writer.write("taskId=");
        writer.write(escape(taskId));
        writer.write('\n');
        if (targetEventId != null) {
            writer.write("targetEventId=");
            writer.write(escape(targetEventId));
            writer.write('\n');
        }
        if (reason != null) {
            writer.write("reason=");
            writer.write(escape(reason));
            writer.write('\n');
        }
        return writer.toString().getBytes(StandardCharsets.UTF_8);
    }

    static TaskPayload simple(String taskId) {
        return new TaskPayload(taskId, null, null);
    }

    static TaskPayload correction(String taskId, String targetEventId, String reason) {
        if (targetEventId == null || targetEventId.isEmpty()) {
            throw new IllegalArgumentException("Correction payload requires targetEventId");
        }
        if (reason == null || reason.isEmpty()) {
            throw new IllegalArgumentException("Correction payload requires reason");
        }
        return new TaskPayload(taskId, targetEventId, reason);
    }

    private static String emptyToNull(String value) {
        return value == null || value.isEmpty() ? null : value;
    }

    private static String escape(String value) {
        StringBuilder escaped = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            switch (ch) {
                case '\\':
                    escaped.append("\\\\");
                    break;
                case '\n':
                    escaped.append("\\n");
                    break;
                case '\r':
                    escaped.append("\\r");
                    break;
                case '\t':
                    escaped.append("\\t");
                    break;
                case '=':
                case ':':
                case '#':
                case '!':
                    escaped.append('\\').append(ch);
                    break;
                default:
                    escaped.append(ch);
                    break;
            }
        }
        return escaped.toString();
    }
}
