package kernel.laws.task;

import java.util.List;

import kernel.core.DerivedOutput;
import kernel.core.Law;
import kernel.core.ReplayResult;
import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;

public final class TaskLaw implements Law {
    private final String version;

    public TaskLaw(String version) {
        this.version = version;
    }

    @Override
    public String version() {
        return version;
    }

    @Override
    public ReplayResult apply(ReplayState state, VerifiedEvent event) {
        TaskPayload payload = TaskPayload.fromBytes(event.payloadBytes());
        TaskStateView current = TaskStateView.from(state);

        return switch (event.eventType()) {
            case "TaskCreated" -> applyCreated(state, current, payload, event);
            case "TaskStarted" -> applyStarted(state, current, payload, event);
            case "TaskCompleted" -> applyCompleted(state, current, payload, event);
            case "TaskCorrected" -> applyCorrected(state, current, payload, event);
            case "TaskCancelled" -> applyCancelled(state, current, payload, event);
            default -> throw new IllegalStateException("Unsupported task eventType: " + event.eventType());
        };
    }

    private ReplayResult applyCreated(ReplayState state, TaskStateView current, TaskPayload payload, VerifiedEvent event) {
        if (current.exists()) {
            throw new IllegalStateException("TaskCreated is only valid for an empty lifecycle");
        }
        ReplayState nextState = current.next(payload.taskId(), TaskStatus.CREATED, event.eventId(), null, null, null, event, state);
        return new ReplayResult(nextState, List.of(taskOutput("task-created", event, payload)));
    }

    private ReplayResult applyStarted(ReplayState state, TaskStateView current, TaskPayload payload, VerifiedEvent event) {
        requireExistingTask(current, payload);
        if (current.status() != TaskStatus.CREATED && current.status() != TaskStatus.REOPENED) {
            throw new IllegalStateException(
                event.eventType() + " is invalid from status " + current.status() + " for eventId " + event.eventId()
            );
        }
        ReplayState nextState = current.next(
            payload.taskId(),
            TaskStatus.ACTIVE,
            event.eventId(),
            current.lastCompletionEventId(),
            current.correctionTargetEventId(),
            current.correctionReason(),
            event,
            state
        );
        return new ReplayResult(nextState, List.of());
    }

    private ReplayResult applyCompleted(ReplayState state, TaskStateView current, TaskPayload payload, VerifiedEvent event) {
        requireExistingTask(current, payload);
        requireStatus(current, TaskStatus.ACTIVE, event);
        ReplayState nextState = current.next(
            payload.taskId(),
            TaskStatus.DONE,
            event.eventId(),
            event.eventId(),
            null,
            null,
            event,
            state
        );
        return new ReplayResult(nextState, List.of(taskOutput("task-completed", event, payload)));
    }

    private ReplayResult applyCorrected(ReplayState state, TaskStateView current, TaskPayload payload, VerifiedEvent event) {
        requireExistingTask(current, payload);
        requireStatus(current, TaskStatus.DONE, event);
        if (payload.targetEventId() == null || payload.reason() == null) {
            throw new IllegalStateException("TaskCorrected requires targetEventId and reason");
        }
        if (!payload.targetEventId().equals(current.lastCompletionEventId())) {
            throw new IllegalStateException(
                "TaskCorrected target " + payload.targetEventId()
                    + " does not match last completion event " + current.lastCompletionEventId()
            );
        }
        ReplayState nextState = current.next(
            payload.taskId(),
            TaskStatus.REOPENED,
            event.eventId(),
            current.lastCompletionEventId(),
            payload.targetEventId(),
            payload.reason(),
            event,
            state
        );
        return new ReplayResult(nextState, List.of(taskOutput("task-corrected", event, payload)));
    }

    private ReplayResult applyCancelled(ReplayState state, TaskStateView current, TaskPayload payload, VerifiedEvent event) {
        requireExistingTask(current, payload);
        if (current.status() != TaskStatus.CREATED && current.status() != TaskStatus.ACTIVE && current.status() != TaskStatus.REOPENED) {
            throw new IllegalStateException(
                "TaskCancelled is invalid from status " + current.status() + " for eventId " + event.eventId()
            );
        }
        ReplayState nextState = current.next(
            payload.taskId(),
            TaskStatus.CANCELLED,
            event.eventId(),
            current.lastCompletionEventId(),
            current.correctionTargetEventId(),
            current.correctionReason(),
            event,
            state
        );
        return new ReplayResult(nextState, List.of(taskOutput("task-cancelled", event, payload)));
    }

    private void requireExistingTask(TaskStateView current, TaskPayload payload) {
        if (!current.exists()) {
            throw new IllegalStateException("Task lifecycle has not been created");
        }
        if (!current.taskId().equals(payload.taskId())) {
            throw new IllegalStateException(
                "Task payload taskId " + payload.taskId() + " does not match lifecycle taskId " + current.taskId()
            );
        }
    }

    private void requireStatus(TaskStateView current, TaskStatus expected, VerifiedEvent event) {
        if (current.status() != expected) {
            throw new IllegalStateException(
                event.eventType() + " is invalid from status " + current.status() + " for eventId " + event.eventId()
            );
        }
    }

    private DerivedOutput taskOutput(String kind, VerifiedEvent event, TaskPayload payload) {
        String value = payload.targetEventId() == null
            ? payload.taskId()
            : payload.taskId() + "|" + payload.targetEventId() + "|" + payload.reason();
        return new DerivedOutput(kind, event.eventId(), value);
    }
}
