package kernel.laws.task;

public enum TaskStatus {
    CREATED,
    ACTIVE,
    REOPENED,
    DONE,
    CANCELLED
}
