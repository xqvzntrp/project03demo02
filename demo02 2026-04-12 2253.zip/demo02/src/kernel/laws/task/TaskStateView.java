package kernel.laws.task;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.nio.charset.StandardCharsets;

import kernel.core.ReplayState;
import kernel.core.VerifiedEvent;

public record TaskStateView(
    String taskId,
    TaskStatus status,
    String lastStateEventId,
    String lastCompletionEventId,
    String correctionTargetEventId,
    String correctionReason,
    List<String> eventIds
) {
    private static final String PREFIX = "TASK_STATE:";

    public static TaskStateView from(ReplayState state) {
        if (state.eventCount() == 0) {
            return new TaskStateView(null, null, null, null, null, null, List.of());
        }
        if (state.appliedEventIds().isEmpty()) {
            throw new IllegalStateException("ReplayState is missing task state marker");
        }

        String marker = state.appliedEventIds().getFirst();
        if (!marker.startsWith(PREFIX)) {
            throw new IllegalStateException("ReplayState marker is invalid: " + marker);
        }

        String[] parts = marker.substring(PREFIX.length()).split("\\|", -1);
        if (parts.length != 6 || parts[0].isEmpty() || parts[1].isEmpty()) {
            throw new IllegalStateException("ReplayState marker is malformed: " + marker);
        }

        List<String> eventIds = List.copyOf(state.appliedEventIds().subList(1, state.appliedEventIds().size()));
        return new TaskStateView(
            decode(parts[0]),
            TaskStatus.valueOf(parts[1]),
            decodeNullable(parts[2]),
            decodeNullable(parts[3]),
            decodeNullable(parts[4]),
            decodeNullable(parts[5]),
            eventIds
        );
    }

    public boolean exists() {
        return taskId != null;
    }

    public ReplayState next(
        String taskId,
        TaskStatus status,
        String lastStateEventId,
        String lastCompletionEventId,
        String correctionTargetEventId,
        String correctionReason,
        VerifiedEvent event,
        ReplayState priorState
    ) {
        List<String> nextEntries = new ArrayList<>();
        nextEntries.add(
            PREFIX
                + encode(taskId) + "|"
                + status.name() + "|"
                + encodeNullable(lastStateEventId) + "|"
                + encodeNullable(lastCompletionEventId) + "|"
                + encodeNullable(correctionTargetEventId) + "|"
                + encodeNullable(correctionReason)
        );
        nextEntries.addAll(eventIds);
        nextEntries.add(event.eventId());
        return new ReplayState(
            nextEntries,
            priorState.eventCount() + 1,
            priorState.totalPayloadBytes() + event.payloadBytes().length,
            event.eventId()
        );
    }

    private static String encode(String value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String encodeNullable(String value) {
        return value == null ? "" : encode(value);
    }

    private static String decode(String value) {
        return new String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8);
    }

    private static String decodeNullable(String value) {
        return value == null || value.isEmpty() ? null : decode(value);
    }
}
