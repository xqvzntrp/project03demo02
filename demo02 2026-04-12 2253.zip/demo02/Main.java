import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Stream;

import javax.tools.JavaCompiler;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

public final class Main {
    private static volatile ClassLoader launcherClassLoader;

    private Main() {
    }

    public static void main(String[] args) throws Exception {
        Path repoRoot = Path.of("").toAbsolutePath();
        Path sourceDir = repoRoot.resolve("src");
        Path outputDir = repoRoot.resolve("build").resolve("classes");
        compileIfNeeded(sourceDir, outputDir);
        invokeEntryPoint(outputDir, args);
    }

    private static void compileIfNeeded(Path sourceDir, Path outputDir) throws IOException {
        if (!Files.isDirectory(sourceDir)) {
            throw new IllegalStateException("Expected source directory at " + sourceDir);
        }
        List<Path> javaFiles = javaFiles(sourceDir);
        if (javaFiles.isEmpty()) {
            throw new IllegalStateException("No Java sources found under " + sourceDir);
        }
        if (!needsCompilation(javaFiles, sourceDir, outputDir)) {
            copyResources(sourceDir, outputDir);
            return;
        }

        Files.createDirectories(outputDir);
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            throw new IllegalStateException("Java compiler is not available. Use a JDK, not a JRE.");
        }

        try (StandardJavaFileManager fileManager = compiler.getStandardFileManager(null, null, StandardCharsets.UTF_8)) {
            Iterable<? extends javax.tools.JavaFileObject> compilationUnits = fileManager.getJavaFileObjectsFromPaths(javaFiles);
            List<String> options = List.of("-encoding", StandardCharsets.UTF_8.name(), "-d", outputDir.toString());
            Boolean success = compiler.getTask(null, fileManager, null, options, null, compilationUnits).call();
            if (!Boolean.TRUE.equals(success)) {
                throw new IllegalStateException("Compilation failed for sources under " + sourceDir);
            }
        }
        copyResources(sourceDir, outputDir);
    }

    private static boolean needsCompilation(List<Path> javaFiles, Path sourceDir, Path outputDir) throws IOException {
        Path platformClass = outputDir.resolve(Path.of("kernel", "apps", "PlatformCli.class"));
        if (!Files.exists(platformClass)) {
            return true;
        }

        for (Path javaFile : javaFiles) {
            Path classFile = compiledClassFor(sourceDir, outputDir, javaFile);
            if (!Files.exists(classFile)) {
                return true;
            }
            long sourceTime = Files.getLastModifiedTime(javaFile).toMillis();
            long classTime = Files.getLastModifiedTime(classFile).toMillis();
            if (sourceTime > classTime) {
                return true;
            }
        }
        return false;
    }

    private static void invokeEntryPoint(Path outputDir, String[] args) throws Exception {
        URL[] urls = { outputDir.toUri().toURL() };
        URLClassLoader classLoader = new URLClassLoader(urls, Main.class.getClassLoader());
        launcherClassLoader = classLoader;
        Thread.currentThread().setContextClassLoader(classLoader);
        String className = "kernel.apps.PlatformCli";
        String[] forwarded = args;
        if (args.length >= 2 && "--mode".equals(args[0]) && "cli".equals(args[1])) {
            className = "kernel.host.MiniCoreHost";
            forwarded = java.util.Arrays.copyOfRange(args, 2, args.length);
        }
        Class<?> entryClass = Class.forName(className, true, classLoader);
        Method mainMethod = entryClass.getMethod("main", String[].class);
        mainMethod.invoke(null, (Object) forwarded);
    }

    private static List<Path> javaFiles(Path sourceDir) throws IOException {
        try (Stream<Path> stream = Files.walk(sourceDir)) {
            return stream
                .filter(Files::isRegularFile)
                .filter(path -> path.getFileName().toString().endsWith(".java"))
                .toList();
        }
    }

    private static List<Path> existingFiles(Path directory) throws IOException {
        if (!Files.isDirectory(directory)) {
            return List.of();
        }
        try (Stream<Path> stream = Files.walk(directory)) {
            return stream.filter(Files::isRegularFile).toList();
        }
    }

    private static void copyResources(Path sourceDir, Path outputDir) throws IOException {
        try (Stream<Path> stream = Files.walk(sourceDir)) {
            for (Path sourcePath : (Iterable<Path>) stream::iterator) {
                if (!Files.isRegularFile(sourcePath)) {
                    continue;
                }
                if (sourcePath.getFileName().toString().endsWith(".java")) {
                    continue;
                }
                Path relativePath = sourceDir.relativize(sourcePath);
                Path outputPath = outputDir.resolve(relativePath);
                Path parent = outputPath.getParent();
                if (parent != null) {
                    Files.createDirectories(parent);
                }
                Files.copy(sourcePath, outputPath, StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    private static Path compiledClassFor(Path sourceDir, Path outputDir, Path javaFile) {
        Path relativePath = sourceDir.relativize(javaFile);
        String fileName = relativePath.getFileName().toString();
        String classFileName = fileName.substring(0, fileName.length() - ".java".length()) + ".class";
        Path parent = relativePath.getParent();
        return parent == null ? outputDir.resolve(classFileName) : outputDir.resolve(parent).resolve(classFileName);
    }

    private static long latestModifiedTime(List<Path> paths) throws IOException {
        long latest = 0L;
        for (Path path : paths) {
            latest = Math.max(latest, Files.getLastModifiedTime(path).toMillis());
        }
        return latest;
    }
}
