import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Concatenates source/docs files under a directory into one output file.
 * File selection is controlled by .concatinclude and .concatignore rules
 * in the source directory using a lightweight gitignore-like format:
 *
 * - blank lines and lines starting with # are ignored
 * - glob patterns are evaluated relative to the source directory
 * - leading ! negates a previous ignore rule
 * - trailing / ignores a directory subtree
 *
 * Usage:
 *   javac ConcatDirectoryFiles.java
 *   java ConcatDirectoryFiles [sourceDirectory] [outputFile]
 *     [--include <file> | --no-include]
 *     [--ignore <file> | --no-ignore]
 *
 * Defaults:
 *   sourceDirectory = current directory
 *   outputFile      = all-sources.txt
 *   include rules   = .concatinclude in sourceDirectory
 *   ignore rules    = .concatignore in sourceDirectory
 */
public final class ConcatDirectoryFiles {

    private ConcatDirectoryFiles() {
    }

    public static void main(String[] args) throws IOException {
        CliOptions options = CliOptions.parse(args);
        Path sourceDirectory = options.sourceDirectory();
        Path outputFile = options.outputFile();

        if (!Files.exists(sourceDirectory) || !Files.isDirectory(sourceDirectory)) {
            throw new IllegalArgumentException("Source directory does not exist or is not a directory: " + sourceDirectory);
        }

        IncludeRules includeRules = IncludeRules.load(sourceDirectory, options.useIncludeRules(), options.includeFile());
        IgnoreRules ignoreRules = IgnoreRules.load(sourceDirectory, options.useIgnoreRules(), options.ignoreFile());
        List<Path> filesToConcat;
        try (Stream<Path> pathStream = Files.walk(sourceDirectory, FileVisitOption.FOLLOW_LINKS)) {
            filesToConcat = pathStream
                .filter(Files::isRegularFile)
                .filter(path -> isIncludedFile(path, sourceDirectory, outputFile, includeRules, ignoreRules))
                .sorted(Comparator.comparing(path -> sourceDirectory.relativize(path).toString()))
                .collect(Collectors.toList());
        }

        if (outputFile.getParent() != null) {
            Files.createDirectories(outputFile.getParent());
        }

        try (BufferedWriter writer = Files.newBufferedWriter(outputFile, StandardCharsets.UTF_8)) {
            for (Path file : filesToConcat) {
                Path relativePath = sourceDirectory.relativize(file);
                writer.write("* ===== " + relativePath + " =====");
                writer.newLine();
                for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                    writer.write(line);
                    writer.newLine();
                }
                writer.newLine();
            }
        }

        System.out.println("Wrote " + filesToConcat.size() + " file(s) to: " + outputFile);
    }

    private static boolean isIncludedFile(
        Path path,
        Path sourceDirectory,
        Path outputFile,
        IncludeRules includeRules,
        IgnoreRules ignoreRules
    ) {
        if (path.equals(outputFile)) {
            return false;
        }

        Path relativePath = sourceDirectory.relativize(path);
        if (!includeRules.matches(relativePath)) {
            return false;
        }
        if (ignoreRules.matches(relativePath)) {
            return false;
        }
        return true;
    }

    private static final class IncludeRules {
        private static final String RULES_FILE = ".concatinclude";

        private final List<Rule> rules;

        private IncludeRules(List<Rule> rules) {
            this.rules = rules;
        }

        static IncludeRules load(Path sourceDirectory, boolean useIncludeRules, Path explicitRulesFile) throws IOException {
            if (!useIncludeRules) {
                return new IncludeRules(List.of(Rule.parse("**")));
            }

            Path rulesFile = explicitRulesFile != null
                ? explicitRulesFile
                : sourceDirectory.resolve(RULES_FILE);
            if (!Files.exists(rulesFile)) {
                throw new IllegalArgumentException("Include rules file does not exist: " + rulesFile);
            }

            List<Rule> rules = loadRules(rulesFile);
            if (rules.isEmpty()) {
                throw new IllegalArgumentException("Include rules file is empty: " + rulesFile);
            }
            return new IncludeRules(List.copyOf(rules));
        }

        boolean matches(Path relativePath) {
            String unixPath = toUnixPath(relativePath);
            for (Rule rule : rules) {
                if (rule.matches(unixPath)) {
                    return true;
                }
            }
            return false;
        }
    }

    private static final class IgnoreRules {
        private static final String RULES_FILE = ".concatignore";

        private final List<Rule> rules;

        private IgnoreRules(List<Rule> rules) {
            this.rules = rules;
        }

        static IgnoreRules load(Path sourceDirectory, boolean useIgnoreRules, Path explicitRulesFile) throws IOException {
            if (!useIgnoreRules) {
                return new IgnoreRules(List.of());
            }
            Path rulesFile = explicitRulesFile != null
                ? explicitRulesFile
                : sourceDirectory.resolve(RULES_FILE);
            if (!Files.exists(rulesFile)) {
                return new IgnoreRules(List.of());
            }
            return new IgnoreRules(List.copyOf(loadRules(rulesFile)));
        }

        boolean matches(Path relativePath) {
            String unixPath = toUnixPath(relativePath);
            boolean ignored = false;
            for (Rule rule : rules) {
                if (rule.matches(unixPath)) {
                    ignored = !rule.negated();
                }
            }
            return ignored;
        }
    }

    private static List<Rule> loadRules(Path rulesFile) throws IOException {
        List<Rule> rules = new ArrayList<>();
        for (String rawLine : Files.readAllLines(rulesFile, StandardCharsets.UTF_8)) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            rules.add(Rule.parse(line));
        }
        return rules;
    }

    private record Rule(boolean negated, boolean anchored, boolean directoryOnly, String literalPattern, PathMatcher matcher) {
        static Rule parse(String line) {
            boolean negated = line.startsWith("!");
            String pattern = negated ? line.substring(1).trim() : line;
            boolean directoryOnly = pattern.endsWith("/");
            boolean anchored = pattern.startsWith("/");
            String body = directoryOnly ? pattern.substring(0, pattern.length() - 1) : pattern;
            String normalized = normalizePattern(body, anchored);
            return new Rule(
                negated,
                anchored,
                directoryOnly,
                normalizeLiteralPattern(body),
                FileSystems.getDefault().getPathMatcher("glob:" + normalized)
            );
        }

        boolean matches(String unixPath) {
            if (directoryOnly) {
                return matchesDirectory(unixPath);
            }
            return matcher.matches(Path.of(unixPath));
        }

        private boolean matchesDirectory(String unixPath) {
            if (matcher.matches(Path.of(unixPath))) {
                return true;
            }

            if (literalPattern.isEmpty()) {
                return false;
            }

            if (anchored) {
                return unixPath.equals(literalPattern) || unixPath.startsWith(literalPattern + "/");
            }

            return unixPath.equals(literalPattern)
                || unixPath.startsWith(literalPattern + "/")
                || unixPath.contains("/" + literalPattern + "/");
        }

        private static String normalizePattern(String pattern, boolean anchored) {
            String unix = pattern.replace('\\', '/');
            if (unix.startsWith("/")) {
                unix = unix.substring(1);
            }
            if (!anchored && !unix.contains("/")) {
                unix = "**/" + unix;
            }
            return unix;
        }

        private static String normalizeLiteralPattern(String pattern) {
            String unix = pattern.replace('\\', '/');
            return unix.startsWith("/") ? unix.substring(1) : unix;
        }
    }

    private static String toUnixPath(Path path) {
        return path.toString().replace('\\', '/');
    }

    private record CliOptions(
        Path sourceDirectory,
        Path outputFile,
        boolean useIncludeRules,
        Path includeFile,
        boolean useIgnoreRules,
        Path ignoreFile
    ) {
        static CliOptions parse(String[] args) {
            Path sourceDirectory = Paths.get(".").toAbsolutePath().normalize();
            Path outputFile = Paths.get("all-sources.txt").toAbsolutePath().normalize();
            boolean useIncludeRules = true;
            Path includeFile = null;
            boolean useIgnoreRules = true;
            Path ignoreFile = null;
            int positionalIndex = 0;

            for (int i = 0; i < args.length; i++) {
                String arg = args[i];
                switch (arg) {
                    case "--include" -> {
                        if (i + 1 >= args.length) {
                            throw new IllegalArgumentException("Missing value for --include");
                        }
                        useIncludeRules = true;
                        includeFile = Paths.get(args[++i]).toAbsolutePath().normalize();
                    }
                    case "--no-include" -> {
                        useIncludeRules = false;
                        includeFile = null;
                    }
                    case "--ignore" -> {
                        if (i + 1 >= args.length) {
                            throw new IllegalArgumentException("Missing value for --ignore");
                        }
                        useIgnoreRules = true;
                        ignoreFile = Paths.get(args[++i]).toAbsolutePath().normalize();
                    }
                    case "--no-ignore" -> {
                        useIgnoreRules = false;
                        ignoreFile = null;
                    }
                    default -> {
                        if (arg.startsWith("--")) {
                            throw new IllegalArgumentException("Unknown option: " + arg);
                        }
                        if (positionalIndex == 0) {
                            sourceDirectory = Paths.get(arg).toAbsolutePath().normalize();
                        } else if (positionalIndex == 1) {
                            outputFile = Paths.get(arg).toAbsolutePath().normalize();
                        } else {
                            throw new IllegalArgumentException("Too many positional arguments");
                        }
                        positionalIndex++;
                    }
                }
            }

            return new CliOptions(sourceDirectory, outputFile, useIncludeRules, includeFile, useIgnoreRules, ignoreFile);
        }
    }
}
